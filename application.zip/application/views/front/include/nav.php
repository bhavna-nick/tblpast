<header class="header_area">
  <meta http-equiv="Content-Type" content="text/html; charset=euc-kr">
  <!-- start header top -->
  <div class="header_top_area">
    <div class="container">
      <div class="row">
        <div class="header_top clearfix">
          <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <div class="left_header_top">
              <!--<ul>
<li><a href="#"><img src="<?php echo base_url('assets/fronttheme/')?>/img/temp-icon.png" alt="temp-icon">India dc, GR 37°C</a></li>
</ul>-->
            </div>
          </div>
          <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 floatright">
            <div class="right_header_top clearfix floatright">
              <ul class="nav navbar-nav">
                <?php 
$vendorid=$this->session->userdata['vendorauth']['Id'];                                        
if($vendorid!=''){ ?>
                <?php }else { ?>
                <li class="">
                  <a class="border-right-dark-4" href="<?php echo base_url('vendor/register');?>">List your Club
                  </a>
                </li>
                <li class="">
                  <a class="border-right-dark-4" href="<?php echo base_url('vendor');?>">Member Login
                  </a>
                </li>
                <li role="presentation" >
                  <a id="drop1" href="<?php echo base_url('customer');?>" role="button" >
                    Login
                    <span class="caret">
                    </span>
                  </a>
                </li>
                <?php }?>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end header top  -->
  <!-- start main header -->
  <div class="main_header_area">
    <div class="container">
      <!-- start mainmenu & logo -->
      <div class="mainmenu">
        <div id="nav">
          <nav class="navbar navbar-default">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                <span class="sr-only">Toggle navigation
                </span>
                <span class="icon-bar">
                </span>
                <span class="icon-bar">
                </span>
                <span class="icon-bar">
                </span>
              </button>
              <div class="site_logo fix">
                <a id="brand" class="clearfix navbar-brand" href="<?php echo base_url();?>">
                  <img src="<?php echo base_url('assets/fronttheme/')?>/img/site-logo.png" alt="Trips">
                </a>
              </div>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
              <ul class="nav navbar-nav">
                <li role="presentation" >
                  <a id="drop-one" href="<?php echo base_url();?>"  aria-haspopup="true" role="button" aria-expanded="false">
                    Home
                  </a>
                </li>        
                <li>
                  <a href="<?php echo base_url('front/allclub')?>">Clubs
                  </a>
                </li>
                <li>
                  <a href="<?php echo base_url('about')?>">About Us
                  </a>
                </li>
                <li>
                  <a href="<?php echo base_url('contact');?>">Contact Us
                  </a>
                </li>
                <?php 
$vendorid=$this->session->userdata['vendorauth']['Id'];                                        
if($vendorid!=''){ ?>
                <li role="presentation" class="dropdown">
                  <a id="drop2" href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" role="button" aria-expanded="false">
                    <?php echo $this->session->userdata['vendorauth']['author'];?>
                  </a>
                  <ul id="menu2" class="dropdown-menu" role="menu">
                    <li role="presentation">
                      <a role="menuitem" tabindex="-1" href="<?php echo base_url('vendor/updatestep1');?>">Update Club Profile
                      </a>
                    </li>
                    <li role="presentation">
                      <a role="menuitem" tabindex="-1" href="<?php echo base_url('food/foodcategory');?>">List Menu Category
                      </a>
                    </li>
                    <li role="presentation">
                      <a role="menuitem" tabindex="-1" href="<?php echo base_url('food/fooditem');?>">List Menu Item
                      </a>
                    </li>
                    <li role="presentation">
                      <a role="menuitem" tabindex="-1" href="<?php echo base_url('events');?>">List Events
                      </a>
                    </li>
                    <li role="presentation">
                      <a role="menuitem" tabindex="-1" href="<?php echo base_url('vendor/changepassword');?>">Change Password
                      </a>
                    </li>
                    <li role="presentation">
                      <a role="menuitem" tabindex="-1" href="<?php echo base_url('vendor/logout');?>">Sign Out
                      </a>
                    </li>
                  </ul>
                </li>
                <?php } ?>
              </ul>
              <div class="emergency_number">
                <a href="tel:1234567890">
                  <img src="<?php echo base_url('assets/fronttheme/')?>/img/call-icon.png" alt="">123 456 7890
                </a>
              </div>
            </div>
            <!-- /.navbar-collapse -->
          </nav>
        </div>
      </div>
      <!-- end mainmenu and logo -->
    </div>
  </div>
  <!-- end main header -->
</header>
<style>
  .mainmenu .nav.navbar-nav li.dropdown > a {
    background: url(img/dropdown_bg.png) no-repeat scroll 95% 90%;
  }
</style>

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Events extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('App');
        $this->load->helper('new_helper');
        $this->load->library('form_validation');
        $this->load->library('email');
        $this->load->library('session');
        $this->load->library('pagination');
        $this->load->helper('url');
    }
    
   public function index()
    {
       $this->App->checkVendorAuthenticate();
        $id = $this->session->userdata['vendorauth']['Id'];
        $data["listcategory"] = $this->App->getPerticularRecord('events','ClubId',$id);
        $this->load->view('front/events/listevent', $data);
    }
     public function index_ci_pagination()
    {
       $this->App->checkVendorAuthenticate();
        $id = $this->session->userdata['vendorauth']['Id'];
        $tot=$this->App->getPerticularRecord('events','ClubId',$id);
        $config["base_url"]    = base_url() . "events/index/";
        $config["total_rows"]  =count($tot);
        $config["per_page"]    = 10;
        $config["uri_segment"] = 3;
        $this->pagination->initialize($config);
        $page                 = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $data["listcategory"] = $this->App->fetch_fooditem('events','ClubId',$id, $config["per_page"], $page);
        $data["links"]        = $this->pagination->create_links();
        
        $this->load->view('front/include/header');
        $this->load->view('front/events/listevent', $data);
        $this->load->view('front/include/footer');
    }
    public function addevent(){
      
        $this->form_validation->set_rules('eventtitle', 'Title', 'required');
        $this->form_validation->set_rules('description', 'Description', 'required');
        $this->form_validation->set_rules('price', 'Price', 'required');
        $id = $this->session->userdata['vendorauth']['Id'];
        
        if (!empty($_FILES['uploadsfl']['name'])) {
            $config['upload_path']   = 'assets/events/';
            $config['allowed_types'] = 'jpg|jpeg|png|gif';
            $config['file_name']     = $_FILES['uploadsfl']['name'];
            
            //Load upload library and initialize configuration
            $this->load->library('upload', $config);
            $this->upload->initialize($config);
            
            if ($this->upload->do_upload('uploadsfl')) {
                $uploadData = $this->upload->data();
                $picture    = $uploadData['file_name'];
            } 
        } if ($this->form_validation->run() == FALSE) {
            if (validation_errors() != '') {
                $data['error'] = validation_errors();
            }
        } else {
            $id        = $this->session->userdata['vendorauth']['Id'];
            $days=$this->input->post('days');
            if($days=='1'){ $ds='1';}else{ $ds=$this->input->post('nooddays');}
           
             $clbname = $this->input->post('eventtitle');
            $trim    = trim($clbname);
            $ow      = strtolower($trim);
            $string  = str_replace(' ', '-', $ow);
            $id      = $this->session->userdata['vendorauth']['Id'];
            $str     = preg_replace('/\s+/', '-', $string);
            $chkslug = $this->App->checkExistEdit('events', 'Slug', $str, 'Id', $id);
            if ($chkslug == '1') {
                $r    = rand(1, 4);
                $slug = $str . $r;
            } else {
                $slug = $str;
            }  
            $arr       = array(
                'ClubId' => $id,
                'Title' => $this->input->post('eventtitle'),
                'Description' => $this->input->post('description'),
                'FromDate' => $this->input->post('fromdate'),
                'ToDate' => $this->input->post('todate'),
                'NoofDays' => $ds,
                'OneDate' => $this->input->post('specialdate'),
                'TimeFrom' => $this->input->post('fromtime'),
                'TimeTo' => $this->input->post('totime'),
                'Status' => '1',
                'Price' => $this->input->post('price'),                
                'Image' => $picture,
                'Created' => date('Y-m-d'),
                'Slug'=>$slug,
            );
            $iid = $this->App->insertdata('events', $arr);
            redirect('events');            
        } 
    }


    public function deleteevent()
    {
        $this->App->checkVendorAuthenticate();
        $id = $this->input->post('id');
        $this->App->deletedata('events', 'Id', $id);
        return 1;
    }
    public function updateeventfrom()
    {
        $this->App->checkVendorAuthenticate();
        $id  = $this->input->post('id');
        $ads = $this->App->getPerticularRecord('events', 'Id', $id);
        $sd  = '';
        if (!empty($ads)) {
            foreach ($ads as $tes) {
                $ClubId = $tes['ClubId'];
                $Title = $tes['Title'];
                $Description = $tes['Description'];
                $FromDate    = $tes['FromDate'];
                $ToDate  = $tes['ToDate'];
                $NoofDays     = $tes['NoofDays'];
                $OneDate     = $tes['OneDate'];
                $TimeFrom     = $tes['TimeFrom'];
                $TimeTo     = $tes['TimeTo'];
                $Image  = $tes['Image'];
                $Status = $tes['Status'];
                $Price = $tes['Price'];
                $sd .= '<div class="modal fade" id="myModal" role="dialog"> <div class="modal-dialog">hello </div>';
            }
        }
        $sd .= '</div>';
        $data = $sd;
        echo json_encode($data);
    } 
    public function editevent($slug){
        $this->form_validation->set_rules('eventtitle', 'Title', 'required');
        $this->form_validation->set_rules('description', 'Description', 'required');
        $this->form_validation->set_rules('price', 'Price', 'required');
        $id = $this->session->userdata['vendorauth']['Id'];
        
        if (!empty($_FILES['uploadsfl']['name'])) {
            $config['upload_path']   = 'assets/events/';
            $config['allowed_types'] = 'jpg|jpeg|png|gif';
            $config['file_name']     = $_FILES['uploadsfl']['name'];
            
            //Load upload library and initialize configuration
            $this->load->library('upload', $config);
            $this->upload->initialize($config);
            
            if ($this->upload->do_upload('uploadsfl')) {
                $uploadData = $this->upload->data();
                $picture    = $uploadData['file_name'];
            } 
        }else{
            $picture=$this->input->post('oldimg');
        } if ($this->form_validation->run() == FALSE) {
            if (validation_errors() != '') {
                $data['error'] = validation_errors();
            }
        } else {
            $id        = $this->session->userdata['vendorauth']['Id'];
            $days=$this->input->post('days');
            if($days=='1'){ $ds='1';}else{ $ds=$this->input->post('nooddays');}
           
             $clbname = $this->input->post('eventtitle');
            $trim    = trim($clbname);
            $ow      = strtolower($trim);
            $string  = str_replace(' ', '-', $ow);
            $id      = $this->session->userdata['vendorauth']['Id'];
            $str     = preg_replace('/\s+/', '-', $string);
            $chkslug = $this->App->checkExistEdit('events', 'Slug', $str, 'Id', $id);
            if ($chkslug == '1') {
                $r    = rand(1, 4);
                $slugold = $str . $r;
            } else {
                $slugold = $str;
            }  
            $arr       = array(
                'ClubId' => $id,
                'Title' => $this->input->post('eventtitle'),
                'Description' => $this->input->post('description'),
                'FromDate' => $this->input->post('fromdate'),
                'ToDate' => $this->input->post('todate'),
                'NoofDays' => $ds,
                'OneDate' => $this->input->post('specialdate'),
                'TimeFrom' => $this->input->post('fromtime'),
                'TimeTo' => $this->input->post('totime'),
                'Status' => $this->input->post('status'),
                'Price' => $this->input->post('price'),                
                'Image' => $picture,
                'Created' => date('Y-m-d'),
                'Slug'=>$slugold,
            );
           // print_r($arr);die;
            $iid = $this->App->update('events','Slug',$slug, $arr);
            redirect('events');    
        }
        $data['eventdetails'] = $this->App->getPerticularRecord('events', 'Slug', $slug);
        $this->load->view('front/include/header');
        $this->load->view('front/events/editevents', $data);
        $this->load->view('front/include/footer');
    }
}

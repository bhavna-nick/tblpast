<!-- start breadcrumb -->
<section class="breadcrumb_main_area margin-bottom-80">
  <div class="container-fluid">
    <div class="row">
      <?php $vid=$vendordetails[0]['Id'];
$layout=$this->App->getPerticularRecord('clublayout','VendorId',$vid);
$img=$layout[0]['MainImage'];
$Description=$layout[0]['Description'];
if($img!=''){
$i=base_url('assets/clubimage/'.$img);
}else{
$i=base_url('assets/fronttheme/img/special-offer-yellow-main.png');
} ?>
      <style>
        .march {
          background:url(<?php echo $i;?>);
          background-repeat: no-repeat;
          background-size:     cover;
        }
      </style>
      <div class="breadcrumb_main nice_title march">
        <h2>
          <?php echo $vendordetails[0]['ClubName'];?>
        </h2>
        <!-- special offer start -->
        <div class="special_offer_main">
          <div class="container">
            <div class="special_offer_sub">
              <?php $vid=$vendordetails[0]['Id'];
$layout=$this->App->getPerticularRecord('clublayout','VendorId',$vid);
$img=$layout[0]['MainImage'];
$PerAdultPrice=$layout[0]['PerAdultPrice'];

$Cuisines=$layout[0]['Cuisines'];
$Description=$layout[0]['Description'];
if($img!=''){
$i=base_url('assets/clubimage/'.$img);
}else{
$i=base_url('assets/fronttheme/img/special-offer-yellow-main.png');
} ?>
            </div>
          </div>
        </div>         
        <!-- end offer start -->
      </div>
    </div>
  </div>            
</section>
<!-- end breadcrunb -->
<div class="room_detail_main margin-bottom-55">
  <div class="container">
    <div class="row">
      <div class="col-lg-12 col-md-12"><?php  $this->load->view('front/include/tab');?>
      </div>
      <div class="col-lg-9 col-md-9">
        <div class="deluxe_room_detail">
          <div class="section_title content-left margin-bottom-5">
            <h5>
              <?php echo $vendordetails[0]['ClubName'];?> Menu 
              <span class="price floatright">  <?php echo '₹ '.$PerAdultPrice;?>
              </span>
              <br> 
              <span class="day floatright">
              </span>
            </h5>
          </div>
          <?php 
$menucategory =$this->App->passwordChecking('foodcategory','ClubId','Status',$clubid,'1');
if(!empty($menucategory)){
?>
          <div class="bocxcsla">
            <h1 class="menutitle">Menu
            </h1>
            <?php 
$menucategory =$this->App->passwordChecking('foodcategory','ClubId','Status',$clubid,'1');
if(!empty($menucategory)){
foreach($menucategory as $category){
$cattit= $category['Title'];
$cid= $category['Id'];
echo '<h4 class="titmenu">'.$cattit.'</h4>';
$menucategory =$this->App->passwordChecking('fooditem','ClubId','CategoryId',$clubid,$cid);
if(!empty($menucategory)){
echo '<table class="ulc">';
foreach($menucategory as $menu){
if($menu['Status']=='1'){
$menutit=$menu['Title'];
$price=$menu['Price'];
//  echo '<li class="mlk">'.$menutit.' <span class="pricecls">   ₹ '.$price.'</span></li>';
echo '<tr ><td class="mlk">'.$menutit.' </td><td class="pricecls">   ₹ '.$price.'</td></tr>';
}
}
echo '</table>';
}
}
}
?>
          </div>
<?php } ?> <br>
        </div>
      </div>
      <div class="col-lg-3 col-md-3">
        <!-- start hotel booking -->
        <div class="col-lg-12 col-md-12 col-sm-4 myclspo">
          <div class="hotel_booking_area clearfix myclspo1">
            <div class="hotel_booking">
              <form id="form1" role="form" action="#" class="">
                <div class="col-lg-12 col-md-12">
                  <div class="room_book">
                    <h6>Vendor Details
                    </h6>
                    <p>Club
                    </p>
                  </div>
                </div>
                <?php $vid=$vendordetails[0]['Id'];
$vendordetails=$this->App->getPerticularRecord('vendor','Id',$vid);?>
                <div class="form-group col-lg-12 col-md-12">
                  <div class="input-group border-bottom-dark-2">
                    <br>
                    <label style="    font-size: 20px;    color: whitesmoke;">
                      <?php echo $vendordetails[0]['FirstName'].' '.$vendordetails[0]['LastName'];?>
                    </label>
                    <br>
                    <label>
                      <i class="fa fa-envelope">
                      </i> 
                      <?php echo $vendordetails[0]['Email'];?>
                    </label>
                    <label>
                      <i class="fa fa-phone">
                      </i> 
                      <?php echo $vendordetails[0]['Phone'] .' , '.$vendordetails[0]['AlternativePhone'];?>
                    </label>
                    <br>
                    <label>
                      <i class="fa fa-map-marker">
                      </i> 
                      <?php echo $vendordetails[0]['Address'].' <br> '.$vendordetails[0]['City'].'-'.$vendordetails[0]['PostCode'].' ,'.$vendordetails[0]['Country']; ?>
                    </label>
                    <br>
                    <label>
                      <?php $AddressIfram=$vendordetails[0]['AddressIfram'];
if($AddressIfram!=''){ ?>
                      <iframe width="100%" height="250" frameborder="0" style="border:0" src="https://www.google.com/maps/embed/v1/place?key=AIzaSyAyhF2cCWevFm_T8iog0GqV3utCrfAbWYw&q='<?php echo $AddressIfram;?>'">
                      </iframe>
                      <?php } ?>
                    </label> 
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
        <!-- end hotel booking -->
        <!-- start client says slider -->
        <!-- end client says slider -->
      </div>
    </div>
    
  </div>
</div>
</div>
<style>
  .bocxcsla {
    background: url(<?php echo base_url('assets/menu/menu2.jpg')?>) no-repeat;
    padding: 24px;
    color: #fff;
    text-transform: capitalize;
    font-size: 12px;
    list-style: none;
  }
  h1.menutitle {
    font-size: 35px;
    color: #fff;
    padding: 8px 0px;
    /* border-bottom: 1px solid; */
    font-family: cursive;
  }
  h4.titmenu {
    font-size: 15px;
    color: orange;
    font-weight: bold;
    margin-top: 17px;
  }
  .mlk {
    list-style: none;
    width: 84%;
  }
  .pricecls {
    color: yellow;
  }
</style>      
<!-- start contact us area -->
<!-- end contact us area -->
<style>
  .myclspo1 {
    background: #313a45;
  }
  p {
    color: #666666;
    /* font-weight: normal; */
    font-size: 14px;
    font-family: inherit;
    font-weight: normal;
  }
  label {
    font-family: serif;
    color: #ccc;
  }
  span.a {
    COLOR: slategray;
  }
</style>

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Contact extends CI_Controller
{   
    public function __construct()
    {
        parent::__construct();
        $this->load->model('App');
        $this->load->helper('new_helper');
    }
    public function index()
    {        
		$this->form_validation->set_rules('fname', 'First Name', 'required');
		$this->form_validation->set_rules('lname', 'Last Name', 'required');
		$this->form_validation->set_rules('cemail', 'Email', 'required');
		$this->form_validation->set_rules('phone', 'Phone', 'required');
		$this->form_validation->set_rules('subject', 'Subject', 'required');
		$this->form_validation->set_rules('message', 'Message', 'required');
		
		 if ($this->form_validation->run() == FALSE || $err != '') {
            if (validation_errors() != '' || $err != '') {
                $data['error'] = validation_errors() . $err;
            }
        } else {
			$arr=array(
			'FirstName'=>$this->input->post('fname'),
			'LastName'=>$this->input->post('lname'),
			'Email'=>$this->input->post('cemail'),
			'Phone'=>$this->input->post('phone'),
			'Subject'=>$this->input->post('subject'),
			'Message'=>$this->input->post('message'),
			'Created'=>date('Y-m-d')
			);
			$this->App->insertdata('contact', $arr);
			$email=$this->input->post('cemail');
			$message    = '<div style="background-color: #fff; margin: 40px; font: 13px/20px normal Helvetica, Arial, sans-serif;color: #4F5155;">
									<div id="container" style="margin: 10px;border: 1px solid #D0D0D0;box-shadow: 0 0 8px #D0D0D0;">
									<h1 style="color: #fff;background-color: #333;border-bottom: 1px solid #D0D0D0; font-size: 19px;font-weight: normal;margin: 0 0 14px 0;padding: 14px 15px 10px 15px; text-align: center;background: #333;">
									<img src="http://tablefast.cueserve.com/assets/fronttheme/img/footer-logo-one.png">
									</h1>
									<div id="body" style="margin: 0 15px 0 15px;text-align: center;">
									
									Thank You for Contact us. We will get back to soon. <br>
								   
									
									</div>
									<p class="footer" style="font-size: 11px;border-top: 1px solid #D0D0D0; line-height: 32px; padding: 0 10px 0 10px; margin: 20px 0 0 0;text-align: center;background: #333;color: #FFF;">Thank you for working with us. We look forward to seeing you on Tablefast.com.</p>
									</div></div>';
					
					
					$from_email = "bhavna@cueserve.com";
					$to_email   = $email;        
					//Load email library 
					$this->load->library('email');
					
					$this->email->from($from_email, 'Tablefast.com');
					$this->email->to($to_email);
					$this->email->subject('Thank you for Contact us with Tablefast.com');
					
					$this->email->message($message);
					
					$this->email->send();
			$data['success']='Thank you for Contact us. We will get back soon.';
		}
        $this->load->view('front/include/header');
        $this->load->view('front/contact',$data);
        $this->load->view('front/include/footer');
    }
    public function index1()
    {
        echo 'front';
        $this->App->demo();
        echo test_method('Hello World'); 
        $this->load->view('welcome_message');
    }
}

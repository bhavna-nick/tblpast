-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 03, 2018 at 06:41 AM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tablebooking`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `Id` int(11) NOT NULL,
  `UserName` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `status` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`Id`, `UserName`, `Email`, `Password`, `status`) VALUES
(1, 'Admin', 'admin@gmail.com', '202cb962ac59075b964b07152d234b70', 1);

-- --------------------------------------------------------

--
-- Table structure for table `clubgallery`
--

CREATE TABLE `clubgallery` (
  `Id` int(11) NOT NULL,
  `VendorId` int(11) DEFAULT NULL,
  `Image` varchar(255) DEFAULT NULL,
  `Created` date DEFAULT NULL,
  `Status` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clubgallery`
--

INSERT INTO `clubgallery` (`Id`, `VendorId`, `Image`, `Created`, `Status`) VALUES
(1, 2, 'blog-pic1.jpg', '2018-05-02', 1),
(2, 2, 'news-one.jpg', '2018-05-02', 1),
(3, 2, 'recent_blog_post.png', '2018-05-02', 1),
(4, 2, 'recent_blog_post-1.png', '2018-05-02', 1),
(5, 2, 'recent_blog_post-2.png', '2018-05-02', 1),
(6, 2, 'sing_blog_photo_2.jpg', '2018-05-02', 1),
(7, 3, 'room-image-five.png', '2018-05-02', 1),
(8, 3, 'room-image-four.png', '2018-05-02', 1),
(9, 3, 'room-image-fourteen.jpg', '2018-05-02', 1),
(10, 3, 'room-image-nine.png', '2018-05-02', 1),
(11, 3, 'room-image-nineteen.png', '2018-05-02', 1),
(12, 3, 'room-image-seven.png', '2018-05-02', 1),
(13, 3, 'room-image-seventeen.png', '2018-05-02', 1),
(14, 4, 'cS-20.jpg', '2018-05-02', 1),
(15, 4, 'cS-21.jpg', '2018-05-02', 1),
(16, 4, 'cS-24.jpg', '2018-05-02', 1),
(17, 4, 'cS-25.jpg', '2018-05-02', 1),
(18, 4, 'cS-26.jpg', '2018-05-02', 1),
(19, 4, 'cS-27.jpg', '2018-05-02', 1),
(20, 4, 'cS-28.jpg', '2018-05-02', 1),
(21, 4, 'cS-29.jpg', '2018-05-02', 1);

-- --------------------------------------------------------

--
-- Table structure for table `clublayout`
--

CREATE TABLE `clublayout` (
  `Id` int(11) NOT NULL,
  `VendorId` int(11) DEFAULT NULL,
  `nooftables` varchar(255) DEFAULT NULL,
  `noofpax` varchar(255) DEFAULT NULL,
  `mainimage` varchar(255) DEFAULT NULL,
  `Created` date DEFAULT NULL,
  `Description` text,
  `AvailableParking` varchar(255) DEFAULT NULL,
  `PriceParkingPerhrs` varchar(255) DEFAULT NULL,
  `SundayFrom` varchar(255) DEFAULT NULL,
  `SundayTo` varchar(255) DEFAULT NULL,
  `SundayFromClose` varchar(255) DEFAULT NULL,
  `SundayToClose` varchar(255) DEFAULT NULL,
  `MondayFrom` varchar(255) DEFAULT NULL,
  `MondayTo` varchar(255) DEFAULT NULL,
  `MondayFromClose` varchar(255) DEFAULT NULL,
  `MondayToClose` varchar(255) DEFAULT NULL,
  `TuesdayFrom` varchar(255) DEFAULT NULL,
  `TuesdayTo` varchar(255) DEFAULT NULL,
  `TuesdayFromClose` varchar(255) DEFAULT NULL,
  `TuesdayToClose` varchar(255) DEFAULT NULL,
  `WednesdayFrom` varchar(255) DEFAULT NULL,
  `WednesdayTo` varchar(255) DEFAULT NULL,
  `WednesdayFromClose` varchar(255) DEFAULT NULL,
  `WednesdayToClose` varchar(255) DEFAULT NULL,
  `ThursdayFrom` varchar(255) DEFAULT NULL,
  `ThursdayTo` varchar(255) DEFAULT NULL,
  `ThursdayFromClose` varchar(255) DEFAULT NULL,
  `ThursdayToClose` varchar(255) DEFAULT NULL,
  `FridayFrom` varchar(255) DEFAULT NULL,
  `FridayTo` varchar(255) DEFAULT NULL,
  `FridayFromClose` varchar(255) DEFAULT NULL,
  `FridayToClose` varchar(255) DEFAULT NULL,
  `SaturdayFrom` varchar(255) DEFAULT NULL,
  `SaturdayTo` varchar(255) DEFAULT NULL,
  `SaturdayFromClose` varchar(255) DEFAULT NULL,
  `SaturdayToClose` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clublayout`
--

INSERT INTO `clublayout` (`Id`, `VendorId`, `nooftables`, `noofpax`, `mainimage`, `Created`, `Description`, `AvailableParking`, `PriceParkingPerhrs`, `SundayFrom`, `SundayTo`, `SundayFromClose`, `SundayToClose`, `MondayFrom`, `MondayTo`, `MondayFromClose`, `MondayToClose`, `TuesdayFrom`, `TuesdayTo`, `TuesdayFromClose`, `TuesdayToClose`, `WednesdayFrom`, `WednesdayTo`, `WednesdayFromClose`, `WednesdayToClose`, `ThursdayFrom`, `ThursdayTo`, `ThursdayFromClose`, `ThursdayToClose`, `FridayFrom`, `FridayTo`, `FridayFromClose`, `FridayToClose`, `SaturdayFrom`, `SaturdayTo`, `SaturdayFromClose`, `SaturdayToClose`) VALUES
(1, 2, '7', NULL, 'TableFast-Banner-4.jpg', '2018-05-02', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nihil atque modi velit molestiae, repellendus iure sint possimus cumque, provident, dolorum unde laboriosam ut eius ex maiores quod repudiandae aut asperiores?</p>\r\n\r\n<p>This information is especially important for those travelling to your accommodation by car.</p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nihil atque modi velit molestiae, repellendus iure sint possimus cumque, provident, dolorum unde laboriosam ut eius ex maiores quod repudiandae aut asperiores?</p>\r\n\r\n<ul>\r\n	<li>Test</li>\r\n	<li>One</li>\r\n	<li>Two</li>\r\n	<li>Three</li>\r\n	<li>Four</li>\r\n</ul>\r\n\r\n<p>This information is especially important for those travelling to your accommodation by car.</p>\r\n', 'paid', '50', '02:39 PM', '01:37 PM', '01:38 PM', '01:38 PM', '01:38 PM', '01:38 PM', '01:38 PM', '01:38 PM', '01:38 PM', '01:38 PM', '01:38 PM', '01:38 PM', '01:38 PM', '01:38 PM', '01:38 PM', '01:38 PM', '01:38 PM', '01:38 PM', '01:38 PM', '01:38 PM', '01:38 PM', '01:38 PM', '01:38 PM', '01:38 PM', '01:38 PM', '01:38 PM', '01:38 PM', '01:38 PM'),
(2, 3, '9', NULL, 'TableFast-Banner-2.jpg', '2018-05-02', '<p>This information is especially important for those travelling to your accommodation by car.This information is especially important for those travelling to your accommodation by car.This information is especially important for those travelling to your accommodation by car.This information is especially important for those travelling to your accommodation by car.This information is especially important for those travelling to your accommodation by car.This information is especially important for those travelling to your accommodation by car.This information is especially important for those travelling to your accommodation by car.This information is especially important for those travelling to your accommodation by car.</p>\r\n', 'no', '', '05:03 PM', '05:03 PM', '05:04 PM', '05:04 PM', '05:03 PM', '05:03 PM', '05:04 PM', '05:04 PM', '05:03 PM', '05:03 PM', '05:04 PM', '05:04 PM', '05:03 PM', '05:03 PM', '05:04 PM', '05:04 PM', '05:03 PM', '05:04 PM', '05:04 PM', '05:04 PM', '05:04 PM', '05:04 PM', '05:04 PM', '05:04 PM', '05:04 PM', '05:04 PM', '05:04 PM', '05:04 PM'),
(3, 4, 'ds', NULL, 'cS-22.jpg', '2018-05-02', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nihil atque modi velit molestiae, repellendus iure sint possimus cumque, provident, dolorum unde laboriosam ut eius ex maiores quod repudiandae aut asperiores?Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nihil atque modi velit molestiae, repellendus iure sint possimus cumque, provident, dolorum unde laboriosam ut eius ex maiores quod repudiandae aut asperiores?Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nihil atque modi velit molestiae, repellendus iure sint possimus cumque, provident, dolorum unde laboriosam ut eius ex maiores quod repudiandae aut asperiores?Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nihil atque modi velit molestiae, repellendus iure sint possimus cumque, provident, dolorum unde laboriosam ut eius ex maiores quod repudiandae aut asperiores?</p>\r\n', 'no', '', '05:10 PM', '05:10 PM', '05:10 PM', '05:10 PM', '05:10 PM', '05:10 PM', '05:10 PM', '05:10 PM', '05:10 PM', '05:10 PM', '05:10 PM', '05:10 PM', '05:10 PM', '05:10 PM', '05:10 PM', '05:10 PM', '05:10 PM', '05:10 PM', '05:10 PM', '05:10 PM', '05:10 PM', '05:10 PM', '05:10 PM', '05:10 PM', '05:10 PM', '05:10 PM', '05:10 PM', '05:10 PM');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `Id` int(11) NOT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Phone` varchar(50) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `Fbloginkey` varchar(255) DEFAULT NULL,
  `Gploginkey` varchar(255) DEFAULT NULL,
  `Status` int(5) DEFAULT NULL,
  `Created` date DEFAULT NULL,
  `FirstName` varchar(255) DEFAULT NULL,
  `LastName` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vendor`
--

CREATE TABLE `vendor` (
  `Id` int(11) NOT NULL,
  `FirstName` varchar(255) DEFAULT NULL,
  `LastName` varchar(255) DEFAULT NULL,
  `ClubName` varchar(255) DEFAULT NULL,
  `City` varchar(255) DEFAULT NULL,
  `State` varchar(255) DEFAULT NULL,
  `Country` varchar(255) DEFAULT NULL,
  `Phone` varchar(40) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `Created` date DEFAULT NULL,
  `Status` int(5) DEFAULT NULL,
  `PaymentStatus` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `AlternativePhone` varchar(50) DEFAULT NULL,
  `PostCode` varchar(50) DEFAULT NULL,
  `AddressIfram` text,
  `ContactName` varchar(255) DEFAULT NULL,
  `Address` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vendor`
--

INSERT INTO `vendor` (`Id`, `FirstName`, `LastName`, `ClubName`, `City`, `State`, `Country`, `Phone`, `Password`, `Created`, `Status`, `PaymentStatus`, `Email`, `AlternativePhone`, `PostCode`, `AddressIfram`, `ContactName`, `Address`) VALUES
(1, 'bhavna', 'baria', 'dfsd', NULL, NULL, NULL, NULL, NULL, '2018-05-01', 4, NULL, 'itadmin@cueserve.com', NULL, NULL, NULL, NULL, NULL),
(2, 'kavya', 'hb', 'Light Club', 'baroda', NULL, 'Gujarat', '3453453453', NULL, '2018-05-02', 2, NULL, 'kavyahb97@gmail.com', '3453453453', '390019', 'Ajwa+road,super+bakery+baroda', 'Kavya', 'Ajwa road,super bakery ,baroda'),
(3, 'Navya', 'Hb', 'Fastclub', 'baroda', NULL, 'Gujarat', '1321313242', NULL, '2018-05-02', 1, NULL, 'navya@g.com', '2233223322', '390019', 'kamlanagar+aadarsh+soc', 'Navya Shah', 'kamlanagar  aadarsh soc'),
(4, 'Hardik', 'Baria', 'Club Care', 'baroda', NULL, 'Gujarat', '9903242342', NULL, '2018-05-02', 0, NULL, 'baria.hardik@gmail.com', '3453453453', '390019', 'ajwa+road+vrundavan+park', 'Hardik Baria', 'ajwa road vrundavan park');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `clubgallery`
--
ALTER TABLE `clubgallery`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `clublayout`
--
ALTER TABLE `clublayout`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `vendor`
--
ALTER TABLE `vendor`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `clubgallery`
--
ALTER TABLE `clubgallery`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `clublayout`
--
ALTER TABLE `clublayout`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vendor`
--
ALTER TABLE `vendor`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
  
  ALTER TABLE `vendor` ADD `Slug` VARCHAR(255) NULL AFTER `Address`;

ALTER TABLE `admin` CHANGE `status` `Status` INT(5) NULL DEFAULT NULL;
ALTER TABLE `clublayout` CHANGE `nooftables` `NoofTables` VARCHAR(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL, CHANGE `noofpax` `NoofPax` VARCHAR(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL, CHANGE `mainimage` `MainImage` VARCHAR(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL;
  
  ALTER TABLE `clublayout` ADD `PerAdultPrice` VARCHAR(255) NULL AFTER `SaturdayToClose`, ADD `PerChildPrice` VARCHAR(255) NULL AFTER `PerAdultPrice`;
ALTER TABLE `clublayout` ADD `Cuisines` TEXT NULL AFTER `PerChildPrice`;
  
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

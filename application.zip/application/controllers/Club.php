<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Club extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('App');
        $this->load->helper('new_helper');
        $this->load->library('form_validation');
        $this->load->library('email');
        $this->load->library('session');
    }
    public function index()
    {        
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
        $this->form_validation->set_rules('password', 'Password', 'required|min_length[6]|max_length[12]');
        if ($_POST) {
            $email    = $this->input->post('email');
            $password = md5($this->input->post('password'));
            $chkauth  = $this->App->passwordChecking('vendor', 'Email', 'Password', $email, $password);
            if ($chkauth == '0') {
                $err = 'Username and Password does not match.';
            }
            
        }
        if ($this->form_validation->run() == FALSE || $err != '') {
            if (validation_errors() != '' || $err != '') {
                $data['error'] = validation_errors() . $err;
            }
        } else {
            if (!empty($chkauth)) {
                
                $arraydata = array(
                    'author' => $chkauth[0]['FirstName'] . ' ' . $chkauth[0]['LastName'],
                    'Id' => $chkauth[0]['Id'],
                    'ClubName' => $chkauth[0]['ClubName'],
                    'Email' => $chkauth[0]['Email']
                );
                
                $this->session->set_userdata('vendorauth', $arraydata);
                redirect('vendor/dashboard');
            }
        }
        $this->load->view('front/include/header');
        $this->load->view('front/vendor/login', $data);
        $this->load->view('front/include/footer');
    }
    public function dashboard()
    {        
        $this->session->userdata['vendorauth']['author'];
        $this->session->userdata['vendorauth']['Id'];
        $this->load->view('front/include/header');
        $this->load->view('front/vendor/dashboard');
        $this->load->view('front/include/footer');
    }
    public function logout()
    {
        $this->session->unset_userdata('vendorauth');
        redirect();
    }
    public function register()
    {
        $this->form_validation->set_rules('lastname', 'Last Name', 'required');
        $this->form_validation->set_rules('clubname', 'Club Name', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required|min_length[6]|max_length[12]');
        $this->form_validation->set_rules('state', 'State', 'required');
        $this->form_validation->set_rules('firstname', 'First Name', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
        $this->form_validation->set_rules('phone', 'Phone', 'required');
        $this->form_validation->set_rules('city', 'City', 'required');
        $this->form_validation->set_rules('country', 'Country', 'required');
        if ($_POST) {
            $email    = $this->input->post('email');
            $phone    = $this->input->post('phone');
            $chkemail = $this->App->checkExist('vendor', 'Email', $email);
            $chkphone = $this->App->checkExist('vendor', 'Phone', $phone);
            
            if ($chkemail == '1') {
                
                $err = 'Email Id already Exist.' . '<br>';
            }
            if ($chkphone == '1') {
                $err1 = 'Phone number already Exist.';
            }
        }
        if ($this->form_validation->run() == FALSE || $err != '' || $err1 != '') {
            if (validation_errors() != '' || $err != '' || $err1 != '') {
                $data['error'] = validation_errors() . $err . $err1;
            }
        } else {
            $arr = array(
                'FirstName' => $this->input->post('firstname'),
                'LastName' => $this->input->post('lastname'),
                'ClubName' => $this->input->post('clubname'),
                'City' => $this->input->post('city'),
                'State' => $this->input->post('state'),
                'Country' => $this->input->post('country'),
                'Phone' => $this->input->post('phone'),
                'Email' => $this->input->post('email'),
                'Password' => md5($this->input->post('password')),
                'Created' => date('Y-m-d'),
                'Status' => '0'
            );
            $this->App->insertdata('vendor', $arr);
            
            $config = Array(
                'protocol' => 'smtp',
                'smtp_host' => 'mail.cueserve.com',
                'smtp_port' => 25,
                'smtp_user' => 'jayapatel@cueserve.com', // change it to yours
                'smtp_pass' => 'jaya123', // change it to yours
                'mailtype' => 'html',
                'charset' => 'iso-8859-1',
                'wordwrap' => TRUE
            );
            
            $email   = $this->input->post('email');
            $message = $this->load->view('email/register', '', true);
            $this->load->library('email', $config);
            $this->email->set_newline("\r\n");
            $this->email->from('jayapatel@cueserve.com'); // change it to yours
            $this->email->to($email); // change it to yours
            $this->email->subject('Thank you for register');
            $this->email->message($message);
            if ($this->email->send()) {                
            } else {
                $data['error'] = 'Sorry, Email not send';
            }            
            $data['success'] = 'Thank you for register.';            
        }             
        $this->load->view('front/include/header');
        $this->load->view('front/vendor/register', $data);
        $this->load->view('front/include/footer');
    }
    public function emailpage()
    {
        $this->load->view('email/register');
    } 
    
}
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Vendor extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('App');
        $this->load->helper('new_helper');
        $this->load->library('form_validation');
        $this->load->library('email');
        $this->load->library('session');
    }
    
    public function index()
    {        
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
        $this->form_validation->set_rules('password', 'Password', 'required|min_length[8]');
        if ($_POST) {
            $email    = $this->input->post('email');
            $password = md5($this->input->post('password'));
            $chkauth  = $this->App->passwordChecking('vendor', 'Email', 'Password', $email, $password);
            if ($chkauth == '0') {
                $err = 'Email Id and Password does not match.';
            }            
        }
        if ($this->form_validation->run() == FALSE || $err != '') {
            if (validation_errors() != '' || $err != '') {
                $data['error'] = validation_errors() . $err;
            }
        } else {
            if (!empty($chkauth)) {                
                $arraydata = array(
                    'author' => $chkauth[0]['FirstName'] . ' ' . $chkauth[0]['LastName'],
                    'Id' => $chkauth[0]['Id'],
                    'ClubName' => $chkauth[0]['ClubName'],
                    'Email' => $chkauth[0]['Email']
                );                
                $this->session->set_userdata('vendorauth', $arraydata);
                redirect('vendor/dashboard');
            }
        }
        $this->load->view('front/include/header');
        $this->load->view('front/vendor/login', $data);
        $this->load->view('front/include/footer');
    }
    public function dashboard()
    {
        $this->App->checkVendorAuthenticate();
        $this->session->userdata['vendorauth']['author'];
        $vid=$this->session->userdata['vendorauth']['Id'];
        
        $data['putresult']=$this->App->getPerticularRecord('vendor', 'Id', $vid);
        $this->load->view('front/include/header');
        $this->load->view('front/vendor/dashboard',$data);
        $this->load->view('front/include/footer');
    }
    public function createstep1()
    {
        $this->App->checkVendorAuthenticate();
        $this->session->userdata['vendorauth']['author'];
        $this->session->userdata['vendorauth']['Id'];
        $this->load->view('front/include/header');
        $this->load->view('front/vendor/step1');
        $this->load->view('front/include/footer');
    }
    public function logout()
    {
        $this->session->unset_userdata('vendorauth');
        redirect();
    }
    public function register()
    {
        $this->form_validation->set_rules('lastname', 'Last Name', 'required');
        $this->form_validation->set_rules('clubname', 'Club Name', 'required');
        $this->form_validation->set_rules('firstname', 'First Name', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
        if ($_POST) {
            $email    = $this->input->post('email');
            $chkemail = $this->App->checkExist('vendor', 'Email', $email);
            
            if ($chkemail == '1') {
                
                $err = 'Email Id already Exist.' . '<br>';
            }
            $clbname = $this->input->post('clubname');
            $trim    = trim($clbname);
            $ow      = strtolower($trim);
            $string  = str_replace(' ', '-', $ow);
            $str     = preg_replace('/\s+/', '-', $string);
            $chkslug = $this->App->checkExist('vendor', 'Slug', $str);
            if ($chkslug == '1') {
                $r    = rand(1, 4);
                $slug = $str . $r;
            } else {
                $slug = $str;
            }
            
        }
        if ($this->form_validation->run() == FALSE || $err != '') {
            if (validation_errors() != '' || $err != '') {
                $data['error'] = validation_errors() . $err;
            }
        } else {
            $arr  = array(
                'FirstName' => $this->input->post('firstname'),
                'LastName' => $this->input->post('lastname'),
                'ClubName' => $this->input->post('clubname'),
                'Email' => $this->input->post('email'),
                'Created' => date('Y-m-d'),
                'Status' => '0',
                'Slug' => $slug
            );
            $iid  = $this->App->insertdata('vendor', $arr);
            $name = $this->input->post('firstname') . ' ' . $this->input->post('lastname');
            
            
            $email   = $this->input->post('email');
            $url     = base_url('vendor/resetpassword/' . $iid);
            $message = '<div style="background-color: #fff; margin: 40px; font: 13px/20px normal Helvetica, Arial, sans-serif;color: #4F5155;">
                        <div id="container" style="margin: 10px;border: 1px solid #D0D0D0;box-shadow: 0 0 8px #D0D0D0;">
                        <h1 style="color: #fff;background-color: #333;border-bottom: 1px solid #D0D0D0; font-size: 19px;font-weight: normal;margin: 0 0 14px 0;padding: 14px 15px 10px 15px; text-align: center;background: #333;">Tablefast.com</h1>
                        <div id="body" style="margin: 0 15px 0 15px;text-align: center;">
                        <h3 style="text-align:center">Thank you for Register</h3>
                        <p style="text-align:left">Dear ' . $name . ' <br><br>
                         Welcome to Tablefast.com and thanks for beginning the registration process.<br>
                         <br>We will get back to soon.
                         Kind regards,<br><br>
                         The Tablefast.com Team<br><br>
                        </div>
                        <p class="footer" style="font-size: 11px;border-top: 1px solid #D0D0D0; line-height: 32px; padding: 0 10px 0 10px; margin: 20px 0 0 0;text-align: center;background: #333;color: #FFF;">Thank you for working with us. We look forward to seeing you on Tablefast.com.</p>
                        </div></div>';
            
            
            $from_email = "bhavna@cueserve.com";
            $to_email   = $email;
            
            //Load email library 
            $this->load->library('email');
            
            $this->email->from($from_email, 'Tablefast.com');
            $this->email->to($to_email);
            $this->email->subject('Thank you for Register');
            
            $this->email->message($message);
            
            $this->email->send();
            
            
            $chkauth   = $this->App->getPerticularRecord('vendor', 'Id', $iid);
            $arraydata = array(
                'author' => $chkauth[0]['FirstName'] . ' ' . $chkauth[0]['LastName'],
                'Id' => $chkauth[0]['Id'],
                'ClubName' => $chkauth[0]['ClubName'],
                'Email' => $chkauth[0]['Email']
            );
            
            $this->session->set_userdata('vendorauth', $arraydata);
            redirect('vendor/createstep1');
            
            $data['success'] = 'Thank you for register.';            
        }      
        
        $this->load->view('front/include/header');
        $this->load->view('front/vendor/register', $data);
        $this->load->view('front/include/footer');
    }
    public function emailpage()
    {
        $this->load->view('email/register');
    }
    public function step1()
    {        
        $this->form_validation->set_rules('clubname', 'Club Name', 'required');
        $this->form_validation->set_rules('phone', 'Phone', 'required');
        $this->form_validation->set_rules('alphone', 'Phone Name', 'required');
        $this->form_validation->set_rules('city', 'City', 'required');
        $this->form_validation->set_rules('county', 'Country', 'required');
        $this->form_validation->set_rules('postcode', 'Post Code', 'required');
        $this->form_validation->set_rules('ifram', 'Proper Address', 'required');
        $this->form_validation->set_rules('contactname', 'Contact Name', 'required');
        $this->form_validation->set_rules('Address', 'Address', 'required');
        
        if ($_POST) {
            $phone = $this->input->post('phone');
            $chk   = $this->App->checkExist('vendor', 'Phone', $phone);
            if ($chk == '1') {
                $err = 'Phone Number Already Exist';
            }            
            $clbname = $this->input->post('clubname');
            $trim    = trim($clbname);
            $ow      = strtolower($trim);
            $string  = str_replace(' ', '-', $ow);
            $id      = $this->session->userdata['vendorauth']['Id'];
            $str     = preg_replace('/\s+/', '-', $string);
            $chkslug = $this->App->checkExistEdit('vendor', 'Slug', $str, 'Id', $id);
            if ($chkslug == '1') {
                $r    = rand(1, 4);
                $slug = $str . $r;
            } else {
                $slug = $str;
            }            
        }
        if ($this->form_validation->run() == FALSE || $err != '') {
            if (validation_errors() != '' || $err != '') {
                $data['error']       = validation_errors() . $err;
                $data['clubname']    = $this->input->post('clubname');
                $data['phone']       = $this->input->post('phone');
                $data['alphone']     = $this->input->post('alphone');
                $data['city']        = $this->input->post('city');
                $data['county']      = $this->input->post('county');
                $data['postcode']    = $this->input->post('postcode');
                $data['address']     = $this->input->post('Address');
                $data['ifram']       = $this->input->post('ifram');
                $data['contactname'] = $this->input->post('contactname');
            }
        } else {
            $id  = $this->session->userdata['vendorauth']['Id'];
            $arr = array(
                'ClubName' => $this->input->post('clubname'),
                'City' => $this->input->post('city'),
                'Country' => $this->input->post('county'),
                'Phone' => $this->input->post('phone'),
                'AlternativePhone' => $this->input->post('alphone'),
                'PostCode' => $this->input->post('postcode'),
                'AddressIfram' => $this->input->post('ifram'),
                'ContactName' => $this->input->post('contactname'),
                'Address' => $this->input->post('Address'),
                'Slug' => $slug
            );
            $this->App->update('vendor', 'Id', $id, $arr);
            redirect('vendor/step2');
        }
        $this->load->view('front/include/header');
        $this->load->view('front/vendor/step1', $data);
        $this->load->view('front/include/footer');
    }
    public function step2()
    {
        $this->App->checkVendorAuthenticate();
        $this->form_validation->set_rules('Cuisines', 'Cuisines', 'required');
        
        $this->form_validation->set_rules('PerAdultPrice', 'COST FOR TWO', 'required');
        $id = $this->session->userdata['vendorauth']['Id'];
        if (!empty($_FILES['uploadimg']['name'])) {
            $config['upload_path']   = 'assets/clubimage/';
            $config['allowed_types'] = 'jpg|jpeg|png|gif';
            $config['file_name']     = $_FILES['picture']['name'];
            
            //Load upload library and initialize configuration
            $this->load->library('upload', $config);
            $this->upload->initialize($config);
            
            if ($this->upload->do_upload('uploadimg')) {
                $uploadData = $this->upload->data();
                $picture    = $uploadData['file_name'];
            } else {
                $picture = $this->input->post('oldimg');
            }
        } else {
            $picture = $this->input->post('oldimg');
        }
        if ($this->form_validation->run() == FALSE) {
            if (validation_errors() != '') {
                $data['error'] = validation_errors();
            }
        } else {
            $id        = $this->session->userdata['vendorauth']['Id'];
            $arr       = array(
                'VendorId' => $id,
                'Cuisines' => $this->input->post('Cuisines'),
                'PerAdultPrice' => $this->input->post('PerAdultPrice'),
                'MainImage' => $picture,
                'Created' => date('Y-m-d')
            );
            $chktblrec = $this->App->getPerticularRecord('clublayout', 'VendorId', $id);
            if (empty($chktblrec)) {
                $iid = $this->App->insertdata('clublayout', $arr);
            } else {
                $this->App->update('clublayout', 'VendorId', $id, $arr);
            }
            redirect('vendor/step3');            
        }        
        $id                    = $this->session->userdata['vendorauth']['Id'];
        $data['vendordetails'] = $this->App->getPerticularRecord('clublayout', 'VendorId', $id);
        
        $this->load->view('front/include/header');
        $this->load->view('front/vendor/step2', $data);
        $this->load->view('front/include/footer');
    }
    
    public function updatestep1()
    {
        $this->App->checkVendorAuthenticate();
        $this->form_validation->set_rules('clubname', 'Club Name', 'required');
        $this->form_validation->set_rules('phone', 'Phone', 'required');
        $this->form_validation->set_rules('alphone', 'Phone Name', 'required');
        $this->form_validation->set_rules('city', 'City', 'required');
        $this->form_validation->set_rules('county', 'Country', 'required');
        $this->form_validation->set_rules('postcode', 'Post Code', 'required');
        $this->form_validation->set_rules('address', 'Address', 'required');
        $this->form_validation->set_rules('ifram', 'Proper Address', 'required');
        $this->form_validation->set_rules('contactname', 'Contact Name', 'required');
        if ($_POST) {
            $id    = $this->session->userdata['vendorauth']['Id'];
            $phone = $this->input->post('phone');
            $chk   = $this->App->checkExistEdit('vendor', 'Phone', $phone, 'Id', $id);
            
            if ($chk == '1') {
                $err = 'Phone Number Already Exist';
            }
            $clbname = $this->input->post('clubname');
            $trim    = trim($clbname);
            $ow      = strtolower($trim);
            $string  = str_replace(' ', '-', $ow);
            $id      = $this->session->userdata['vendorauth']['Id'];
            $str     = preg_replace('/\s+/', '-', $string);
            $chkslug = $this->App->checkExistEdit('vendor', 'Slug', $str, 'Id', $id);
            if ($chkslug == '1') {
                $r    = rand(1, 4);
                $slug = $str . $r;
            } else {
                $slug = $str;
            }
        }
        if ($this->form_validation->run() == FALSE || $err != '') {
            if (validation_errors() != '' || $err != '') {
                $data['error'] = validation_errors() . $err;
            }
        } else {
            $id  = $this->session->userdata['vendorauth']['Id'];
            $arr = array(
                'ClubName' => $this->input->post('clubname'),
                'City' => $this->input->post('city'),
                'Country' => $this->input->post('county'),
                'Phone' => $this->input->post('phone'),
                'AlternativePhone' => $this->input->post('alphone'),
                'PostCode' => $this->input->post('postcode'),
                'AddressIfram' => $this->input->post('ifram'),
                'ContactName' => $this->input->post('contactname'),
                'Slug' => $slug
            );
            $this->App->update('vendor', 'Id', $id, $arr);
            redirect('vendor/step2');
        }
        $id                    = $this->session->userdata['vendorauth']['Id'];
        $data['vendordetails'] = $this->App->getPerticularRecord('vendor', 'Id', $id);
        
        $this->load->view('front/include/header');
        $this->load->view('front/vendor/editstep1', $data);
        $this->load->view('front/include/footer');
    }
    public function step3()
    {
        $this->App->checkVendorAuthenticate();
        $this->form_validation->set_rules('description', 'Description', 'required');
        $this->form_validation->set_rules('AvailableParking', 'Available Parking', 'required');
        $typeparking = $this->input->post('AvailableParking');
        if ($typeparking == 'paid') {
            $this->form_validation->set_rules('PriceParkingPerhrs', '{Parking Price', 'required');
        }
        if ($_POST) {
            
        }
        if ($this->form_validation->run() == FALSE) {
            if (validation_errors() != '') {
                $data['error'] = validation_errors();
            }
        } else {
            $id  = $this->session->userdata['vendorauth']['Id'];
            $arr = array(
                'Description' => $this->input->post('description'),
                'AvailableParking' => $this->input->post('AvailableParking'),
                'PriceParkingPerhrs' => $this->input->post('PriceParkingPerhrs')
            );
            $this->App->update('clublayout', 'VendorId', $id, $arr);
            redirect('vendor/step4');
        }
        $id                    = $this->session->userdata['vendorauth']['Id'];
        $data['vendordetails'] = $this->App->getPerticularRecord('clublayout', 'VendorId', $id);
        
        $this->load->view('front/include/header');
        $this->load->view('front/vendor/step3', $data);
        $this->load->view('front/include/footer');
    }
    public function step4()
    {
        $this->App->checkVendorAuthenticate();
        $this->form_validation->set_rules('multi', 'Number of tables', 'required');
        
        if ($this->form_validation->run() == FALSE) {
            if (validation_errors() != '') {
                $data['error'] = validation_errors();
            }
        } else {
            $id = $this->session->userdata['vendorauth']['Id'];
            $this->load->library('upload');
            if ($this->input->post('fileSubmit') && !empty($_FILES['userFiles']['name'])) {
                $filesCount = count($_FILES['userFiles']['name']);
                for ($i = 0; $i < $filesCount; $i++) {
                    $_FILES['userFile']['name']     = $_FILES['userFiles']['name'][$i];
                    $_FILES['userFile']['type']     = $_FILES['userFiles']['type'][$i];
                    $_FILES['userFile']['tmp_name'] = $_FILES['userFiles']['tmp_name'][$i];
                    $_FILES['userFile']['error']    = $_FILES['userFiles']['error'][$i];
                    $_FILES['userFile']['size']     = $_FILES['userFiles']['size'][$i];
                    
                    $uploadPath              = 'assets/clubgallery/';
                    $config['upload_path']   = $uploadPath;
                    $config['allowed_types'] = '*';
                    
                    $this->load->library('upload', $config);
                    $this->upload->initialize($config);
                    if ($this->upload->do_upload('userFile')) {
                        $fileData                    = $this->upload->data();
                        $uploadData[$i]['file_name'] = $fileData['file_name'];
                    } else {
                        $data['error'] = $this->upload->display_errors();
                    }
                }
                
                if (!empty($uploadData)) {
                    $c = count($uploadData);
                    for ($i = 0; $i < $c; $i++) {
                        $arr = array(
                            'VendorId' => $id,
                            'Image' => $uploadData[$i]['file_name'],
                            'Created' => date('Y-m-d'),
                            'Status' => '1'
                        );
                        $this->App->insertdata('clubgallery', $arr);
                    }
                    redirect('vendor/step5');
                }
            }
            redirect('vendor/step5');
            
        }
        
        $id                    = $this->session->userdata['vendorauth']['Id'];
        $data['vendordetails'] = $this->App->getPerticularRecord('clubgallery', 'VendorId', $id);
        
        $this->load->view('front/include/header');
        $this->load->view('front/vendor/step4', $data);
        $this->load->view('front/include/footer');
    }
    
    public function step5()
    {
        $this->App->checkVendorAuthenticate();
        $this->form_validation->set_rules('sundayfrom', 'Time', 'required');
        if ($this->form_validation->run() == FALSE) {
            if (validation_errors() != '') {
                $data['error'] = validation_errors();
            }
        } else {
            $id  = $this->session->userdata['vendorauth']['Id'];
            $arr = array(
                
                'SundayFrom' => $this->input->post('sundayfrom'),
                'SundayTo' => $this->input->post('sundayto'),
                'SundayFromClose' => $this->input->post('sundayfromclose'),
                'SundayToClose' => $this->input->post('sundaytoclose'),
                'MondayFrom' => $this->input->post('mondayfrom'),
                'MondayTo' => $this->input->post('mondayto'),
                'MondayFromClose' => $this->input->post('mondayfromclose'),
                'MondayToClose' => $this->input->post('mondaytoclose'),
                'TuesdayFrom' => $this->input->post('tuesdayfrom'),
                'TuesdayTo' => $this->input->post('tuesdayto'),
                'TuesdayFromClose' => $this->input->post('tuesdayfromclose'),
                'TuesdayToClose' => $this->input->post('tuesdaytoclose'),
                'WednesdayFrom' => $this->input->post('wednesdayfrom'),
                'WednesdayTo' => $this->input->post('wednesdayto'),
                'WednesdayFromClose' => $this->input->post('wednesdayfromclose'),
                'WednesdayToClose' => $this->input->post('wednesdaytoclose'),
                'ThursdayFrom' => $this->input->post('thursdayfrom'),
                'ThursdayTo' => $this->input->post('thursdayto'),
                'ThursdayFromClose' => $this->input->post('thursdayfromclose'),
                'ThursdayToClose' => $this->input->post('thursdaytoclose'),
                'FridayFrom' => $this->input->post('fridayfrom'),
                'FridayTo' => $this->input->post('fridayto'),
                'FridayFromClose' => $this->input->post('fridayfromclose'),
                'FridayToClose' => $this->input->post('fridaytoclose'),
                'SaturdayFrom' => $this->input->post('saturdayfrom'),
                'SaturdayTo' => $this->input->post('saturdayto'),
                'SaturdayFromClose' => $this->input->post('saturdayfromclose'),
                'SaturdayToClose' => $this->input->post('saturdaytoclose')
            );
            $this->App->update('clublayout', 'VendorId', $id, $arr);
            redirect('vendor/step6');            
        }
        
        $id                    = $this->session->userdata['vendorauth']['Id'];
        $data['vendordetails'] = $this->App->getPerticularRecord('clublayout', 'VendorId', $id);
        
        $this->load->view('front/include/header');
        $this->load->view('front/vendor/step5', $data);
        $this->load->view('front/include/footer');
    }
    public function deletegallery($id)
    {
        $this->App->checkVendorAuthenticate();
        if ($id != '') {
            $this->App->deletedata('clubgallery', 'Id', $id);
            echo json_encode('1');
        }
        echo json_encode('1');
    }
    
    public function step6()
    {
        $this->App->checkVendorAuthenticate();
        $id = $this->session->userdata['vendorauth']['Id'];
        $cheskk=$this->App->getPerticularRecord('vendor', 'Id', $id);
        $status=$cheskk[0]['Status'];       
        $this->form_validation->set_rules('test', 'test', 'required');
        if ($this->form_validation->run() == FALSE) {
            if (validation_errors() != '') {
                $data['error'] = validation_errors();
            }
        } else {
            $id  = $this->session->userdata['vendorauth']['Id'];
            if($status!=''){
            $s=$status; 
            }else{ $s=$this->input->post('status'); }
          
            $arr = array(
                'Status' => $s,
            );
            $this->App->update('vendor', 'Id', $id, $arr);
            redirect('vendor/complete');
        }
        $id                    = $this->session->userdata['vendorauth']['Id'];
        $data['vendordetails'] = $this->App->getPerticularRecord('vendor', 'Id', $id);
        
        $this->load->view('front/include/header');
        $this->load->view('front/vendor/step6', $data);
        $this->load->view('front/include/footer');
    }
    public function complete()
    {
        $this->App->checkVendorAuthenticate();
        $this->load->view('front/include/header');
        $this->load->view('front/vendor/completeprocess');
        $this->load->view('front/include/footer');
    }
    public function resetpassword($id)
    {
        $data['userIDds'] = $id;
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('cpassword', 'Confirm Password', 'required|matches[password]');
        
        
        $password = $this->input->post('password');
        $jk       = $this->App->password_strength_check($password);
        if ($jk == '0') {
            $err = 'Password must contain A lowercase letter, A capital (uppercase) letter, A number, Minimum 8 characters ';
        }
        if ($this->form_validation->run() == FALSE || $err != '') {
            if (validation_errors() != '' || $err != '') {
                $data['error'] = validation_errors() . $err;
            }
        } else {
            $arr = array(
                'Password' => md5($this->input->post('password'))
            );
            $this->App->update('vendor', 'Id', $id, $arr);            
            $data['success'] = 'Reset Password Successfully. Please Login';            
        }
        
        
        $this->load->view('front/include/header');
        $this->load->view('front/vendor/resetpassword', $data);
        $this->load->view('front/include/footer');
    }
    public function previewclub()
    {
        $this->App->checkVendorAuthenticate();
        $id                    = $this->session->userdata['vendorauth']['Id'];
        $data['vendordetails'] = $this->App->getPerticularRecord('vendor', 'Id', $id);
        $this->load->view('front/include/header');
        $this->load->view('front/vendor/previewclub', $data);
        $this->load->view('front/include/footer');
    }
    public function changepassword()
    {		   
		$uid=$this->session->userdata['vendorauth']['Id'];
		$this->form_validation->set_rules('oldpassword', 'Old Password', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('cpassword', 'Confirm Password', 'required|matches[password]');
        
        $oldpassword = md5($this->input->post('oldpassword'));
        $password = $this->input->post('password');
        $jk       = $this->App->password_strength_check($password);
        if($_POST){			
		  $chkauth  = $this->App->passwordChecking('vendor', 'Id', 'Password', $uid, $oldpassword);
            if ($chkauth == '0') {
                $err1 = ' Password does not match.';
            }            
            
			if ($jk == '0') {
				$err = 'Password must contain A lowercase letter, A capital (uppercase) letter, A number, Minimum 8 characters ';
			}
		}
      
        if ($this->form_validation->run() == FALSE || $err != ''|| $err1 != '') {
            if (validation_errors() != '' || $err != ''|| $err1 != '') {
                $data['error'] = validation_errors() . $err.$err1;
            }
        } else {
            $arr = array(
                'Password' => md5($this->input->post('password'))
            );
            $this->App->update('vendor', 'Id', $uid, $arr);            
            $data['success'] = 'Change Password Successfully.';            
        }
		$this->App->checkVendorAuthenticate();
		$this->load->view('front/include/header');
        $this->load->view('front/vendor/changepassword', $data);
        $this->load->view('front/include/footer');
	}
    
    
    
    
    
    
    public function testmail()
    {
        /*
        $htmlContent = '<h1>HTML email testing by CodeIgniter Email Library</h1>';
        $htmlContent .= '<p>You can use any HTML tags and content in this email.</p>';
        
        $url=base_url('vendor/resetpassword/2');
        $htmlContent .='<a href="'.$url.'" target="_blank">Click here</a>';
        $config['mailtype'] = 'html';
        $this->email->initialize($config);*/
        
        $from_email = "jayapatel@cueserve.com";
        $to_email   = 'rahulcueserve6@gmail.com';
        
        //Load email library 
        $this->load->library('email');
        
        $this->email->from($from_email, 'jaya');
        $this->email->to($to_email);
        $this->email->subject('Email Test');
        $url     = base_url('vendor/resetpassword/2');
        $message = '<div style="background-color: #fff;
                            margin: 40px;
                            font: 13px/20px normal Helvetica, Arial, sans-serif;
                            color: #4F5155;">

                        <div id="container" style="margin: 10px;
                            border: 1px solid #D0D0D0;
                            box-shadow: 0 0 8px #D0D0D0;">
                            <h1 style="color: #fff;
                            background-color: #333;
                            border-bottom: 1px solid #D0D0D0;
                            font-size: 19px;
                            font-weight: normal;
                            margin: 0 0 14px 0;
                            padding: 14px 15px 10px 15px;
                            text-align: center;
                            background: #333;">Table Booking</h1>

                        <div id="body" style="margin: 0 15px 0 15px;text-align: center;">
                                
                            <h3 style="text-align:center">Please confirm your registration</h3>
                                    <p>
                                        Dear ' . $name . ' <br>
                    <br>
                    Welcome to Tablefast.com and thanks for beginning the registration process.<br>
                    <br>To set up a password and access your registration, simply click the button below.<br><br>
                    <a href="' . $url . '" target="_blank">Create Password</a><br>
                    <br>We look forward to working with you!

                    Kind regards,<br><br>
                    The Tablefast.com Team<br><br>
                        </div>

                        <p class="footer" style="font-size: 11px;
                            border-top: 1px solid #D0D0D0;
                            line-height: 32px;
                            padding: 0 10px 0 10px;
                            margin: 20px 0 0 0;
                                    text-align: center;
                                    background: #333;
                                    color: #FFF;">Thank you for working with us. We look forward to seeing you on Tablefast.com.</p>
                    </div>

                    </div>';
        
        $this->email->message($message);        
        //Send mail 
        $this->email->send();
        echo 'send mail';        
    }
    
}

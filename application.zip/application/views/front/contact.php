<!-- start breadcrumb --><script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript">
</script>
<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.min.js"></script>
<section class="breadcrumb_main_area margin-bottom-80">
  <div class="container-fluid">
    <div class="row">
      <div class="breadcrumb_main nice_title">
        <h2>Contact Us
        </h2>
        <!-- special offer start -->
        <div class="special_offer_main">
          <div class="container">
            <div class="special_offer_sub">
              <img src="<?php echo base_url('assets/fronttheme/')?>/img/special-offer-yellow-main.png" alt="imf">
            </div>
          </div>
        </div>         
        <!-- end offer start -->
      </div>
    </div>
  </div>            
</section>
<section class="contact_mail_area margin-bottom-90">
  <div class="container">
    <div class="row">
      <div class="contact_mail">
        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
          <div class="send_mail">
            <div class="section_title margin-bottom-40">
              <h4>send us an email
              </h4>
            </div>
            <form action="<?php echo base_url('contact'); ?>" method="post" name="contactfrm" id="contactfrm">
              <div class="row">
               <?php if(!empty($error)){?>
            <div class="alert alert-danger  alert-dismissible">
              <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
              </a>
              <?php  echo $error;?>
            </div>
            <?php } ?>
            <?php if(!empty($success)){?>
            <div class="alert alert-success  alert-dismissible">
              <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
              </a>
              <?php  echo $success;?>
            </div>
            <?php } ?>
                <div class="col-lg-6 col-md-6">
                  <input type="text" placeholder="First Name *" name="fname"  id="fname">
                </div>
                <div class="col-lg-6 col-md-6">
                  <input type="text" placeholder="Last Name *"  name="lname" id="lname">
                </div>
                <div class="col-lg-6 col-md-6">
                  <input  type="email" placeholder="Your Email Id *"  name="cemail" id="cemail"/>
                </div>
                <div class="col-lg-6 col-md-6"> 
                  <input  type="text" placeholder="Phone Number *"  name="phone" id="phone" maxlength="10" onkeypress="return ValidatePhoneNo()"/>
                </div>
                 <script>
                        function ValidatePhoneNo() {
                          if ((event.keyCode > 47 && event.keyCode < 58) || event.keyCode == 43 || event.keyCode == 32)
                            return event.returnValue;
                          return event.returnValue = '';
                        }
                      </script>
                 <div class="col-lg-12 col-md-12">
                  <input  type="text" placeholder="Subject *"  name="subject" id="subject"/>
                </div>
                <div class="col-lg-12 col-md-12">
                  <textarea name="message" placeholder="Message"  id="message">
                  </textarea>
                </div>
                <div class="col-lg-4 col-md-4">
                  <!-- <a href="#" class="btn btn-warning btn-md"></a> -->
                  <input class="btn btn-warning btn-md" type="submit" name="submit" value="Submit Now" />
                </div>
              </div>
            </form>
             <script>
          //form validation rules
          $("#contactfrm").validate({
            rules: {
				
              fname: "required",
              message: "required",
              lname: "required",
             // cemail: "required",
              subject: "required",
              phone: "required",
            }
            ,
            messages: {
              lname: "Please enter Last Name",
              subject: "Please enter Subject ",
              fname: "Please enter First Name",
             // cemail: "Please enter Email",
              phone: "Please enter Phone",
              message: "Please enter Email",
            }
            ,
            submitHandler: function(form) {
              form.submit();
            }
          }
                                     );
        </script>
          </div>
        </div>
        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
          <div class="contact_info margin-top-65">
            <div class="section_title margin-bottom-45">
              <h4>Contact Info
              </h4>
            </div>
            <ul class="clearul">
              <li>
                <i class="fa fa-map-marker">
                </i>
                St Amsterdam finland, 
                <br>
                United Stats of AKY16 8PN
              </li>
              <li>
                <i class="fa fa-phone">
                </i>
                1234567890
              </li>
              <li>
                <i class="fa fa-envelope-o">
                </i>
                info@tablefast.com
              </li>
            </ul>
            <div class="social_icons clearfix">
              <ul class="clearul">
                <li>
                  <a href="#">
                    <i class="fa fa-facebook">
                    </i>
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i class="fa fa-twitter">
                    </i>
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i class="fa fa-google-plus">
                    </i>
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i class="fa fa-linkedin">
                    </i>
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<style>
.send_mail input, .send_mail textarea { 
     text-transform: none;}
.alert.alert-danger p {
    color:#a94442;
  }
	label.error {
		color: red;
	}
</style>

<!DOCTYPE html>
<html lang="en">

<head>

    <title>Tablefast - Admin - Login</title>
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url('assets/favicon/');?>favicon.ico">
    <!-- Bootstrap -->
    <link href="<?php echo base_url('assets/admintheme');?>/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="<?php echo base_url('assets/admintheme');?>/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="<?php echo base_url('assets/admintheme');?>/vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- Animate.css -->
    <link href="<?php echo base_url('assets/admintheme');?>/vendors/animate.css/animate.min.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="<?php echo base_url('assets/admintheme');?>/build/css/custom.min.css" rel="stylesheet">
    <style>
        input.btn.btn-default.submit {
            margin: 0% 1% 1% 40%;
        }
    </style>
</head>

<body class="login">
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
    <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.min.js"></script>
    <div class="awe-overlay">

        <div class="login_wrapper">
            <div class="animate form login_form" id="loginfrm">
                <section class="login_content">
                    <div><img src="<?php echo base_url('assets/admintheme/logo.png');?>"></div>

                    <form action="<?php echo base_url('Admin');?>" method="post">

                        <h1>Login Form</h1>
                        <?php if(!empty($error)){?>
                            <div class="alert alert-danger  alert-dismissible" id="res">
                                <a onclick="closediv()" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                <?php  echo $error;?>

                            </div>
                            <?php } ?>

                                <?php if(!empty($success)){?>
                                    <div class="alert alert-success  alert-dismissible">
                                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                        <?php  echo $success;?>

                                    </div>
                                    <?php } ?>
                                        <div>
                                            <input type="text" class="form-control" name="username" id="username" placeholder="UserName" required="" />
                                        </div>
                                        <div>
                                            <input type="password" name="password" id="password" class="form-control" placeholder="Password" required="" />
                                        </div>
                                        <div>
                                            <input type="submit" class="btn btn-default submit" name="submit" value="Sign in">
                                        </div>
                    </form>

                </section>
            </div>
        </div>
    </div>
    <script>
        function closediv() {
            $("#res").hide();
        }
    </script>

    <style>
        label.error {
            color: red;
            font-size: 16px;
            font-weight: 300;
        }
        
        div#loginfrm {
            border: 1px solid;
            padding: 16px;
            background: #fff;
        }
        
        .login {
            background: url(<?php echo base_url('assets/fronttheme/img/imgbanner.jpg');
            ?>);
        }
    </style>
</body>

</html>
<section class="contact_us_area content-left">
  <div class="container">
    <div class="contact_us clearfix">
      <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
        <div class="call clearfix">
          <h6>Call Us
          </h6>
          <p>123 456 7890
          </p>
        </div>
      </div>
      <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
        <div class="email_us clearfix">
          <h6>Email us
          </h6>
          <p>info@tablefast.com
          </p>
        </div>
      </div>
      <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
        <div class="news_letter clearfix">
             <div id="errnews" style="font-size: 13px;margin-top: -16px;color: mediumvioletred;  font-weight: bold;"></div>
             <div id="successnews" style="font-size: 13px;margin-top: -16px;color: yellow;  font-weight: bold;"></div>
          <input type="email" placeholder="Enter ID  for Newsletter" id="newsemail" id="newsemail" style="text-transform:none">
          <a onclick="newsletterfrom()" class="btn btn-blue">Subscribe
          </a>
        </div>
      </div>
      <script>
          function newsletterfrom(){
            var eml=$("#newsemail").val();
            var url="<?php echo base_url('front/newsletter');?>";
             if(eml!=''){
             $.ajax({
                            type: 'post',
                            dataType : 'json',
                            url: url,
                            data: "email="+eml,
                            success: function (data) {
                              if(data=='1'){
                                $('#successnews').html('Thank you for subscribe our newsletter.').delay(3000).fadeOut();
                                 document.getElementById("newsemail").value = "";
                               
                              }
                              if(data=='2'){
                                $('#errnews').html('You have already subscribe our Newsletter.').delay(3000).fadeOut();
                              }
                            }
                          });
             }else{
                 $('#errnews').html('Please Enter Valid Email Id').delay(3000).fadeOut();
             }
            
          }
      </script>
      <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
        <div class="social_icons clearfix">
          <ul>
            <li>
              <a href="#">
                <i class="fa fa-facebook">
                </i>
              </a>
            </li>
            <li>
              <a href="#">
                <i class="fa fa-twitter">
                </i>
              </a>
            </li>
            <li>
              <a href="#">
                <i class="fa fa-google-plus">
                </i>
              </a>
            </li>
            <li>
              <a href="#">
                <i class="fa fa-linkedin">
                </i>
              </a>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</section>

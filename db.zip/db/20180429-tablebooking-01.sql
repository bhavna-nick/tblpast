-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 01, 2018 at 03:10 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tablebooking`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `Id` int(11) NOT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `status` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `clubgallery`
--

CREATE TABLE `clubgallery` (
  `Id` int(11) NOT NULL,
  `VendorId` int(11) DEFAULT NULL,
  `Image` varchar(255) DEFAULT NULL,
  `Created` date DEFAULT NULL,
  `Status` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `clublayout`
--

CREATE TABLE `clublayout` (
  `Id` int(11) NOT NULL,
  `VendorId` int(11) DEFAULT NULL,
  `nooftables` varchar(255) DEFAULT NULL,
  `noofpax` varchar(255) DEFAULT NULL,
  `mainimage` varchar(255) DEFAULT NULL,
  `Created` date DEFAULT NULL,
  `Description` text,
  `AvailableParking` varchar(255) DEFAULT NULL,
  `PriceParkingPerhrs` varchar(255) DEFAULT NULL,
  `SundayFrom` varchar(255) DEFAULT NULL,
  `SundayTo` varchar(255) DEFAULT NULL,
  `SundayFromClose` varchar(255) DEFAULT NULL,
  `SundayToClose` varchar(255) DEFAULT NULL,
  `MondayFrom` varchar(255) DEFAULT NULL,
  `MondayTo` varchar(255) DEFAULT NULL,
  `MondayFromClose` varchar(255) DEFAULT NULL,
  `MondayToClose` varchar(255) DEFAULT NULL,
  `TuesdayFrom` varchar(255) DEFAULT NULL,
  `TuesdayTo` varchar(255) DEFAULT NULL,
  `TuesdayFromClose` varchar(255) DEFAULT NULL,
  `TuesdayToClose` varchar(255) DEFAULT NULL,
  `WednesdayFrom` varchar(255) DEFAULT NULL,
  `WednesdayTo` varchar(255) DEFAULT NULL,
  `WednesdayFromClose` varchar(255) DEFAULT NULL,
  `WednesdayToClose` varchar(255) DEFAULT NULL,
  `ThursdayFrom` varchar(255) DEFAULT NULL,
  `ThursdayTo` varchar(255) DEFAULT NULL,
  `ThursdayFromClose` varchar(255) DEFAULT NULL,
  `ThursdayToClose` varchar(255) DEFAULT NULL,
  `FridayFrom` varchar(255) DEFAULT NULL,
  `FridayTo` varchar(255) DEFAULT NULL,
  `FridayFromClose` varchar(255) DEFAULT NULL,
  `FridayToClose` varchar(255) DEFAULT NULL,
  `SaturdayFrom` varchar(255) DEFAULT NULL,
  `SaturdayTo` varchar(255) DEFAULT NULL,
  `SaturdayFromClose` varchar(255) DEFAULT NULL,
  `SaturdayToClose` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `Id` int(11) NOT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Phone` varchar(50) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `Fbloginkey` varchar(255) DEFAULT NULL,
  `Gploginkey` varchar(255) DEFAULT NULL,
  `Status` int(5) DEFAULT NULL,
  `Created` date DEFAULT NULL,
  `FirstName` varchar(255) DEFAULT NULL,
  `LastName` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vendor`
--

CREATE TABLE `vendor` (
  `Id` int(11) NOT NULL,
  `FirstName` varchar(255) DEFAULT NULL,
  `LastName` varchar(255) DEFAULT NULL,
  `ClubName` varchar(255) DEFAULT NULL,
  `City` varchar(255) DEFAULT NULL,
  `State` varchar(255) DEFAULT NULL,
  `Country` varchar(255) DEFAULT NULL,
  `Phone` varchar(40) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `Created` date DEFAULT NULL,
  `Status` int(5) DEFAULT NULL,
  `PaymentStatus` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `AlternativePhone` varchar(50) DEFAULT NULL,
  `PostCode` varchar(50) DEFAULT NULL,
  `AddressIfram` text,
  `ContactName` varchar(255) DEFAULT NULL,
  `Address` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `clubgallery`
--
ALTER TABLE `clubgallery`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `clublayout`
--
ALTER TABLE `clublayout`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `vendor`
--
ALTER TABLE `vendor`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `clubgallery`
--
ALTER TABLE `clubgallery`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `clublayout`
--
ALTER TABLE `clublayout`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vendor`
--
ALTER TABLE `vendor`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

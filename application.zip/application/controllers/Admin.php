<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller
{
    
    public function __construct()
    {
        parent::__construct();
        $this->load->model('App');
        $this->load->helper('new_helper');
        $this->load->library('form_validation');
        $this->load->library('email');
        $this->load->library('session');
    }
    public function index()
    {
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');
        if ($_POST) {
            $username = $this->input->post('username');
            $password = md5($this->input->post('password'));
            $chkauth  = $this->App->passwordChecking('admin', 'UserName', 'Password', $username, $password);
            if ($chkauth == '0') {
                $err = 'Username and Password does not match.';
            }
            
        }
        if ($this->form_validation->run() == FALSE || $err != '') {
            if (validation_errors() != '' || $err != '') {
                $data['error'] = validation_errors() . $err;
            }
        } else {
            if (!empty($chkauth)) {
                
                $arraydata = array(
                    'username' => $chkauth[0]['UserName'],
                    'Id' => $chkauth[0]['Id'],
                    'Email' => $chkauth[0]['Email']
                );
                
                $this->session->set_userdata('adminauth', $arraydata);
                redirect('admin/dashboard');
            }
        }
        $this->load->view('admin/login', $data);
    }
    public function dashboard()
    {
        $this->App->checkAdminAuthenticate();
        $id = $this->session->userdata['adminauth']['Id'];
        $tot = $this->App->getRecord('vendor');
        $data['totalclub'] = count($tot);
        
        $totapprove = $this->App->getPerticularRecord('vendor', 'Status', '2');
        $data['totalApproved'] = count($totapprove);
        
        $totreject = $this->App->getPerticularRecord('vendor', 'Status', '3');
        $data['totalrejected'] = count($totreject);
        
        $tottrash = $this->App->getPerticularRecord('vendor', 'Status', '4');
        $data['totaltrash'] = count($tottrash);
        
        $totdraft = $this->App->getPerticularRecord('vendor', 'Status', '0');
        $data['totaldraft']   = count($totdraft);
        $totPending = $this->App->getPerticularRecord('vendor', 'Status', '1');
        $data['totalPending'] = count($totPending);        
        $this->load->view('admin/dashboard', $data);
        
    }
    public function profile()
    {
        $this->App->checkAdminAuthenticate();
        $this->form_validation->set_rules('Username', 'Username', 'required');
        $this->form_validation->set_rules('Email', 'Email', 'required|valid_email');
        
        if ($this->form_validation->run() == FALSE || $err != '') {
            if (validation_errors() != '' || $err != '') {
                $data['error'] = validation_errors() . $err;
            }
        } else {
            $password = $this->input->post('password');
            if ($password != '') {
                $arr = array(
                    'UserName' => $this->input->post('Username'),
                    'Email' => $this->input->post('Email'),
                    'Password' => md5($this->input->post('password'))
                );
            } else {
                $arr = array(
                    'UserName' => $this->input->post('Username'),
                    'Email' => $this->input->post('Email')
                );
            }
            $id = $this->session->userdata['adminauth']['Id'];
            $this->App->update('admin', 'Id', $id, $arr);            
            $data['success'] = 'Change Profile Successfully.';            
        }
        $id                   = $this->session->userdata['adminauth']['Id'];
        $data['admindetails'] = $this->App->getPerticularRecord('admin', 'Id', $id);
        $this->load->view('admin/profile', $data);
    }
    public function logout()
    {
        $this->session->unset_userdata('adminauth');
        redirect('admin');
    }
    public function listClub()
    {
        $this->App->checkAdminAuthenticate();
        $id = $this->session->userdata['adminauth']['Id'];
        $data['listvendor'] = $this->App->getRecord('vendor');
        $this->load->view('admin/club/listclub', $data);
    }
    public function approveClub()
    {
        $this->App->checkAdminAuthenticate();
        $id = $this->input->post('id');
        
        $clubdetail = $this->App->getPerticularRecord('Vendor', 'Id', $id);
        $name       = $clubdetail[0]['FirstName'] . ' ' . $clubdetail[0]['LastName'];
        $email      = $clubdetail[0]['Email'];
        $url        = base_url('vendor/resetpassword/' . $id);
        $message    = '<div style="background-color: #fff; margin: 40px; font: 13px/20px normal Helvetica, Arial, sans-serif;color: #4F5155;">
                        <div id="container" style="margin: 10px;border: 1px solid #D0D0D0;box-shadow: 0 0 8px #D0D0D0;">
                        <h1 style="color: #fff;background-color: #333;border-bottom: 1px solid #D0D0D0; font-size: 19px;font-weight: normal;margin: 0 0 14px 0;padding: 14px 15px 10px 15px; text-align: center;background: #333;"><img src="http://tablefast.cueserve.com/assets/fronttheme/img/footer-logo-one.png"></h1>
                        <div id="body" style="margin: 0 15px 0 15px;text-align: center;">
                        <p style="text-align:left">Dear ' . $name . ' <br><br>
                         Congratulations! Your club is Approved. You just signed your Accommodation Agreement 
                         with Tablefast.com. <br>
                         <br>Thank you for partnering with Tablefast.com.<br><br>
                         <a href="' . $url . '" target="_blank">Reset 
                         Password For Login</a><br>
                        <br>Kind regards,<br><br>
                         The Tablefast.com Team<br><br>
                        </div>
                        <p class="footer" style="font-size: 11px;border-top: 1px solid #D0D0D0; line-height: 32px; padding: 0 10px 0 10px; margin: 20px 0 0 0;text-align: center;background: #333;color: #FFF;">Thank you for working with us. We look forward to seeing you on Tablefast.com.</p>
                        </div></div>';
        
        
        $from_email = "bhavna@cueserve.com";
        $to_email   = $email;        
        //Load email library 
        $this->load->library('email');
        
        $this->email->from($from_email, 'Tablefast.com');
        $this->email->to($to_email);
        $this->email->subject('Thank you for partnering with Tablefast.com');
        
        $this->email->message($message);
        
        $this->email->send();
        
        $arr = array(
            'Status' => '2'
        );
        $this->App->update('vendor', 'Id', $id, $arr);
        return 1;
    }
    public function rejectClub()
    {
        $this->App->checkAdminAuthenticate();
        $id         = $this->input->post('id');
        $arr        = array(
            'Status' => '3'
        );
        $clubdetail = $this->App->getPerticularRecord('Vendor', 'Id', $id);
        $name       = $clubdetail[0]['FirstName'] . ' ' . $clubdetail[0]['LastName'];
        $email      = $clubdetail[0]['Email'];
        $url        = base_url('vendor/resetpassword/' . $id);
        $message    = '<div style="background-color: #fff; margin: 40px; font: 13px/20px normal Helvetica, Arial, sans-serif;color: #4F5155;">
                        <div id="container" style="margin: 10px;border: 1px solid #D0D0D0;box-shadow: 0 0 8px #D0D0D0;">
                        <h1 style="color: #fff;background-color: #333;border-bottom: 1px solid #D0D0D0; font-size: 19px;font-weight: normal;margin: 0 0 14px 0;padding: 14px 15px 10px 15px; text-align: center;background: #333;"><img src="http://tablefast.cueserve.com/assets/fronttheme/img/footer-logo-one.png"></h1>
                        <div id="body" style="margin: 0 15px 0 15px;text-align: center;">
                        <p style="text-align:left">Dear ' . $name . ' <br><br>
                        Sorry, Your club Application is rejected. <br>
                        </div>
                        <p class="footer" style="font-size: 11px;border-top: 1px solid #D0D0D0; line-height: 32px; padding: 0 10px 0 10px; margin: 20px 0 0 0;text-align: center;background: #333;color: #FFF;">Thank you for working with us. We look forward to seeing you on Tablefast.com.</p>
                        </div></div>';
        
        
        $from_email = "bhavna@cueserve.com";
        $to_email   = $email;
        
        //Load email library 
        $this->load->library('email');
        
        $this->email->from($from_email, 'Tablefast.com');
        $this->email->to($to_email);
        $this->email->subject('Reject your Club Application');
        
        $this->email->message($message);
        
        $this->email->send();
        $this->App->update('vendor', 'Id', $id, $arr);
        return 1;
    }
    public function trashClub()
    {
        $this->App->checkAdminAuthenticate();
        $id  = $this->input->post('id');
        $arr = array(
            'Status' => '4'
        );
        $this->App->update('vendor', 'Id', $id, $arr);
        return 1;
    }
    public function deleteClub()
    {
        $this->App->checkAdminAuthenticate();
        $id = $this->input->post('id');
        $this->App->deletedata('vendor', 'Id', $id);
        $this->App->deletedata('foodcategory', 'ClubId', $id);
        $this->App->deletedata('fooditem', 'ClubId', $id);
        $this->App->deletedata('clubgallery', 'Vendorid', $id);
        $this->App->deletedata('clublayout', 'Vendorid', $id);
        return 1;
    }
    public function trashClubList()
    {
        $this->App->checkAdminAuthenticate();
        $data['listvendor'] = $this->App->getPerticularRecord('vendor', 'Status', '4');
        $this->load->view('admin/club/trashclublist', $data);
    }
    public function viewclub($id = '')
    {
        $this->App->checkAdminAuthenticate();
        $data['clubidget']=$id;
        $data['vendordetails'] = $this->App->getPerticularRecord('vendor', 'Id', $id);
        $this->load->view('admin/club/viewclub', $data);
    }
    public function listcategory(){
        $this->App->checkAdminAuthenticate();
        $id = $this->session->userdata['adminauth']['Id'];
        $data['listcategory'] = $this->App->getRecord('foodcategory');
        $this->load->view('admin/club/listfoodcategory', $data);
    }
    public function listcategoryitem(){
        $this->App->checkAdminAuthenticate();
        $id = $this->session->userdata['adminauth']['Id'];
        $data['listcategory'] = $this->App->getRecord('fooditem');
        $this->load->view('admin/club/listfooditem', $data);
    }
    public function deletecategory()
    {
        $this->App->checkAdminAuthenticate();
        $id = $this->input->post('id');
        $this->App->deletedata('foodcategory', 'Id', $id);
        $this->App->deletedata('fooditem', 'CategoryId', $id);
        return 1;
    }
    public function deletecategoryitem()
    {
        $this->App->checkAdminAuthenticate();
        $id = $this->input->post('id');
        $this->App->deletedata('fooditem', 'Id', $id);
        return 1;
    }
    public function eventdetail($slug)
    {
        $this->App->checkAdminAuthenticate();
        $data['eventdetails'] = $this->App->getPerticularRecord('events', 'Slug', $slug);
        $this->load->view('admin/club/viewevent', $data);
    }
    public function deleteevent()
    {
        $this->App->checkAdminAuthenticate();
        $id = $this->input->post('id');
        $this->App->deletedata('events', 'Id', $id);
        return 1;
    }
    public function listevents()
    {
		$this->App->checkAdminAuthenticate();
        $id = $this->session->userdata['adminauth']['Id'];
        $data['listevents'] = $this->App->getRecord('events');
        $this->load->view('admin/club/listevents', $data);
	}
	public function listcontact()
    {
		$this->App->checkAdminAuthenticate();
        $id = $this->session->userdata['adminauth']['Id'];
        $data['listcontact'] = $this->App->getRecord('contact');
        $this->load->view('admin/listcontacts', $data);
	}
	public function deletecontact()
    {
        $this->App->checkAdminAuthenticate();
        $id = $this->input->post('id');
        $this->App->deletedata('contact', 'Id', $id);
        return 1;
    }
	public function listnewsletter()
    {
		$this->App->checkAdminAuthenticate();
        $id = $this->session->userdata['adminauth']['Id'];
        $data['listnewsletter'] = $this->App->getRecord('newsletter');
        $this->load->view('admin/listnewsletter', $data);
	}
	public function deletenewsletter()
    {
        $this->App->checkAdminAuthenticate();
        $id = $this->input->post('id');
        $this->App->deletedata('newsletter', 'Id', $id);
        return 1;
    }
    
}

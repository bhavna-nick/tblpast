<!-- start breadcrumb -->
<section class="breadcrumb_main_area margin-bottom-80">
  <div class="container-fluid">
    <div class="row">
      <?php $vid=$vendordetails[0]['Id'];
$layout=$this->App->getPerticularRecord('clublayout','VendorId',$vid);
$img=$layout[0]['MainImage'];
$Description=$layout[0]['Description'];
if($img!=''){
$i=base_url('assets/clubimage/'.$img);
}else{
$i=base_url('assets/fronttheme/img/special-offer-yellow-main.png');
} ?>
      <style>
        .march {
          background:url(<?php echo $i;?>);
          background-repeat: no-repeat;
          background-size:     cover;
        }
      </style>
      <div class="breadcrumb_main nice_title march">
        <h2>
          <?php echo $vendordetails[0]['ClubName'];?>
        </h2>
        <!-- special offer start -->
        <div class="special_offer_main">
          <div class="container">
            <div class="special_offer_sub">
              <?php $vid=$vendordetails[0]['Id'];
$layout=$this->App->getPerticularRecord('clublayout','VendorId',$vid);
$img=$layout[0]['MainImage'];
$Description=$layout[0]['Description'];
if($img!=''){
$i=base_url('assets/clubimage/'.$img);
}else{
$i=base_url('assets/fronttheme/img/special-offer-yellow-main.png');
} ?>
            </div>
          </div>
        </div>         
        <!-- end offer start -->
      </div>
    </div>
  </div>            
</section>
<!-- end breadcrunb -->
<div class="room_detail_main margin-bottom-55">
  <div class="container">
    <div class="row">
      <div class="col-lg-9 col-md-9">
        <div class="deluxe_room_detail">
          <div class="section_title content-left margin-bottom-5">
            <h5>
              <?php echo $vendordetails[0]['ClubName'];?> Detail 
              <span class="price floatright">$ 130
              </span> 
              <br> 
              <span class="day floatright">
              </span>
            </h5>
          </div>
          <div class="section_content">
            <p>Checkout the latest deal
            </p>
            <div class="showcase">
              <div class="section_description">
                <div class="row">
                  <div class="col-lg-12 col-md-12">
                    <div class="clearfix" style="">
                      <ul id="image-gallery" class="gallery list-unstyled cS-hidden">
                        <!-- <ul id="vertical" class="gallery list-unstyled"> -->
                        <?php  $vid=$vendordetails[0]['Id'];
$layout=$this->App->getPerticularRecord('clubgallery','VendorId',$vid);
$imsg=$layout[0]['Image'];
if(!empty($layout)){
foreach($layout as $lay){  ?>
                        <li data-thumb="<?php echo base_url('assets/clubgallery/'.$lay['Image']);?>">
                          <img class="mslider" src="<?php echo base_url('assets/clubgallery/'.$lay['Image']);?>" style="width:100%"/>
                        </li>
                        <?php }
}
?>
                      </ul>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-lg-12 col-md-12">
                    <div class="room_facilities_des padding-top-50 padding-bottom-50 border-bottom-whitesmoke border-top-whitesmoke">
                      <p>
                        <?php echo $Description;?> 
                      </p>
                      <p>
                        <?php $vid=$vendordetails[0]['Id'];
$layout=$this->App->getPerticularRecord('clublayout','VendorId',$vid);
echo 'Available Parking : </span>'.$layout[0]['AvailableParking'];
if($layout[0]['AvailableParking']=='paid'){
echo '<br><span class="a">Parking Price (Per hrs) : </span> Rs '.$layout[0]['PriceParkingPerhrs'];
}?> 
                      </p>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <!-- start welcome section -->
                  <!-- end welcome section -->
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-md-3">
        <!-- start hotel booking -->
        <div class="col-lg-12 col-md-12 col-sm-4 myclspo">
          <div class="hotel_booking_area clearfix myclspo1">
            <div class="hotel_booking">
              <form id="form1" role="form" action="#" class="">
                <div class="col-lg-12 col-md-12">
                  <div class="room_book">
                    <h6>Vendor Details
                    </h6>
                    <p>Club
                    </p>
                  </div>
                </div>
                <?php $vid=$vendordetails[0]['Id'];
$vendordetails=$this->App->getPerticularRecord('vendor','Id',$vid);?>
                <div class="form-group col-lg-12 col-md-12">
                  <div class="input-group border-bottom-dark-2">
                    <br>
                    <label style="    font-size: 20px;    color: whitesmoke;">
                      <?php echo $vendordetails[0]['FirstName'].' '.$vendordetails[0]['LastName'];?>
                    </label>
                    <br>
                    <label>
                      <i class="fa fa-envelope">
                      </i> 
                      <?php echo $vendordetails[0]['Email'];?>
                    </label>
                    <label>
                      <i class="fa fa-phone">
                      </i> 
                      <?php echo $vendordetails[0]['Phone'] .' , '.$vendordetails[0]['AlternativePhone'];?>
                    </label>
                    <br>
                    <label>
                      <i class="fa fa-map-marker">
                      </i> 
                      <?php echo $vendordetails[0]['Address'].' <br> '.$vendordetails[0]['City'].'-'.$vendordetails[0]['PostCode'].' ,'.$vendordetails[0]['Country']; ?>
                    </label>
                    <br>
                    <label>
                      <?php $AddressIfram=$vendordetails[0]['AddressIfram'];
if($AddressIfram!=''){ ?>
                      <iframe width="100%" height="250" frameborder="0" style="border:0" src="https://www.google.com/maps/embed/v1/place?key=AIzaSyAyhF2cCWevFm_T8iog0GqV3utCrfAbWYw&q='<?php echo $AddressIfram;?>'">
                      </iframe>
                      <?php } ?>
                    </label> 
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
        <!-- end hotel booking -->
        <!-- start client says slider -->
        <!-- end client says slider -->
      </div>
    </div>
  </div>
</div>
<div class="room_detail_main margin-bottom-55">
  <div class="container">
    <div class="row">
      <p class="vencls">Time Schedule
      </p>  
      <?php  
$vid=$vendordetails[0]['Id'];
$layout=$this->App->getPerticularRecord('clublayout','VendorId',$vid);
$SundayFrom=$layout[0]['SundayFrom'];
$SundayTo=$layout[0]['SundayTo'];
$SundayFromClose=$layout[0]['SundayFromClose'];
$SundayToClose=$layout[0]['SundayToClose'];
$MondayFrom=$layout[0]['MondayFrom'];
$MondayTo=$layout[0]['MondayTo'];
$MondayFromClose=$layout[0]['MondayFromClose'];
$MondayToClose=$layout[0]['MondayToClose'];
$TuesdayFrom=$layout[0]['TuesdayFrom'];
$TuesdayTo=$layout[0]['TuesdayTo'];
$TuesdayToClose=$layout[0]['TuesdayToClose'];
$WednesdayFrom=$layout[0]['WednesdayFrom'];
$WednesdayTo=$layout[0]['WednesdayTo'];
$WednesdayFromClose=$layout[0]['WednesdayFromClose'];
$WednesdayToClose=$layout[0]['WednesdayToClose'];
$ThursdayFrom=$layout[0]['ThursdayFrom'];
$ThursdayTo=$layout[0]['ThursdayTo'];
$ThursdayFromClose=$layout[0]['ThursdayFromClose'];
$ThursdayToClose=$layout[0]['ThursdayToClose'];
$FridayFrom=$layout[0]['FridayFrom'];
$FridayTo=$layout[0]['FridayTo'];
$FridayFromClose=$layout[0]['FridayFromClose'];
$FridayToClose=$layout[0]['FridayToClose'];
$SaturdayFrom=$layout[0]['SaturdayFrom'];
$SaturdayTo=$layout[0]['SaturdayTo'];
$SaturdayFromClose=$layout[0]['SaturdayFromClose'];
$SaturdayToClose=$layout[0]['SaturdayToClose'];
?>
      <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
        <p class="vencls">Opening Hours: 
        </p>
        <?php /* 
$currentday= date('l');
if($currentday =='Monday'){
echo $MondayFrom.' - '.$MondayTo;
} elseif($currentday =='Tuesday'){
echo $TuesdayFrom.' - '.$TuesdayTo;
}
elseif($currentday =='Wednesday'){
echo $WednesdayFrom.' - '.$WednesdayTo;
}
elseif($currentday =='Thursday'){
echo $ThursdayFrom.' - '.$ThursdayTo;
}
elseif($currentday =='Friday'){
echo $FridayFrom.' - '.$FridayTo;
}
elseif($currentday =='Saturday'){
echo $SaturdayFrom.' - '.$SaturdayTo;
}
elseif($currentday =='Sunday'){
echo $SundayFrom.' - '.$SundayTo;
}
else{
echo $SundayFrom.' - '.$SundayTo;
}*/?>
        <diV class='sd'>
          <label> 
            <span class="a">Monday : 
            </span>  
            <?php echo $MondayFrom; ?> To 
            <?php echo $MondayTo;?>
            <label>
              <span class="a">Thuesday :
              </span> 
              <?php echo $TuesdayFrom;?> To 
              <?php echo $TuesdayTo; ?>
            </label>
            <label>
              <span class="a">Wednesday :
              </span>  
              <?php echo $WednesdayFrom; ?> To 
              <?php echo $WednesdayTo; ?>
            </label>
            <label>
              <span class="a">Thursday :
              </span>  
              <?php echo $ThursdayFrom; ?> To 
              <?php echo $ThursdayTo; ?>
            </label>
            <label>
              <span class="a">Friday :
              </span>  
              <?php echo $FridayFrom; ?> To 
              <?php echo $FridayTo; ?>
            </label>
            <label>
              <span class="a">Saturday :
              </span> 
              <?php echo $SaturdayFrom; ?> To
              <?php echo $SaturdayTo; ?>
            </label>
            <label>
              <span class="a">Sunday :
              </span> 
              <?php echo $SundayFrom; ?> To 
              <?php echo $SundayTo; ?>
            </label>
            </diV>
          </div>
        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
          <p class="vencls">Kitchen Opening Hours:
          </p>
          <diV class='sd'> 
            <label>
              <span class="a">Monday : 
              </span> 
              <?php echo $MondayFromClose; ?> To 
              <?php echo $MondayToClose;?>
            </label>
            <label>
              <span class="a">Thuesday : 
              </span> 
              <?php echo $TuesdayFromClose;?> To 
              <?php echo $TuesdayToClose; ?>
            </label>
            <label>
              <span class="a">Wednesday :
              </span>  
              <?php echo $WednesdayFromClose; ?> To 
              <?php echo $WednesdayToClose; ?>
            </label>
            <label>
              <span class="a">Thursday : 
              </span> 
              <?php echo $ThursdayFromClose; ?> To
              <?php echo $ThursdayToClose; ?>
            </label>
            <label>
              <span class="a">Friday :
              </span>  
              <?php echo $FridayFromClose; ?> To 
              <?php echo $FridayToClose; ?>
            </label>
            <label>
              <span class="a">Saturday :
              </span> 
              <?php echo $SaturdayFromClose; ?> To 
              <?php echo $SaturdayToClose; ?>
            </label>
            <label>
              <span class="a">Sunday : 
              </span> 
              <?php echo $SundayFromClose; ?> To 
              <?php echo $SundayToClose; ?>
            </label>
            </div> 
        </div>
      </div>
    </div>
  </div>
  <!-- start contact us area -->
  <!-- end contact us area -->
  <style>
    .myclspo1 {
      background: #313a45;
    }
    p {
      color: #666666;
      /* font-weight: normal; */
      font-size: 14px;
      font-family: inherit;
      font-weight: normal;
    }
    label {
      font-family: serif;
    }
    span.a {
      COLOR: slategray;
    }
    p.vencls {
      color: navy;
      border-bottom: 1px solid;
      font-weight: bold;
      font-size: 18px;
    }
    label {
      display: table-row;
      color: #ccc;
      font-size: 13px;
      margin: 2px !important;
    }
  </style>

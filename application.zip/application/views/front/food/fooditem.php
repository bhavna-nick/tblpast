<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Tablefast.com
    </title>
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url('assets/favicon/');?>favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- fonts -->
    <link href='http://fonts.googleapis.com/css?family=Playfair+Display:400,700,900' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Karla:700,400' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Lora:400,700' rel='stylesheet' type='text/css'>
    <!-- fontawesome -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/font-awesome.css" />
    <!-- bootstrap -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/bootstrap.min.css" />
    <!-- uikit -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/uikit.min.css" />
    <!-- animate -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/animate.css" />
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/datepicker.css" />
    <!-- Owl carousel 2 css -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/owl.carousel.css">
    <!-- rev slider -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/rev-slider/settings.css" />
    <!-- lightslider -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/lightslider.css">
    <!-- Theme -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/reset.css">
    <!-- custom css -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/style.css" />
    <!-- responsive -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/responsive.css" />
    <link href="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-bs/css/dataTables.bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-buttons-bs/css/buttons.bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-fixedheader-bs/css/fixedHeader.bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-responsive-bs/css/responsive.bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-scroller-bs/css/scroller.bootstrap.min.css" rel="stylesheet">

    <link href="<?php echo base_url('assets/admintheme');?>/build/css/custom.minfront.css" rel="stylesheet">
   
    <?php $s= $this->uri->segment(3);?>
<style>
.pad-30 {
    padding: 6px 9px;
}a.btn.btn-warning.pad-30 {
    padding: 7px 11px;
}
    .form-group.col-lg-6.col-md-6.col-sm-6.icon_arrow1 {
    margin-right: 33px;
}td {
    width: 8%;
}label.error {
    color: red;
    font-size: 13px;
}
</style>
  </head>
  <body  id="accomodation_page">
  <!-- start preloader -->
  <div id="loader-wrapper">
    <div class="logo">
      <a href="#">
        <span>Table
        </span>-Fast
      </a>
    </div>
    <div id="loader">   
    </div>
  </div>
  <?php $this->load->view('front/include/nav');?> 
<section class="breadcrumb_main_area margin-bottom-80">
  <div class="container-fluid">
    <div class="row">
      <div class="breadcrumb_main nice_title">
        <h2> Items
        </h2>
        <!-- special offer start -->
        <div class="special_offer_main">
          <div class="container">
            <div class="special_offer_sub">
              <img src="<?php echo base_url('assets/fronttheme/')?>/img/special-offer-yellow-main.png" alt="imf">
            </div>
          </div>
        </div>         
        <!-- end offer start -->
      </div>
    </div>
  </div>            
</section>
<section class="contact_mail_area margin-bottom-90">
  <div class="container">
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_title">
            <h2 style="font-size:20px ">Items
            </h2>
            <button type="button" class="btn btn-info"  style="float:right;margin-bottom:10px;color:#63c2ea !important" data-toggle="modal" data-target="#myModal" >
              <i class="fa fa-plus"> 
              </i> Add Item  
            </button>
            <br>
            <br>
            <!------------------------------------>
            <!-- Modal -->
            <div class="modal fade" id="myModal" role="dialog">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;
                    </button>
                    <h4 class="modal-title" >Add Item
                    </h4>
                  </div>
                  <div class="modal-body">
                    <form id="demo-form2" method="post" class="form-horizontal form-label-left">
                      <div id="err" style="color:red">
                      </div>
                      <div id="err1" style="color:red">
                      </div>
                      <div class="form-group">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                          <label style="text-align:left">Category
                          </label>
                          <select class="form-control col-md-12 col-xs-12"  id="cattitle" name="cattitle">
                            <option>--Select Category--
                            </option>
                            <?php if(!empty($categorylist)){
foreach($categorylist as $catall){ ?>
                            <option value="<?php echo $catall['Id']?>">
                              <?php echo $catall['Title'];?>
                            </option>
                            <?php }
}?>
                          </select>
                        </div>
                      </div>
                      <div class="form-group">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                          <input id="itemtitle" class="form-control col-md-12 col-xs-12" placeholder="Title" required="required" type="text" name="itemtitle" >
                        </div>
                      </div>
                      <div class="form-group">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                          <input id="price" class="form-control col-md-12 col-xs-12" placeholder="Price" required="required" type="text" name="price" >
                        </div>
                      </div>
                      <div class="ln_solid">
                      </div>
                      <div class="form-group">
                        <div class="col-md-12 col-sm-12 col-xs-12 ">
                          <button type="button" class="btn btn-info" onclick="addcategory()">Submit
                          </button>
                        </div>
                      </div>
                    </form>
                    <script>
                      function addcategory(){
                        var s=$("#cattitle option:selected").val();
                        var itemtitle=$("#itemtitle").val();
                        var price=$("#price").val();
                        var url="<?php echo base_url('food/additem');?>";
                        if(s=='' || itemtitle=='' || price==''){
                          $("#err").html("Please all fields required");
                        }
                        else{
                          $.ajax({
                            type: 'post',
                            dataType : 'json',
                            url: url,
                            data: "category="+s+"&itemtitle="+itemtitle+"&price="+price,
                            success: function (data) {
                              if(data=='1'){
                                alert('Item successfully added.');
                                location.reload();
                              }
                              if(data=='2'){
                                $('#err1').html('Category already Exist.');
                              }
                            }
                          }
                                );
                        }
                      }
                    </script>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!------------------------------------------->
        </div>
        <div class="x_content">
        	
          <table id="datatable-buttons" style="overflow-x: scroll;" class="table table-striped table-bordered" cellspacing="0" width="100%">
            <thead>
              <tr>
                <th>Action
                </th> 
                <th>Category
                </th>
                <th>Item
                </th>
                <th>Price
                </th>
                <th>Status
                </th> 
                <th>Created
                </th>  
              </tr>
            </thead>
            <tbody>
              <?php if(!empty($listcategory)){
foreach($listcategory as $cat){ 
$CategoryId=$cat['CategoryId'];
$catmm= $this->App->getPerticularRecord('foodcategory','Id',$CategoryId);
if($cat['Status']=='1'){ $s='Active';}else{ $s='Inactive';}?>
              <tr>
                <td>
                  <a  class="btn pad-30" style="margin:3px 0px" data-toggle="tooltip" title="Update"  onclick="updatecategory('<?php echo $cat['Id']?>')">
                    <i class="fa fa-edit"> 
                    </i>  
                  </a> 
                  <a  class="btn btn-warning pad-30" style="margin:3px 0px;" data-toggle="tooltip" title="Delete" onclick="deletecategory('<?php echo $cat['Id']?>')">
                    <i class="fa fa-trash"> 
                    </i>  
                  </a> 
                </td>
                <td>
                  <?php echo  $catmm[0]['Title'];?>
                </td>
                <td>
                  <?php echo $cat['Title'];?>
                </td>
                <td>
                  <?php echo 'Rs. '.$cat['Price'];?>
                </td>
                <td>
                  <?php echo $s;?>
                </td>
                <td>
                  <?php echo $cat['Created'];?>
                </td>
              </tr>
              <?php }
} ?>
            </tbody>
          </table>
         
          <script>
            function deletecategory(id){
              var r = confirm("Are You sure want to Trash this Record?");
              var url="<?php echo base_url('food/deleteitem');?>";
              if (r == true) {
                $.ajax({
                  type: 'post',
                  url: url,
                  data: "id="+id,
                  success: function () {
                    alert('Delete Item Successfully');
                    location.reload();
                  }
                }
                      );
              }
            }
            function updatecategory(id){
              var url="<?php echo base_url('food/updateitemfrom');?>";
              $.ajax({
                type: 'post',
                dataType : 'json',
                url: url,
                data: "id="+id,
                success: function (data) {
                  $("#updatediv").html(data);
                  $('#myModal2').modal('show');
                }
              }
                    );
            }
          </script>	
        </div>
      </div>
    </div>
  </div>
  </div>
</div>
</section>
<div id="updatediv">
</div>
<script>
  function editcategory(){
    var s=$("#cattitle1 option:selected").val();
    var itemtitle1=$("#itemtitle1").val();
    var itemid=$("#itemid").val();
    var price1=$("#price1").val();
    var catstatus=$().val("#catstatus option:selected");
    var url="<?php echo base_url('food/edititem');?>";
    if(s=='' || itemtitle1=='' || price1==''){
      $("#err3").html("Please item title required");
    }
    else{
      $.ajax({
        type: 'post',
        dataType : 'json',
        url: url,
        data: "category="+s+"&itemtitle1="+itemtitle1+"&price1="+price1+"&itemid="+itemid+"&catstatus="+catstatus,
        success: function (data) {
          if(data=='1'){
            alert('Item successfully Update.');
            location.reload();
          }
          if(data=='2'){
            $('#err2').html('Item already Exist.');
          }
        }
      }
            );
    }
  }
</script>

<?php $this->load->view('front/include/subfooternav');?>
<footer class="footer_area">
  <div class="container">
    <div class="footer">
      <div class="footer_top padding-top-80 clearfix">
        <div class="col-lg-4 col-md-4 col-sm-4">
          <div class="footer_widget">
            <div class="footer_logo">
              <a href="#">
                <img src="<?php echo base_url('assets/fronttheme/')?>/img/footer-logo-one.png" alt="">
              </a>
            </div>
            <p>Lorem ipsum dolor sit amet, conser adipiscing elit. In consectetur tincidunt dolor.
            </p>
            <ul>
              <li>
                <P>
                  <i class="fa fa-map-marker">
                  </i>St Amsterdam finland, 
                  <br> United Stats of AKY16 8PN
                </P>
              </li>
            </ul>
          </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-4">
          <div class="row">
            <div class="footer_widget clearfix">
              <h5 class="padding-left-15">Quick Links
              </h5>
              <div class="col-lg-6 col-md-6 col-sm-6">
                <ul>
                  <li>
                    <a href="<?php echo base_url();?>">Home
                    </a>
                  </li>
                  <li>
                    <a href="<?php echo base_url('front/allclub');?>">Clubs
                    </a>
                  </li>
                  <li>
                    <a href="<?php echo base_url('about');?>">About Us
                    </a>
                  </li>
                  <li>
                    <a href="<?php echo base_url('contact');?>">Contact
                    </a>
                  </li>
                </ul>  
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-4">
          <div class="footer_widget">
            <h5>We Are Global
            </h5>
            <div class="footer_map">
              <a href="#">
                <img src="<?php echo base_url('assets/fronttheme/')?>/img/footer-map-two.jpg" alt="">
              </a>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="container">
          <div class="footer_copyright margin-tb-50 content-center">
            <p>© 2018 
              <a href="#">Tablefast.com 
              </a>. All rights reserved
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
</footer>
<!-- end footer -->
<!-- jquery library -->
<script src="<?php echo base_url('assets/fronttheme/')?>/js/vendor/jquery-1.11.2.min.js"></script>
<!-- bootstrap -->
<script src="<?php echo base_url('assets/fronttheme/')?>/js/bootstrap.min.js"></script>

<!-- uikit -->
<script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-scroller/js/dataTables.scroller.min.js"></script>
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/jszip/dist/jszip.min.js"></script>
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/pdfmake/build/vfs_fonts.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="<?php echo base_url('assets/admintheme');?>/build/js/custom.min.js"></script>



<!--Activating WOW Animation only for modern browser-->
<!--[if !IE]><!-->
<script type="text/javascript">new WOW().init();</script>
<script src="<?php echo base_url('assets/fronttheme/')?>/js/main.js"></script>
</body>
</html>


<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Front extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('App');
        $this->load->helper('new_helper');
        $this->load->library('pagination');
        $this->load->helper('url');
    }
    public function index()
    {
        $data['clubs']  = $this->App->getRecordByLimit('vendor', 'Status', '2', '0', '1');
        $data['clubs1'] = $this->App->getRecordByLimit('vendor', 'Status', '2', '1', '1');
        $data['clubs2'] = $this->App->getRecordByLimit('vendor', 'Status', '2', '2', '1');
        
        $data['clubs3rec'] = $this->App->getRecordByLimit('vendor', 'Status', '2', '0', '3');
        
        $data['clubs4rec'] = $this->App->getRecordByLimit('vendor', 'Status', '2', '2', '4');
        $data['Allclub']   = $this->App->getPerticularRecord('vendor', 'Status', '2');
        
        $this->load->view('front/include/header');
        $this->load->view('front/home', $data);
        $this->load->view('front/include/footer');
    }
    public function login()
    {
        $this->load->view('front/include/header');
        $this->load->view('front/login');
        $this->load->view('front/include/footer');
    }
    public function register()
    {
        $this->load->view('front/include/header');
        $this->load->view('front/ragister');
        $this->load->view('front/include/footer');
    }
    public function clubdetails($slug = '')
    {
        /*$data['vendordetails']=$this->App->getPerticularRecord('vendor','Slug',$slug);
        $this->load->view('front/include/header');
        $this->load->view('front/clubdetails',$data);
        $this->load->view('front/include/footer');*/
        
        $data['vendordetails'] = $this->App->getPerticularRecord('vendor', 'Slug', $slug);
        $this->load->view('front/include/header');
        $this->load->view('front/tabclubdetails', $data);
        //$this->load->view('front/viewclubdetails', $data);
        $this->load->view('front/include/footer');
    }
    public function allclub()
    {
        $data['allrec'] = $this->App->getPerticularRecord('vendor', 'Status', '2');
        $data['clubs']  = $this->App->getRecordByLimit('vendor', 'Status', '2', '0', '1');
        $data['clubs1'] = $this->App->getRecordByLimit('vendor', 'Status', '2', '1', '1');
        $data['clubs2'] = $this->App->getRecordByLimit('vendor', 'Status', '2', '2', '1');
        
        $config["base_url"]    = base_url() . "front/allclub/";
        $config["total_rows"]  = $this->App->record_count('vendor');
        $config["per_page"]    = 12;
        $config["uri_segment"] = 3;
        $this->pagination->initialize($config);
        $page            = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $data["results"] = $this->App->fetch_departments('vendor', $config["per_page"], $page);
        $data["links"]   = $this->pagination->create_links();
        
        
        $this->load->view('front/include/header');
        $this->load->view('front/listclub', $data);
        $this->load->view('front/include/footer');
    }
    
    public function autosearch()
    {
        $category = $this->input->post('category');
        $det      = $this->db->query("select * from vendor where Status='2' and (ClubName LIKE '%" . $category . "%' or Address Like '%" . $category . "%')");
       
        $tes      = $det->result_array();
        
        $sd = '<div class="main">';
        if (!empty($tes)) {
            foreach ($tes as $tess) {
                $clv    = $tess['ClubName'];
                $id     = $tess['Id'];
                $city   = $tess['City'];
                $layout = $this->App->getPerticularRecord('clublayout', 'VendorId', $id);
                $img    = $layout[0]['MainImage'];
                $path   = base_url('assets/clubimage/' . $img);
                $sd .= '<a onclick="searchfun(' . $id . ')"><div class="mop"> <img src="' . $path . '" class="imgsearch"> ' . $clv . '</div></a>';
            }            
        }
        $sd .= '</div>';
        $data = $sd;
        echo json_encode($data);
    }
    public function getname()
    {
        $id     = $this->input->post('id');
        $layout = $this->App->getPerticularRecord('vendor', 'Id', $id);
        $nmn    = $layout[0]['ClubName'];
        echo json_encode($nmn);
    }
    public function search()
    {
        $clubname = $this->input->post('clubname');
        $bookdata = $this->input->post('bookdata');
        $adult    = $this->input->post('adult');
        $child    = $this->input->post('child');
        
        if ($clubname != '' && $bookdata != '' && $adult != '' && $child != '') {            
            $que               = $this->db->query("select * from vendor where (ClubName Like '%" . $clubname . "%' or Address Like '%" . $clubname . "%') and Status='2'");
            $data['putresult'] = $que->result_array();            
            $que               = $this->db->query("select * from vendor where ClubName<>'" . $clubname . "' and Status='2'");
           // $data['allresult'] = $que->result_array();  
            
        } elseif ($clubname != '' && $bookdata != '' && $adult != '' && $child == '') {
            $que               = $this->db->query("select * from vendor where (ClubName Like '%" . $clubname . "%' or Address Like '%" . $clubname . "%')  and Status='2'");
            $data['putresult'] = $que->result_array();            
            $que               = $this->db->query("select * from vendor where ClubName<>'" . $clubname . "' and Status='2'");
            //$data['allresult'] = $que->result_array();
            
        } elseif ($clubname != '' && $bookdata != '' && $adult == '' || $child == '') {
            $que               = $this->db->query("select * from vendor where (ClubName Like '%" . $clubname . "%' or Address Like '%" . $clubname . "%') and Status='2'");
            $data['putresult'] = $que->result_array();            
            $que               = $this->db->query("select * from vendor where ClubName<>'" . $clubname . "' and Status='2'");
           // $data['allresult'] = $que->result_array();
            
        } elseif ($clubname == '' && $bookdata != '' || $adult == '' || $child == '') {         
            
            $que               = $this->db->query("select * from vendor where Status='2' and (ClubName Like '%" . $clubname . "%' or Address Like '%" . $clubname . "%')");
            $data['putresult'] = $que->result_array();
            
        } else {            
            $que               = $this->db->query("select * from vendor where Status='2' and (ClubName Like '%" . $clubname . "%' or Address Like '%" . $clubname . "%')");
            $data['putresult'] = $que->result_array();   
            
        }       
        
        $this->load->view('front/include/header');
        $this->load->view('front/searchclub', $data);
        $this->load->view('front/include/footer');
    }
    public function detail($slug = '')
    {
        $data['vendordetails'] = $this->App->getPerticularRecord('vendor', 'Slug', $slug);
        $this->load->view('front/include/header');
        //$this->load->view('front/viewclubdetails', $data);
$this->load->view('front/tabclubdetails', $data);
        $this->load->view('front/include/footer');
        
    }
    public function index1()
    {
        echo 'front';
        $this->App->demo();
        echo test_method('Hello World'); // helper method
        $this->load->view('welcome_message');
    }
    public function menu($slug = '')
    {
        $data['vendordetails'] = $this->App->getPerticularRecord('vendor', 'Slug', $slug);
        $vendordetails         = $this->App->getPerticularRecord('vendor', 'Slug', $slug);
        $data['clubid']        = $vendordetails[0]['Id'];
        $this->load->view('front/include/header');
        $this->load->view('front/menu', $data);
        $this->load->view('front/include/footer');
    }
    public function events($slug = '')
    {
        $data['vendordetails'] = $this->App->getPerticularRecord('vendor', 'Slug', $slug);
        $vendordetails         = $this->App->getPerticularRecord('vendor', 'Slug', $slug);
        $data['clubid']        = $vendordetails[0]['Id'];
        $this->load->view('front/include/header');
        $this->load->view('front/events', $data);
        $this->load->view('front/include/footer');
    }
    public function eventdetail($slug=''){
        $data['eventdetails'] = $this->App->getPerticularRecord('events', 'Slug', $slug);
        
        $this->load->view('front/include/header');
        $this->load->view('front/eventdetails', $data);
        $this->load->view('front/include/footer');
    }
    public function gallery($slug = '')
    {
        $data['vendordetails'] = $this->App->getPerticularRecord('vendor', 'Slug', $slug);
        $vendordetails         = $this->App->getPerticularRecord('vendor', 'Slug', $slug);
        $data['clubid']        = $vendordetails[0]['Id'];
        $this->load->view('front/include/header');
        $this->load->view('front/gallery', $data);
        $this->load->view('front/include/footer');
    }
    public function newsletter()
    {
		$email=$this->input->post('email');
		$arr=array('Email'=>$email,
		 'Created'=>date('Y-m-d'),);
 
                  $chk=$this->App->checkExist('newsletter', 'Email', $email);
                  if($chk=='1'){
                        echo json_encode('2');
                 }else{

					 $this->App->insertdata('newsletter',$arr);
					 $message    = '<div style="background-color: #fff; margin: 40px; font: 13px/20px normal Helvetica, Arial, sans-serif;color: #4F5155;">
									<div id="container" style="margin: 10px;border: 1px solid #D0D0D0;box-shadow: 0 0 8px #D0D0D0;">
									<h1 style="color: #fff;background-color: #333;border-bottom: 1px solid #D0D0D0; font-size: 19px;font-weight: normal;margin: 0 0 14px 0;padding: 14px 15px 10px 15px; text-align: center;background: #333;">
									<img src="http://tablefast.cueserve.com/assets/fronttheme/img/footer-logo-one.png">
									</h1>
									<div id="body" style="margin: 0 15px 0 15px;text-align: center;">
									
									Thank You for Subscribe our Newsletter. We will get back to soon. <br>
								   
									
									</div>
									<p class="footer" style="font-size: 11px;border-top: 1px solid #D0D0D0; line-height: 32px; padding: 0 10px 0 10px; margin: 20px 0 0 0;text-align: center;background: #333;color: #FFF;">Thank you for working with us. We look forward to seeing you on Tablefast.com.</p>
									</div></div>';
					
					
					$from_email = "bhavna@cueserve.com";
					$to_email   = $email;        
					//Load email library 
					$this->load->library('email');
					
					$this->email->from($from_email, 'Tablefast.com');
					$this->email->to($to_email);
					$this->email->subject('Thank you for Subscribe with Tablefast.com');
					
					$this->email->message($message);
					
					$this->email->send();
					echo json_encode('1');
          }
        
	}
}

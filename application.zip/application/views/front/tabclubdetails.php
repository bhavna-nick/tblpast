<!-- start breadcrumb -->
<section class="breadcrumb_main_area margin-bottom-80">
  <div class="container-fluid">
    <div class="row">
      <?php $vid=$vendordetails[0]['Id'];
$layout=$this->App->getPerticularRecord('clublayout','VendorId',$vid);
$img=$layout[0]['MainImage'];

    $PerAdultPrice11=$layout[0]['PerAdultPrice'];

$Description=$layout[0]['Description'];
if($img!=''){
$i=base_url('assets/clubimage/'.$img);
}else{
$i=base_url('assets/fronttheme/img/special-offer-yellow-main.png');
} ?>
      <style>
        .march {
          background:url(<?php echo $i;?>);
          background-repeat: no-repeat;
          background-size:     cover;
        }
      </style>
      <div class="breadcrumb_main nice_title march">
        <h2>
          <?php echo $vendordetails[0]['ClubName'];?>
        </h2>
        <!-- special offer start -->
        <div class="special_offer_main">
          <div class="container">
            <div class="special_offer_sub">
              <?php $vid=$vendordetails[0]['Id'];
$layout=$this->App->getPerticularRecord('clublayout','VendorId',$vid);
$img=$layout[0]['MainImage'];
    $Description=$layout[0]['Description'];
    $Cuisines=$layout[0]['Cuisines'];
    $PerAdultPrice=$layout[0]['PerAdultPrice'];
if($img!=''){
$i=base_url('assets/clubimage/'.$img);
}else{
$i=base_url('assets/fronttheme/img/special-offer-yellow-main.png');
} ?>
            </div>
          </div>
        </div>         
        <!-- end offer start -->
      </div>
    </div>
  </div>            
</section>
<!-- end breadcrunb -->
 <!-- start other detect room section -->
        <div class="other_room_area">
            <div class="container">
                <div class="row">
                    <div class="other_room">
                        <div role="tabpanel">
                            <!-- <div class="section_title content-center"> -->

                            <!-- Nav tabs -->
                            <div class="container">
                                <div class="section_title">
                                    <ul class="nav nav-tabs margin-bottom-60" role="tablist">
                                        <li role="presentation" class="active"><a href="#all" aria-controls="all" role="tab" data-toggle="tab">Overview</a></li>
                                        <li role="presentation"><a href="#deluxe_room" aria-controls="deluxe_room" role="tab" data-toggle="tab">Menu</a></li>
                                        <li role="presentation"><a href="#single_bedroom" aria-controls="single_bedroom" role="tab" data-toggle="tab">Events</a></li>
                                        <li role="presentation"><a href="#double_bedroom" aria-controls="double_bedroom" role="tab" data-toggle="tab">Photos</a></li>
                                        <li role="presentation"><a href="#classic_room" aria-controls="classic_room" role="tab" data-toggle="tab">Table Booking</a></li>
                                        <li role="presentation"><a href="#exe_room" aria-controls="exe_room" role="tab" data-toggle="tab">Reviews</a></li>
                                    </ul>
                                </div>
                            </div>

                            <!-- Tab panes -->
                            <div class="tab-content">
                                <!-- <div class="section_content"> -->
                                
                                
                                <div role="tabpanel" class="tab-pane active" id="all">
                                    <!-- start single room details -->
                                    <div class="room_detail_main margin-bottom-55">
											<div class="container">
    <div class="row">
      
      <div class="col-lg-9 col-md-9">
        <div class="deluxe_room_detail">
          <div class="section_title content-left margin-bottom-5">
            <h5>
              <?php echo $vendordetails[0]['ClubName'];?> Detail 
              
             <span class="price floatright"><?php echo '₹ '.$PerAdultPrice;?>
              </span> 
              <br> 
              <span class="day floatright">
              </span>
            </h5>
          </div>
          <div class="section_content">
           
            <div class="showcase">
              <div class="section_description">
                <div class="row">
                  <div class="col-lg-12 col-md-12">
                    <div class="clearfix" style="">
                      <ul id="image-gallery" class="gallery list-unstyled cS-hidden">
                        <!-- <ul id="vertical" class="gallery list-unstyled"> -->
                        <?php  $vid=$vendordetails[0]['Id'];
$layout=$this->App->getPerticularRecord('clubgallery','VendorId',$vid);

$imsg=$layout[0]['Image'];
if(!empty($layout)){
foreach($layout as $lay){  ?>
                        <li data-thumb="<?php echo base_url('assets/clubgallery/'.$lay['Image']);?>">
                          <img class="mslider" src="<?php echo base_url('assets/clubgallery/'.$lay['Image']);?>" style="width:100%"/>
                        </li>
                        <?php }
}
?>
                      </ul>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-lg-12 col-md-12">
                    <div class="room_facilities_des padding-top-50 padding-bottom-50 border-bottom-whitesmoke border-top-whitesmoke">
                      <p>
                          
                          <label style="color: #000;    font-size: 24px;">Cost For Two : 
                          <span style="    font-size: 13px;
                                       color: navy;
                                       font-family: sans-serif;
                                       }">
                            <?php echo '₹ '.$PerAdultPrice;?>
                          </span>
                        </label> 
                        <label style="color: #000;    font-size: 24px;">Cuisines : 
                          <span style="    font-size: 13px;
                                       color: navy;
                                       font-family: sans-serif;
                                       }">
                            <?php echo $Cuisines;?>
                          </span>
                        </label> 
                      </p>
                      <p>
                        <?php echo $Description;?> 
                      </p>
                      <p>
                        <?php $vid=$vendordetails[0]['Id'];
$layout=$this->App->getPerticularRecord('clublayout','VendorId',$vid);
echo 'Available Parking : </span>'.$layout[0]['AvailableParking'];
if($layout[0]['AvailableParking']=='paid'){
echo '<br>Parking Price (Per hrs) : </span> Rs '.$layout[0]['PriceParkingPerhrs'];
}?> 
                      </p>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <!-- start welcome section -->
                  <!-- end welcome section -->
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-md-3">
        <!-- start hotel booking -->
        <div class="col-lg-12 col-md-12 col-sm-4 myclspo">
          <div class="hotel_booking_area clearfix myclspo1">
            <div class="hotel_booking">
              <form id="form1" role="form" action="#" class="">
                <div class="col-lg-12 col-md-12">
                  <div class="room_book">
                    <h6>Vendor Details
                    </h6>
                    <p>Club
                    </p>
                  </div>
                </div>
                <?php $vid=$vendordetails[0]['Id'];
$vendordetails=$this->App->getPerticularRecord('vendor','Id',$vid);?>
                <div class="form-group col-lg-12 col-md-12">
                  <div class="input-group border-bottom-dark-2">
                    <br>
                    <label style="    font-size: 20px;    color: whitesmoke;">
                      <?php echo $vendordetails[0]['FirstName'].' '.$vendordetails[0]['LastName'];?>
                    </label>
                    <br>
                    <label>
                      <i class="fa fa-envelope">
                      </i> 
                      <?php echo $vendordetails[0]['Email'];?>
                    </label>
                    <label>
                      <i class="fa fa-phone">
                      </i> 
                      <?php echo $vendordetails[0]['Phone'] .' , '.$vendordetails[0]['AlternativePhone'];?>
                    </label>
                    <br>
                    <label>
                      <i class="fa fa-map-marker">
                      </i> 
                      <?php echo $vendordetails[0]['Address'].' <br> '.$vendordetails[0]['City'].'-'.$vendordetails[0]['PostCode'].' ,'.$vendordetails[0]['Country']; ?>
                    </label>
                    <br>
                    <label>
                      <?php $AddressIfram=$vendordetails[0]['AddressIfram'];
if($AddressIfram!=''){ ?>
                      <iframe width="100%" height="250" frameborder="0" style="border:0" src="https://www.google.com/maps/embed/v1/place?key=AIzaSyAyhF2cCWevFm_T8iog0GqV3utCrfAbWYw&q='<?php echo $AddressIfram;?>'">
                      </iframe>
                      <?php } ?>
                    </label> 
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
        <!-- end hotel booking -->
        <!-- start client says slider -->
        <!-- end client says slider -->
      </div>
    </div>
    <div class="row">
      <p class="vencls">Opening hours :  
        <?php  
$vid=$vendordetails[0]['Id'];
$layout=$this->App->getPerticularRecord('clublayout','VendorId',$vid);
$SundayFrom=$layout[0]['SundayFrom'];
$SundayTo=$layout[0]['SundayTo'];
$SundayFromClose=$layout[0]['SundayFromClose'];
$SundayToClose=$layout[0]['SundayToClose'];
$MondayFrom=$layout[0]['MondayFrom'];
$MondayTo=$layout[0]['MondayTo'];
$MondayFromClose=$layout[0]['MondayFromClose'];
$MondayToClose=$layout[0]['MondayToClose'];
$TuesdayFrom=$layout[0]['TuesdayFrom'];
$TuesdayTo=$layout[0]['TuesdayTo'];
$TuesdayToClose=$layout[0]['TuesdayToClose'];
$WednesdayFrom=$layout[0]['WednesdayFrom'];
$WednesdayTo=$layout[0]['WednesdayTo'];
$WednesdayFromClose=$layout[0]['WednesdayFromClose'];
$WednesdayToClose=$layout[0]['WednesdayToClose'];
$ThursdayFrom=$layout[0]['ThursdayFrom'];
$ThursdayTo=$layout[0]['ThursdayTo'];
$ThursdayFromClose=$layout[0]['ThursdayFromClose'];
$ThursdayToClose=$layout[0]['ThursdayToClose'];
$FridayFrom=$layout[0]['FridayFrom'];
$FridayTo=$layout[0]['FridayTo'];
$FridayFromClose=$layout[0]['FridayFromClose'];
$FridayToClose=$layout[0]['FridayToClose'];
$SaturdayFrom=$layout[0]['SaturdayFrom'];
$SaturdayTo=$layout[0]['SaturdayTo'];
$SaturdayFromClose=$layout[0]['SaturdayFromClose'];
$SaturdayToClose=$layout[0]['SaturdayToClose'];
?>
        <?php 
$currentday= date('l');
if($currentday =='Monday'){
echo $MondayFrom.' - '.$MondayTo;
} elseif($currentday =='Tuesday'){
echo $TuesdayFrom.' - '.$TuesdayTo;
}
elseif($currentday =='Wednesday'){
echo $WednesdayFrom.' - '.$WednesdayTo;
}
elseif($currentday =='Thursday'){
echo $ThursdayFrom.' - '.$ThursdayTo;
}
elseif($currentday =='Friday'){
echo $FridayFrom.' - '.$FridayTo;
}
elseif($currentday =='Saturday'){
echo $SaturdayFrom.' - '.$SaturdayTo;
}
elseif($currentday =='Sunday'){
echo $SundayFrom.' - '.$SundayTo;
}
else{
echo $SundayFrom.' - '.$SundayTo;
}?>
        <span style="float:right" class="tooltip4">See More
          <span class="tooltiptext">
            <label> Monday : 
              <?php echo $MondayFrom; ?> To 
              <?php echo $MondayTo;?>
              <label>Thuesday : 
                <?php echo $TuesdayFrom;?> To 
                <?php echo $TuesdayTo; ?>
              </label>
              <label>Wednesday :
                <?php echo $WednesdayFrom; ?> To 
                <?php echo $WednesdayTo; ?>
              </label>
              <label>Thursday : 
                <?php echo $ThursdayFrom; ?> To 
                <?php echo $ThursdayTo; ?>
              </label>
              <label>Friday : 
                <?php echo $FridayFrom; ?> To 
                <?php echo $FridayTo; ?>
              </label>
              <label>Saturday : 
                <?php echo $SaturdayFrom; ?> To
                <?php echo $SaturdayTo; ?>
              </label>
              <label>Sunday : 
                <?php echo $SundayFrom; ?> To 
                <?php echo $SundayTo; ?>
              </label>
              </span>
          </span>  
          </p>
    </div>
  </div>
</div>

										</div>  
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                <div role="tabpanel" class="tab-pane" id="deluxe_room">
                                    <!-- start single room details -->
                                    <div class="room_detail_main margin-bottom-55">
  <div class="container">
    <div class="row">
      
      <div class="col-lg-9 col-md-9">
        <div class="deluxe_room_detail">
          <div class="section_title content-left margin-bottom-5">
            <h5>
              <?php echo $vendordetails[0]['ClubName'];?> Menu 
             
              <br> 
              <span class="day floatright">
              </span>
            </h5>
          </div>
          <?php $clubid=$vendordetails[0]['Id'];
$menucategory =$this->App->passwordChecking('foodcategory','ClubId','Status',$clubid,'1');
if(!empty($menucategory)){
?>
          <div class="bocxcsla">
            <h1 class="menutitle">Menu
            </h1>
            <?php 
$menucategory =$this->App->passwordChecking('foodcategory','ClubId','Status',$clubid,'1');
if(!empty($menucategory)){
foreach($menucategory as $category){
$cattit= $category['Title'];
$cid= $category['Id'];
echo '<h4 class="titmenu">'.$cattit.'</h4>';
$menucategory =$this->App->passwordChecking('fooditem','ClubId','CategoryId',$clubid,$cid);
if(!empty($menucategory)){
echo '<table class="ulc">';
foreach($menucategory as $menu){
if($menu['Status']=='1'){
$menutit=$menu['Title'];
$price=$menu['Price'];
//  echo '<li class="mlk">'.$menutit.' <span class="pricecls">   ₹ '.$price.'</span></li>';
echo '<tr ><td class="mlk">'.$menutit.' </td><td class="pricecls">   ₹ '.$price.'</td></tr>';
}
}
echo '</table>';
}
}
}
?>
          </div>
<?php } ?> <br>
        </div>
      </div>
      <div class="col-lg-3 col-md-3">
        <!-- start hotel booking -->
        <div class="col-lg-12 col-md-12 col-sm-4 myclspo">
          <div class="hotel_booking_area clearfix myclspo1">
            <div class="hotel_booking">
              <form id="form1" role="form" action="#" class="">
                <div class="col-lg-12 col-md-12">
                  <div class="room_book">
                    <h6>Vendor Details
                    </h6>
                    <p>Club
                    </p>
                  </div>
                </div>
                <?php $vid=$vendordetails[0]['Id'];
$vendordetails=$this->App->getPerticularRecord('vendor','Id',$vid);?>
                <div class="form-group col-lg-12 col-md-12">
                  <div class="input-group border-bottom-dark-2">
                    <br>
                    <label style="    font-size: 20px;    color: whitesmoke;">
                      <?php echo $vendordetails[0]['FirstName'].' '.$vendordetails[0]['LastName'];?>
                    </label>
                    <br>
                    <label>
                      <i class="fa fa-envelope">
                      </i> 
                      <?php echo $vendordetails[0]['Email'];?>
                    </label>
                    <label>
                      <i class="fa fa-phone">
                      </i> 
                      <?php echo $vendordetails[0]['Phone'] .' , '.$vendordetails[0]['AlternativePhone'];?>
                    </label>
                    <br>
                    <label>
                      <i class="fa fa-map-marker">
                      </i> 
                      <?php echo $vendordetails[0]['Address'].' <br> '.$vendordetails[0]['City'].'-'.$vendordetails[0]['PostCode'].' ,'.$vendordetails[0]['Country']; ?>
                    </label>
                    <br>
                    <label>
                      <?php $AddressIfram=$vendordetails[0]['AddressIfram'];
if($AddressIfram!=''){ ?>
                      <iframe width="100%" height="250" frameborder="0" style="border:0" src="https://www.google.com/maps/embed/v1/place?key=AIzaSyAyhF2cCWevFm_T8iog0GqV3utCrfAbWYw&q='<?php echo $AddressIfram;?>'">
                      </iframe>
                      <?php } ?>
                    </label> 
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
        <!-- end hotel booking -->
        <!-- start client says slider -->
        <!-- end client says slider -->
      </div>
    </div>
    
  </div>
<style>
  .bocxcsla {
    background: url(<?php echo base_url('assets/menu/menu2.jpg')?>) no-repeat;
    padding: 24px;
    color: #fff;
    text-transform: capitalize;
    font-size: 12px;
    list-style: none;
  }
  h1.menutitle {
    font-size: 35px;
    color: #fff;
    padding: 8px 0px;
    /* border-bottom: 1px solid; */
    font-family: cursive;
  }
  h4.titmenu {
    font-size: 15px;
    color: orange;
    font-weight: bold;
    margin-top: 17px;
  }
  .mlk {
    list-style: none;
    width: 84%;
  }
  .pricecls {
    color: yellow;
  }.myclspo1 {
    background: #313a45;
  }
  p {
    color: #666666;
    /* font-weight: normal; */
    font-size: 14px;
    font-family: inherit;
    font-weight: normal;
  }
  label {
    font-family: serif;
    color: #ccc;
  }
  span.a {
    COLOR: slategray;
  }
</style>
</div>
    <!-- end single room details -->
                                </div>
                                
                                
                                
                                
                                
                                
                                <div role="tabpanel" class="tab-pane" id="single_bedroom">
                                    <!-- start single room details -->
                                    <div class="room_detail_main margin-bottom-55">
  <div class="container">
    <div class="row">
      <div class="col-lg-9 col-md-9">
        <div class="deluxe_room_detail">
          <div class="section_title content-left margin-bottom-5">
            <h5>
              <?php echo $vendordetails[0]['ClubName'];?> Detail 
              <span class="price floatright"><?php echo '₹ '.$PerAdultPrice;?>
              </span> 
              <br> 
              <span class="day floatright">
              </span>
            </h5>
          </div>
            <!-------------------------------------------------------------------->
                   <?php 
                   $clubid=$vendordetails[0]['Id'];
                   $eventsdetails=$this->App->getPerticularRecord('events', 'ClubId', $clubid);
                  
                   if(!empty($eventsdetails)){
                       foreach($eventsdetails as $clb){
                           $img=$clb['Image'];
                     
                ?>
                   <div class="boxclx">
                    <div clas=" row">
                      <div class="col-lg-4 col-md-4 col-sm-12">
                        <div class="mk">
                          <a href="<?php echo base_url('front/eventdetail/'.$clb['Slug']);?>">
                            <?php if($img!=''){ ?>
                            <img src="<?php echo base_url('assets/events/'.$img);?>" alt="" class="ew">
                            <?php }else{ ?>
                            <img src="<?php echo base_url('assets/fronttheme/')?>/img/room-thumb-one.jpg" alt="" class="ew">
                            <?php } ?>
                          </a>
                        </div>
                      </div>
                      <div class="col-lg-8 col-md-8 col-sm-12">
                        <div class="col-md-12">
                          <a href="<?php echo base_url('front/eventdetail/'.$clb['Slug']);?>">
                            <h3 class="titlecls">
                              <?php echo $clb['Title'];?>
                            </h3>
                          </a>
                             </div>
                          <div class="col-md-12">
                              <div class="col-md-8 col-lg-8 col-sm-8 col-xs-12">
                              <p class="col"> 
                            <label style="    font-family: serif;    color: #222;    font-weight: 300;">
                                <i class="fa fa-timer"></i>
                              <?php 
                               if($clb['NoofDays']=='1'){
        $dt=$clb['OneDate'];
    }else{ $dt=$clb['FromDate'].' To '.$clb['ToDate'];}
                              echo '<br>Date : '.$dt.'<br>'; echo 'Time '.$clb['TimeFrom'].' To '.$clb['TimeTo'];
                              echo '<br>Price : ₹ '.$clb['Price'];?>
                            </label>
                          </p>
                              </div>
                              <div class="col-md-4 col-lg-4 col-sm-4 col-xs-12">
                                   
                          <a style="padding: 6px 7px;" href="<?php echo base_url('front/eventdetail/'.$clb['Slug']);?>" class="btn ">Read More
                          </a>
                        
                              </div>
                          </div>
                          <div class="col-md-12">
                          <p class="col"> 
                            <label style="    font-family: serif;    color: #000;    font-weight: 300;">
                              
                              <?php  $big=$clb['Description'];
$small = substr($big, 0, 110);
echo  $small.'...'; ?>
                            </label>
                          </p>	
                          </div>
                        
                       
                     
                          
                          
                          
                    </div>
                  </div>
                  
                </div>
                   <?php   }
                   } ?>
                   <!-------------------------------------------------------------------->
          
        </div>
      </div>
      <div class="col-lg-3 col-md-3">
        <!-- start hotel booking -->
        <div class="col-lg-12 col-md-12 col-sm-4 myclspo">
          <div class="hotel_booking_area clearfix myclspo1">
            <div class="hotel_booking">
              <form id="form1" role="form" action="#" class="">
                <div class="col-lg-12 col-md-12">
                  <div class="room_book">
                    <h6>Vendor Details
                    </h6>
                    <p>Club
                    </p>
                  </div>
                </div>
                <?php $vid=$vendordetails[0]['Id'];
$vendordetails=$this->App->getPerticularRecord('vendor','Id',$vid);?>
                <div class="form-group col-lg-12 col-md-12">
                  <div class="input-group border-bottom-dark-2">
                    <br>
                    <label style="    font-size: 20px;    color: whitesmoke;">
                      <?php echo $vendordetails[0]['FirstName'].' '.$vendordetails[0]['LastName'];?>
                    </label>
                    <br>
                    <label>
                      <i class="fa fa-envelope">
                      </i> 
                      <?php echo $vendordetails[0]['Email'];?>
                    </label>
                    <label>
                      <i class="fa fa-phone">
                      </i> 
                      <?php echo $vendordetails[0]['Phone'] .' , '.$vendordetails[0]['AlternativePhone'];?>
                    </label>
                    <br>
                    <label>
                      <i class="fa fa-map-marker">
                      </i> 
                      <?php echo $vendordetails[0]['Address'].' <br> '.$vendordetails[0]['City'].'-'.$vendordetails[0]['PostCode'].' ,'.$vendordetails[0]['Country']; ?>
                    </label>
                    <br>
                    <label>
                      <?php $AddressIfram=$vendordetails[0]['AddressIfram'];
if($AddressIfram!=''){ ?>
                      <iframe width="100%" height="250" frameborder="0" style="border:0" src="https://www.google.com/maps/embed/v1/place?key=AIzaSyAyhF2cCWevFm_T8iog0GqV3utCrfAbWYw&q='<?php echo $AddressIfram;?>'">
                      </iframe>
                      <?php } ?>
                    </label> 
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
        <!-- end hotel booking -->
        <!-- start client says slider -->
        <!-- end client says slider -->
      </div>
    </div>
    <style>
  .boxclx {
    border: 1px solid #ccc;
    display: inline-block;
    background: whitesmoke;
    padding: 12px;
    border-radius: 8px;
    margin: 1%;
    width:98%
  }
p.col {
    margin: 0px;
    padding: 0px;
}
  h3.titlecls {
    padding-top: 3px;
    font-size:18px;
  }
  .mg {
    border-top: 1px dotted;
    padding: 7px;
    margin-top: 15px;
  }
  .col-md-3.col-lg-3.col-sm-12.mds {
    background: #313a45;
  }
  input#clubname ,input#bookdate {
    background: transparent;
    border: none;
    color:#fff; font-size: 10px;
  }
  img.imgsearch {
    width: 34%;
  }
  .mop {
    border: 1px solid #ccc;
    background: #fff;
    padding: 2px;
    margin: 8px;
  }</style>
  </div>
</div>
     <!-- end single room details -->
                                </div>
                                <div role="tabpanel" class="tab-pane" id="double_bedroom">
                                    <!-- start single room details -->
                                <div class="room_detail_main margin-bottom-55">
  <div class="container">
    <div class="row">
      <div class="col-lg-9 col-md-9">
        <div class="deluxe_room_detail">
          <div class="section_title content-left margin-bottom-5">
            <h5>
              <?php echo $vendordetails[0]['ClubName'];?> Gallery 
              
            </h5><style> img.imgopwn {
    height: 150px;width:100%
}</style>
          </div>
          <div class="section_content">
           <!---------------------------------------------------------->
                                    <div class="accomodation_single_room">
                                        <div class="container">
                                            <div class="row">
                                                <div class="col-lg-9 col-md-9 col-sm-9 col-sm-12">
                                                <?php $clubid =$vendordetails[0]['Id'];
                                               $clubgallery= $this->App->getPerticularRecord('clubgallery', 'VendorId', $clubid);
                                               if(!empty($clubgallery)){
                                                   foreach($clubgallery as $gallery){
                                                      
                                                   
                                               ?>
                                                
                                                <div class="col-lg-4 col-md-4 col-sm-4">
                                                    <div class="single_room_wrapper clearfix">
                                                        <div class="room_wrapper">
                                                            <div class="room_media" style="width:100%">
                                                                <img alt="img" class="imgopwn" src="<?php echo base_url('assets/clubgallery/'.$gallery['Image']);?>" >
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                   <?php }
                                               }?>
                                               
                                               </div> 
                                                <div class="col-lg-3 col-md-3 col-sm-3 col-sm-12 myclspo">
                                                    <div class="hotel_booking_area clearfix myclspo1">
            <div class="hotel_booking">
              <form id="form1" role="form" action="#" class="">
                <div class="col-lg-12 col-md-12">
                  <div class="room_book">
                    <h6>Vendor Details
                    </h6>
                    <p>Club
                    </p>
                  </div>
                </div>
                <?php $vid=$vendordetails[0]['Id'];
$vendordetails=$this->App->getPerticularRecord('vendor','Id',$vid);?>
                <div class="form-group col-lg-12 col-md-12">
                  <div class="input-group border-bottom-dark-2">
                    <br>
                    <label style="    font-size: 20px;    color: whitesmoke;">
                      <?php echo $vendordetails[0]['FirstName'].' '.$vendordetails[0]['LastName'];?>
                    </label>
                    <br>
                    <label>
                      <i class="fa fa-envelope">
                      </i> 
                      <?php echo $vendordetails[0]['Email'];?>
                    </label>
                    <label>
                      <i class="fa fa-phone">
                      </i> 
                      <?php echo $vendordetails[0]['Phone'] .' , '.$vendordetails[0]['AlternativePhone'];?>
                    </label>
                    <br>
                    <label>
                      <i class="fa fa-map-marker">
                      </i> 
                      <?php echo $vendordetails[0]['Address'].' <br> '.$vendordetails[0]['City'].'-'.$vendordetails[0]['PostCode'].' ,'.$vendordetails[0]['Country']; ?>
                    </label>
                    <br>
                    <label>
                      <?php $AddressIfram=$vendordetails[0]['AddressIfram'];
if($AddressIfram!=''){ ?>
                      <iframe width="100%" height="250" frameborder="0" style="border:0" src="https://www.google.com/maps/embed/v1/place?key=AIzaSyAyhF2cCWevFm_T8iog0GqV3utCrfAbWYw&q='<?php echo $AddressIfram;?>'">
                      </iframe>
                      <?php } ?>
                    </label> 
                  </div>
                </div>
              </form>
            </div>
          </div>
                                                </div>
                                                
                                            </div>

                                        </div>
                                    </div>
                                
           <!------------------------------------------------------------->
            
          </div>
        </div>
      </div>
      
    </div>
    
  </div>
</div>
     <!-- end single room details -->
                                </div>
                                <div role="tabpanel" class="tab-pane" id="classic_room">
                                    <!-- start single room details -->
                                   <div class="room_detail_main margin-bottom-55">
  <div class="container">
    <div class="row">
      
      <div class="col-lg-9 col-md-9">
        <div class="deluxe_room_detail">
          <div class="section_title content-left margin-bottom-5">
            <h5>
              <?php echo $vendordetails[0]['ClubName'];?> 
            </h5>
          </div>
          <div class="section_content">
           <!---------------------------------------------------------->
                                    <div class="accomodation_single_room">
                                        <div class="container">
                                            <div class="row">
                                                <div class="col-lg-9 col-md-9 col-sm-9 col-sm-12">
                                                Booking Form
                                               </div> 
                                                <div class="col-lg-3 col-md-3 col-sm-3 col-sm-12 myclspo">
                                                    <div class="hotel_booking_area clearfix myclspo1">
            <div class="hotel_booking">
              <form id="form1" role="form" action="#" class="">
                <div class="col-lg-12 col-md-12">
                  <div class="room_book">
                    <h6>Vendor Details
                    </h6>
                    <p>Club
                    </p>
                  </div>
                </div>
                <?php $vid=$vendordetails[0]['Id'];
$vendordetails=$this->App->getPerticularRecord('vendor','Id',$vid);?>
                <div class="form-group col-lg-12 col-md-12">
                  <div class="input-group border-bottom-dark-2">
                    <br>
                    <label style="    font-size: 20px;    color: whitesmoke;">
                      <?php echo $vendordetails[0]['FirstName'].' '.$vendordetails[0]['LastName'];?>
                    </label>
                    <br>
                    <label>
                      <i class="fa fa-envelope">
                      </i> 
                      <?php echo $vendordetails[0]['Email'];?>
                    </label>
                    <label>
                      <i class="fa fa-phone">
                      </i> 
                      <?php echo $vendordetails[0]['Phone'] .' , '.$vendordetails[0]['AlternativePhone'];?>
                    </label>
                    <br>
                    <label>
                      <i class="fa fa-map-marker">
                      </i> 
                      <?php echo $vendordetails[0]['Address'].' <br> '.$vendordetails[0]['City'].'-'.$vendordetails[0]['PostCode'].' ,'.$vendordetails[0]['Country']; ?>
                    </label>
                    <br>
                    <label>
                      <?php $AddressIfram=$vendordetails[0]['AddressIfram'];
if($AddressIfram!=''){ ?>
                      <iframe width="100%" height="250" frameborder="0" style="border:0" src="https://www.google.com/maps/embed/v1/place?key=AIzaSyAyhF2cCWevFm_T8iog0GqV3utCrfAbWYw&q='<?php echo $AddressIfram;?>'">
                      </iframe>
                      <?php } ?>
                    </label> 
                  </div>
                </div>
              </form>
            </div>
          </div>
                                                </div>
                                                
                                            </div>

                                        </div>
                                    </div>
                                
           <!------------------------------------------------------------->
            
          </div>
        </div>
      </div>
      
    </div>
    
  </div>
</div>

                                    <!-- end single room details -->
                                </div>
                                <div role="tabpanel" class="tab-pane" id="exe_room">
                                    <!-- start single room details -->
                                   <div class="room_detail_main margin-bottom-55">
  <div class="container">
    <div class="row">
     
      <div class="col-lg-9 col-md-9">
        <div class="deluxe_room_detail">
          <div class="section_title content-left margin-bottom-5">
            <h5>
              <?php echo $vendordetails[0]['ClubName'];?> Reviews
              
            </h5>
          </div>
          <div class="section_content">
           <!---------------------------------------------------------->
                                    <div class="accomodation_single_room">
                                        <div class="container">
                                            <div class="row">
                                                <div class="col-lg-9 col-md-9 col-sm-9 col-sm-12">
                                                Reviews List
                                               
                                               </div> 
                                                <div class="col-lg-3 col-md-3 col-sm-3 col-sm-12 myclspo">
                                                    <div class="hotel_booking_area clearfix myclspo1">
            <div class="hotel_booking">
              <form id="form1" role="form" action="#" class="">
                <div class="col-lg-12 col-md-12">
                  <div class="room_book">
                    <h6>Vendor Details
                    </h6>
                    <p>Club
                    </p>
                  </div>
                </div>
                <?php $vid=$vendordetails[0]['Id'];
$vendordetails=$this->App->getPerticularRecord('vendor','Id',$vid);?>
                <div class="form-group col-lg-12 col-md-12">
                  <div class="input-group border-bottom-dark-2">
                    <br>
                    <label style="    font-size: 20px;    color: whitesmoke;">
                      <?php echo $vendordetails[0]['FirstName'].' '.$vendordetails[0]['LastName'];?>
                    </label>
                    <br>
                    <label>
                      <i class="fa fa-envelope">
                      </i> 
                      <?php echo $vendordetails[0]['Email'];?>
                    </label>
                    <label>
                      <i class="fa fa-phone">
                      </i> 
                      <?php echo $vendordetails[0]['Phone'] .' , '.$vendordetails[0]['AlternativePhone'];?>
                    </label>
                    <br>
                    <label>
                      <i class="fa fa-map-marker">
                      </i> 
                      <?php echo $vendordetails[0]['Address'].' <br> '.$vendordetails[0]['City'].'-'.$vendordetails[0]['PostCode'].' ,'.$vendordetails[0]['Country']; ?>
                    </label>
                    <br>
                    <label>
                      <?php $AddressIfram=$vendordetails[0]['AddressIfram'];
if($AddressIfram!=''){ ?>
                      <iframe width="100%" height="250" frameborder="0" style="border:0" src="https://www.google.com/maps/embed/v1/place?key=AIzaSyAyhF2cCWevFm_T8iog0GqV3utCrfAbWYw&q='<?php echo $AddressIfram;?>'">
                      </iframe>
                      <?php } ?>
                    </label> 
                  </div>
                </div>
              </form>
            </div>
          </div>
                                                </div>
                                                
                                            </div>

                                        </div>
                                    </div>
                                
           <!------------------------------------------------------------->
            
          </div>
        </div>
      </div>
      
    </div>
    
  </div>
</div>

                                    <!-- end single room details -->
                                </div>
                                <div role="tabpanel" class="tab-pane" id="royal_room">
                                    <!-- start single room details -->
                                    <div class="accomodation_single_room">
                                        <div class="container">
                                            <div class="row">
                                                <div class="col-lg-3 col-md-3 col-sm-3">
                                                    <div class="single_room_wrapper clearfix">
                                                        <div class="room_wrapper">
                                                            <div class="room_media">
                                                                <a href="img/room-image-fourteen.jpg" data-uk-lightbox="{group:'group1'}" title="Gallery">
                                                                <figure class="uk-overlay uk-overlay-hover">
                                                                    <img alt="img" src="img/room-image-fourteen.jpg" >
                                                                    <div class="uk-overlay-panel uk-overlay-background uk-overlay-icon"></div>
                                                                </figure>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-3 col-md-3 col-sm-3">
                                                    <div class="single_room_wrapper clearfix">
                                                        <div class="room_wrapper">
                                                            <div class="room_media">
                                                                <a href="img/room-image-fifteen.png" data-uk-lightbox="{group:'group1'}" title="Gallery">
                                                                <figure class="uk-overlay uk-overlay-hover">
                                                                    <img alt="img" src="img/room-image-fifteen.png" >
                                                                    <div class="uk-overlay-panel uk-overlay-background uk-overlay-icon"></div>
                                                                </figure>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-3 col-md-3 col-sm-3">
                                                    <div class="single_room_wrapper clearfix">
                                                        <div class="room_wrapper">
                                                            <div class="room_media">
                                                                <a href="img/room-image-sixteen.png" data-uk-lightbox="{group:'group1'}" title="Gallery">
                                                                <figure class="uk-overlay uk-overlay-hover">
                                                                    <img alt="img" src="img/room-image-sixteen.png" >
                                                                    <div class="uk-overlay-panel uk-overlay-background uk-overlay-icon"></div>
                                                                </figure>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-3 col-md-3 col-sm-3">
                                                    <div class="single_room_wrapper clearfix">
                                                        <div class="room_wrapper">
                                                            <div class="room_media">
                                                                <a href="img/room-image-seventeen.png" data-uk-lightbox="{group:'group1'}" title="Gallery">
                                                                <figure class="uk-overlay uk-overlay-hover">
                                                                    <img alt="img" src="img/room-image-seventeen.png" >
                                                                    <div class="uk-overlay-panel uk-overlay-background uk-overlay-icon"></div>
                                                                </figure>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- start pagination -->
                                                <div class="col-lg-12 col-md-12">
                                                    <nav class="text-center margin-top-65 margin-bottom-75">
                                                      <ul class="pagination">
                                                        <li>
                                                          <a href="#" aria-label="Previous">
                                                            <i class="fa fa-angle-left"></i>prev
                                                          </a>
                                                        </li>
                                                        <li><a href="#">1</a></li>
                                                        <li><a href="#">2</a></li>
                                                        <li><a href="#">3</a></li>
                                                        <li><a href="#">4</a></li>
                                                        <li><a href="#">5</a></li>
                                                        <li>
                                                          <a href="#" aria-label="Next">next
                                                            <i class="fa fa-angle-right"></i>
                                                          </a>
                                                        </li>
                                                      </ul>
                                                    </nav>
                                                </div>
                                                <!-- end pagination -->
                                            </div>
                                        </div>
                                    </div>
                                    <!-- end single room details -->
                                </div>
                            </div>
                       
                       
                       
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- end other detect room section -->
<style>
  .tooltip4 {
    position: relative;
    display: inline-block;
    border-bottom: 1px dotted black;
  }
  .tooltip4 .tooltiptext {
    visibility: hidden;
    width: 220px;
    background-color: #555;
    color: #fff;
    text-align: center;
    border-radius: 6px;
    padding: 5px 5px;
    position: absolute;
    z-index: 1;
    bottom: 125%;
    left: -10%;
    margin-left: -140px;
    opacity: 0;
    transition: opacity 0.3s;
  }
  .tooltip4 .tooltiptext::after {
    content: "";
    position: absolute;
    top: 100%;
    left: 50%;
    margin-left: -5px;
    border-width: 5px;
    border-style: solid;
    border-color: #555 transparent transparent transparent;
  }
  .tooltip4:hover .tooltiptext {
    visibility: visible;
    opacity: 1;
  }
</style>      
<!-- start contact us area -->
<!-- end contact us area -->
<style>
.active a {
    font-weight: bold;
    background: #3ac4fa !important;
    color: #fff !important;
}
  .myclspo1 {
    background: #313a45;
  }
  p {
    color: #666666;
    /* font-weight: normal; */
    font-size: 14px;
    font-family: inherit;
    font-weight: normal;
  }
  label {
    font-family: serif;
  }
  span.a {
    COLOR: slategray;
  }
  p.vencls {
    color: navy;
    font-weight: bold;
    font-size: 18px;
  }
  label {
    display: table-row;
    color: #ccc;
    font-size: 13px;
    margin: 2px !important;
  }body#gallery_page .other_room .nav-tabs {
     border-bottom: op !important;
}

</style>

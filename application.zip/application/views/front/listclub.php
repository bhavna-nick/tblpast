<!-- start breadcrumb -->
<section class="breadcrumb_main_area margin-bottom-80">
  <div class="container-fluid">
    <div class="row">
      <div class="breadcrumb_main nice_title">
        <h2>Clubs
        </h2>
        <!-- special offer start -->
        <div class="special_offer_main">
          <div class="container">
            <div class="special_offer_sub">
              <img src="<?php echo base_url('assets/fronttheme/')?>img/special-offer-yellow-main.png" alt="imf">
            </div>
          </div>
        </div>         
        <!-- end offer start -->
      </div>
    </div>
  </div>            
</section>
<!-- end breadcrunb -->
<!-- start Hotel Facilities section -->
<section class="select_room_area padding-top-5 margin-bottom-90">
  <div class="container">
    <div class="row">
      <div class="select_room clearfix">
        <div class="section_title nice_title text-center">
          <h3>Special Tables
          </h3>
        </div>
        <div class="select_room_content clearfix">
          <?php if(!empty($clubs)){
foreach($clubs as $clb){
$cid=$clb['Id'];
$clublayout=$this->App->getPerticularRecord('clublayout','VendorId',$cid);
$img=$clublayout[0]['MainImage'];
$PerAdultPrice=$clublayout[0]['PerAdultPrice'];
?>
          <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12 eightcls">
            <div class="room_thumb eightroom">
              <a href="<?php echo base_url('front/clubdetails/'.$clb['Slug']);?>">
                <?php if($img!=''){ ?>
                <img class="eightimg" src="<?php echo base_url('assets/clubimage/'.$img);?>" alt="">
                <?php }else{ ?>
                <img class="eightimg" src="<?php echo base_url('assets/fronttheme/')?>/img/room-thumb-one.jpg" alt="">
                <?php } ?>
              </a>
              <div class="room_details">
                <div class="about_room floatleft">
                  <div class="room_quality floatleft">
                    <a href="<?php echo base_url('front/clubdetails/'.$clb['Slug']);?>">
                      <h5>
                        <?php echo $clb['ClubName'];?>
                      </h5>
                    </a>
                  </div>
                  <div class="room_rent floatleft">
                    <p><?php echo '₹ '.$PerAdultPrice;?>
                      <span> 
                      </span>
                    </p>
                  </div>
                </div>
                <div class="room_block floatright">
                  <a href="<?php echo base_url('front/clubdetails/'.$clb['Slug']);?>" class="btn btn-black">Book
                  </a>
                </div>
              </div>
            </div>
          </div>
          <?php } } ?>
          <div class="col-lg-4 col-md-4 col-sm-4 col-sx-12 fourcls">
            <?php if(!empty($clubs1)){
foreach($clubs1 as $clb1){
$cid=$clb1['Id'];
$clublayout=$this->App->getPerticularRecord('clublayout','VendorId',$cid);
$img=$clublayout[0]['MainImage'];
$PerAdultPrice=$clublayout[0]['PerAdultPrice'];
?>
            <div class="room_thumb small_room_thumb margin-bottom-35 fourroom1">
              <a href="<?php echo base_url('front/clubdetails/'.$clb1['Slug']);?>">
                <?php if($img!=''){ ?>
                <img src="<?php echo base_url('assets/clubimage/'.$img);?>" alt="" class="uo">
                <?php }else{ ?>
                <img class="uo" src="<?php echo base_url('assets/fronttheme/')?>/img/room-thumb-one.jpg" alt="">
                <?php } ?>
              </a> 
              <div class="room_details">
                <div class="about_room floatleft">
                  <div class="room_quality floatleft">
                    <a href="<?php echo base_url('front/clubdetails/'.$clb1['Slug']);?>">
                      <h5>
                        <?php echo $clb1['ClubName'];?>
                      </h5>
                    </a>
                  </div>
                  <div class="room_rent floatleft">
                    <p><?php echo '₹ '.$PerAdultPrice;?>
                      <span> 
                      </span>
                    </p>
                  </div>
                </div>
                <div class="room_block floatright">
                  <a href="<?php echo base_url('front/clubdetails/'.$clb1['Slug']);?>" class="btn btn-black">Book
                  </a>
                </div>
              </div>
            </div>
            <?php } } 
if(!empty($clubs2)){
foreach($clubs2 as $clb2){
$cid=$clb2['Id'];
$clublayout=$this->App->getPerticularRecord('clublayout','VendorId',$cid);
$img=$clublayout[0]['MainImage'];
$PerAdultPrice=$clublayout[0]['PerAdultPrice'];
?>
            <div class="room_thumb small_room_thumb fourroom1">
              <a href="<?php echo base_url('front/clubdetails/'.$clb2['Slug']);?>">
                <?php if($img!=''){ ?>
                <img src="<?php echo base_url('assets/clubimage/'.$img);?>" alt=""  class="uo">
                <?php }else{ ?>
                <img class="uo" src="<?php echo base_url('assets/fronttheme/')?>/img/room-thumb-one.jpg" alt="">
                <?php } ?>
              </a> 
              <div class="room_details">
                <div class="about_room floatleft">
                  <div class="room_quality floatleft">
                    <a href="<?php echo base_url('front/clubdetails/'.$clb2['Slug']);?>">
                      <h5>
                        <?php echo $clb2['ClubName'];?>
                      </h5>
                    </a>
                  </div>
                  <div class="room_rent floatleft">
                    <p><?php echo '₹ '.$PerAdultPrice;?>
                      <span> 
                      </span>
                    </p>
                  </div>
                </div>
                <div class="room_block floatright">
                  <a href="<?php echo base_url('front/clubdetails/'.$clb2['Slug']);?>" class="btn btn-black">Book
                  </a>
                </div>
              </div>
            </div>
            <?php } } ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- end Hotel Facilities section -->
<!-- start other detect room section -->
<section class="other_room_area">
  <div class="container">
    <div class="row">
      <div class="other_room">
        <div class="section_title nice_title content-center">
          <h3>List of Tables
          </h3>
        </div>
        <div class="section_content">
          <!-- start hotel booking -->
          <!-- end hotel booking -->
          <!-- start single room details -->
          <div class="accomodation_single_room">
            <div class="container">
              <div class="row">
                <?php if(!empty($results)){ 
foreach($results as $clb) {
$cid=$clb['Id'];
$clublayout=$this->App->getPerticularRecord('clublayout','VendorId',$cid);
$img=$clublayout[0]['MainImage'];
$PerAdultPrice=$clublayout[0]['PerAdultPrice'];?>  
                <div class="col-lg-3 col-md-3 col-sm-3 yellowbox">
                  <div class="single_room_wrapper clearfix padding-bottom-30">
                    <figure class="uk-overlay uk-overlay-hover">
                      <div class="room_media mk">
                        <a href="<?php echo base_url('front/clubdetails/'.$clb['Slug']);?>">
                          <?php if($img!=''){ ?>
                          <img src="<?php echo base_url('assets/clubimage/'.$img);?>" alt="" class="ew">
                          <?php }else{ ?>
                          <img src="<?php echo base_url('assets/fronttheme/')?>/img/room-thumb-one.jpg" alt="" class="ew">
                          <?php } ?> 
                          </div>
                        <div class="room_title border-bottom-whitesmoke clearfix">
                          <div class="left_room_title floatleft">
                            <a href="<?php echo base_url('front/clubdetails/'.$clb['Slug']);?>">
                              <h6>
                                <?php echo $clb['ClubName'];?>
                              </h6>
                            </a>
                            <p><?php echo '₹ '.$PerAdultPrice;?>
                              <span>
                              </span>
                            </p>
                          </div>
                          <div class="left_room_title floatright">
                            <a href="<?php echo base_url('front/clubdetails/'.$clb['Slug']);?>" class="btn ">Book
                            </a>
                          </div>
                        </div>
                        <div class="rrt uk-overlay-panel uk-overlay-background single_wrapper_details clearfix animated bounceInDown">
                          <div class="border-dark-1 padding-22 clearfix single_wrapper_details_pad dre">
                            <a href="<?php echo base_url('front/clubdetails/'.$clb['Slug']);?>">
                              <h5>
                                <?php echo $clb['ClubName'];?>
                              </h5>
                            </a>
                            <p>
                              <?php 
$big=$clublayout[0]['Description'];
$small = substr($big, 0, 100);
echo  $small.'...';?>
                            </p>
                            <div class="single_room_cost clearfix">
                              <div class="floatright">
                                <a href="<?php echo base_url('front/clubdetails/'.$clb['Slug']);?>" class="btn ">Book
                                </a>
                              </div>
                            </div>
                          </div>
                        </div>
                        </figure>
                      </div>
                  </div>
                  <?php }
} ?>
                </div>
                <div class="row">
                  <nav class="text-center margin-top-65 margin-bottom-75">
                    <ul class="pagination">
                      <?php echo $links; ?>
                    </ul>
                  </nav> 
                </div>
              </div>
              <!-- end single room details -->
            </div>
          </div>
        </div>
      </div>
      </section>
    <!-- end other detect room section -->
    <!-- start contact us area -->
    <!-- end contact us area -->
    <style>
      .border-dark-1 a {
        text-decoration: none;
      }
      body#accomodation_page .single_wrapper_details .single_room_cost .btn, body#accomodation_page .single_wrapper_details .single_room_cost .floatright .btn {
        margin-bottom: -36px !important;
      }
      body#accomodation_page .single_wrapper_details .single_wrapper_details_pad, body#accomodation_page .single_wrapper_details .single_wrapper_details_pad {
        height: auto;
        width: 100%;
      }
      img.eightimg {
        height: 412px; width: 100%;
      }
      img.rm {
        height: 150px; width: 100%;
      }
      img.uo {
        height: 188px; width: 100%;
      }
      .room_media {
        margin-bottom: 28px;
        text-align: center;
      }
      .padding-22 {
        padding: 27px 22px;
        text-align: justify;
      }
      img.ew {
        height: 150px; width: 100%;
      }
    </style>

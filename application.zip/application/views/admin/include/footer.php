<footer>
  <div class="pull-right">
    Tablefast.com 
  </div>
  <div class="clearfix">
  </div>
</footer>

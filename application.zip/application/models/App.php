<?php
class App extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    
    public function demo()
    {
        echo 'demo';
    }
    public function insertdata($tblname, $array)
    {
        $i = '0';
        $this->db->insert($tblname, $array);
        return $this->db->insert_id();
    }
    public function deletedata($tblname, $para, $value)
    {
        
        $this->db->where($para, $value);
        $this->db->delete($tblname);
    }
    public function update($tblname, $parameter, $value, $arr)
    {
        $this->db->where($parameter, $value);
        $this->db->update($tblname, $arr);
        //echo $this->db->last_query();die;
    }
    public function getRecord($tblname)
    {
        $query = $this->db->get($tblname);
        if (!empty($query)) {
            return $query->result_array();
        }
        return 0;
    }
    public function getPerticularRecord($tblname, $parameter, $value)
    {
        $query = $this->db->query("select * from " . $tblname . " where " . $parameter . " = '" . $value . "'");
        if (!empty($query)) {
            return $query->result_array();
        }
        return 0;
    }
    public function checkExist($tblname, $parameter, $value)
    {
        $query = $this->db->query("select * from " . $tblname . " where " . $parameter . " = '" . $value . "'");
        $query = $query->result_array();
        if (!empty($query)) {
            return 1;
        }
        return 0;
    }
    public function checkExistEdit($tblname, $parameter, $value, $para, $val)
    {
        $query = $this->db->query("select * from " . $tblname . " where " . $parameter . " = '" . $value . "' and " . $para . " <> '" . $val . "'");
        
        $query = $query->result_array();
        if (!empty($query)) {
            return 1;
        }
        return 0;
    }
    public function passwordChecking($tblname, $para1, $para2, $val1, $val2)
    {
        $query       = $this->db->query("select * from " . $tblname . " where " . $para1 . " = '" . $val1 . "' and " . $para2 . " = '" . $val2 . "'");
     
        $queryresult = $query->result_array();
        
        if (!empty($queryresult)) {
            return $queryresult;
        }
        return 0;
    }
    public function checkAdminAuthenticate()
    {
        $username = $this->session->userdata['adminauth']['username'];
        if ($username == '') {
            redirect('Admin');
        }
    }
    public function checkVendorAuthenticate()
    {
        $Id = $this->session->userdata['vendorauth']['Id'];
        if ($Id == '') {
            redirect('Vendor');
        }
    }
    public function getRecordByLimit($tblname, $para1, $val1, $l1, $l2)
    {
        $query       = $this->db->query("select * from " . $tblname . " where " . $para1 . " = '" . $val1 . "' ORDER BY `Id` DESC limit " . $l1 . "," . $l2 . " ");
        $queryresult = $query->result_array();
        
        if (!empty($queryresult)) {
            return $queryresult;
        }
        return 0;
    }
    public function get_data($where, $fields, $limit, $start)
    {
        return $this->get($where, $fields, $limit, $start);
    }    
    public function record_count($tblname)
    {
        return $this->db->count_all($tblname);
    }     
    public function fetch_departments($tblname, $limit, $start)
    {
        $query = $this->db->query("select * from " . $tblname . " where Status='2' ORDER BY `Id` DESC limit " . $start . "," . $limit . "");
        
        if ($query->num_rows() > 0) {
            foreach ($query->result_array() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
    }
    public function password_strength_check($password, $min_len = 8, $max_len = 70, $req_digit = 1, $req_lower = 1, $req_upper = 1, $req_symbol = 1)
    {
        $regex = '/^';
        if ($req_digit == 1) {
            $regex .= '(?=.*\d)';
        } 
        if ($req_lower == 1) {
            $regex .= '(?=.*[a-z])';
        } 
        if ($req_upper == 1) {
            $regex .= '(?=.*[A-Z])';
        } 
        if ($req_symbol == 1) {
            $regex .= '(?=.*[^a-zA-Z\d])';
        } 
        $regex .= '.{' . $min_len . ',' . $max_len . '}$/';
        
        if (preg_match($regex, $password)) {
            return 1;
        } else {
            return 0;
        }
    }
    public function fetch_food($tblname, $limit, $start)
    {
        $query = $this->db->query("select * from " . $tblname . " where Status='1' ORDER BY `Id` DESC limit " . $start . "," . $limit . "");
        
        if ($query->num_rows() > 0) {
            foreach ($query->result_array() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
    }
    public function fetch_fooditem($tblname, $par, $val, $limit, $start)
    {
        $query = $this->db->query("select * from " . $tblname . " where " . $par . "= '" . $val . "' and Status='1' ORDER BY `Id` DESC limit " . $start . "," . $limit . "");
        
        if ($query->num_rows() > 0) {
            foreach ($query->result_array() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
    }    
    
}
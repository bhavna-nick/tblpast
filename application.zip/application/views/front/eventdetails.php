<!-- start breadcrumb -->
<section class="breadcrumb_main_area margin-bottom-80">
  <div class="container-fluid">
    <div class="row">
      <?php $vid=$eventdetails[0]['Id'];
$img=$eventdetails[0]['Image'];
$Description=$eventdetails[0]['Description'];
if($img!=''){
$i=base_url('assets/events/'.$img);
}else{
$i=base_url('assets/fronttheme/img/special-offer-yellow-main.png');
} ?>
      <style>
        .march {
          background:url(<?php echo $i;?>);
          background-repeat: no-repeat;
          background-size:     cover;
        }
      </style>
      <div class="breadcrumb_main nice_title march">
        <h2>
          <?php echo $eventdetails[0]['Title'];?>
        </h2>
        <!-- special offer start -->
        <div class="special_offer_main">
          <div class="container">
            <div class="special_offer_sub">
              <?php $vid=$eventdetails[0]['Id'];
$img=$eventdetails[0]['Image'];
$Description=$layout[0]['Description'];
if($img!=''){
$i=base_url('assets/events/'.$img);
}else{
$i=base_url('assets/fronttheme/img/special-offer-yellow-main.png');
} ?>
            </div>
          </div>
        </div>         
        <!-- end offer start -->
      </div>
    </div>
  </div>            
</section>
<!-- end breadcrunb -->
<div class="room_detail_main margin-bottom-55">
  <div class="container">
    <div class="row">
      <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
        <div class="deluxe_room_detail">
          <div class="section_title content-left margin-bottom-5">
            <h5>
              <?php echo $eventdetails[0]['Title'];?> Detail 
              <span class="price floatright"><?php echo '₹ '.$eventdetails[0]['Price'];?>
              </span> 
              <br> 
              
            </h5>
              <p class="col"> 
                            <label style="    font-family: serif;    color: #222;    font-weight: 300;">
                                <i class="fa fa-timer"></i>
                              <?php 
                               if($eventdetails[0]['NoofDays']=='1'){
        $dt=$eventdetails[0]['OneDate'];
    }else{ $dt=$eventdetails[0]['FromDate'].' To '.$eventdetails[0]['ToDate'];}
                              echo '<br>Date : '.$dt.'<br>'; echo 'Time '.$eventdetails[0]['TimeFrom'].' To '.$eventdetails[0]['TimeTo'];
                              echo '<br>Price : ₹ '.$eventdetails[0]['Price'];?>
                            </label>
                          </p>
                          
                          <p class="col"> 
                            <label style="    font-family: serif;    color: #000;    font-weight: 300;">
                              
                              <?php  echo $eventdetails[0]['Description'];
 ?>
                            </label>
                          </p>	
          </div>
         
        </div>
      </div>
        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
        <div class="customer_says">
          <div class="section_title margin-bottom-50">
            <h5>Latest Events
            </h5>
          </div>
            <?php  $ClubId=$eventdetails[0]['ClubId'];
            $latest=$this->App->getRecordByLimit('events','ClubId',$ClubId,'0','3');
            ?>
          <div class="section_description">
            <div id="customer_says_slider" class="carousel slide" data-ride="carousel" data-pause="none">
              <!-- Wrapper for slides -->
              <div class="carousel-inner" role="listbox">
                  <?php if(!empty($latest)){ $i=1;
                      foreach($latest as $lst){ 
                          if($lst['Status']=='1'){
                          ?>
                <div class="item <?php if($i=='1'){ echo 'active';} ?>">
                  <div class="single_says">
                    <div class="customer_comment">
                      <p>
                       <?php $big=$lst['Description'];
$small = substr($big, 0, 110);
echo  $small.'...'; ?>  </p>
                      
                    </div>
                    <div class="customer_detail clearfix">
                      <div class="customer_pic alignleft-20">
                        <a href="<?php echo base_url('front/eventdetail/'.$lst['Slug']);?>">
                          <img src="<?php echo base_url('assets/events/'.$lst['Image'])?>" alt="" class="smlcls">
                        </a>
                      </div>
                      <div class="customer_identity floatleft">
                       <a href="<?php echo base_url('front/eventdetail/'.$lst['Slug']);?>"> <h6><?php echo $lst['Title'];?>
                           </h6></a>
                        <p><?php  if($lst['NoofDays']=='1'){
        $dt=$lst['OneDate'];
    }else{ $dt=$lst['FromDate'].' To '.$lst['ToDate'];}
                              echo 'Date : '.$dt.'<br>'; echo 'Time '.$lst['TimeFrom'].' To '.$lst['TimeTo'];
                              echo '<br>Price : ₹ '.$lst['Price'];?>
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                          <?php } $i++; }
                  } ?>
                
              </div>
              <!-- Controls -->
              <a class="slider_says left" href="#customer_says_slider" role="button" data-slide="prev">
                <i class="fa fa-angle-left">
                </i>
                <span class="sr-only">Previous
                </span>
              </a>
              <a class="slider_says right" href="#customer_says_slider" role="button" data-slide="next">
                <i class="fa fa-angle-right">
                </i>
                <span class="sr-only">Next
                </span>
              </a>
            </div>
          </div>
        </div>
        </div>
        </div>
  </div>
</div>
 <!-- start contact us area -->
  <!-- end contact us area -->
  <style>
      img.smlcls {
          width:50%;
          padding:4px;height:100px
      }
  </style>

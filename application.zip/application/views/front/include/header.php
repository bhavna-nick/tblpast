<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Tablefast.com
    </title>
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url('assets/favicon/');?>favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- fonts -->
    <link href='http://fonts.googleapis.com/css?family=Playfair+Display:400,700,900' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Karla:700,400' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Lora:400,700' rel='stylesheet' type='text/css'>
    <!-- fontawesome -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/font-awesome.css" />
    <!-- bootstrap -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/bootstrap.min.css" />
    <!-- uikit -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/uikit.min.css" />
    <!-- animate -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/animate.css" />
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/datepicker.css" />
    <!-- Owl carousel 2 css -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/owl.carousel.css">
    <!-- rev slider -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/rev-slider/settings.css" />
    <!-- lightslider -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/lightslider.css">
    <!-- Theme -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/reset.css">
    <!-- custom css -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/style.css" />
    <!-- responsive -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/responsive.css" />
   
    <?php $s= $this->uri->segment(3);?>
  </head>
  <body 
        <?php if(current_url()==base_url()){ echo 'id="home_two"';} elseif(current_url()==base_url('about')){ echo 'id="about_us_page"';}elseif(current_url()==base_url('contact')){ echo 'id="contact_us_page"';}elseif(current_url()==base_url('vendor/dashboard')){ echo 'id="booking_page"';}elseif(current_url()==base_url('vendor/step2')){ echo 'id="booking_page"';}elseif(current_url()==base_url('vendor/updatestep1')){ echo 'id="booking_page"';}elseif(current_url()==base_url('vendor/step1')){ echo 'id="booking_page"';}elseif(current_url()==base_url('vendor/step6')){ echo 'id="booking_page"';}elseif(current_url()==base_url('vendor/step4')){ echo 'id="booking_page"';}elseif(current_url()==base_url('vendor/step3')){ echo 'id="booking_page"';}elseif(current_url()==base_url('vendor/step5')){ echo 'id="booking_page"';} elseif(current_url()==base_url('vendor/complete')){ echo 'id="booking_page"';} elseif(current_url()==base_url('vendor/previewclub')){ echo 'id="room_detail_page"';} elseif(current_url()==base_url('front/allclub')){ echo 'id="accomodation_page"';}elseif(current_url()==base_url('front/allclub/'.$s)){ echo 'id="accomodation_page"';}
  elseif(current_url()==base_url('food/foodcategory')){ echo 'id="accomodation_page"';}elseif(current_url()==base_url('food/fooditem')){ echo 'id="accomodation_page"';}elseif(current_url()==base_url('front/search')){ echo 'id="room_detail_page"';}elseif(current_url()==base_url('front/detail/'.$s)){ echo 'id="gallery_page"';}elseif(current_url()==base_url('front/menu/'.$s)){ echo 'id="gallery_page"';}elseif(current_url()==base_url('food/foodcategory/'.$s)){ echo 'id="accomodation_page"';}elseif(current_url()==base_url('food/fooditem/'.$s)){ echo 'id="accomodation_page"';}
  elseif(current_url()==base_url('events/index/'.$s)){ echo 'id="accomodation_page"';}
  elseif(current_url()==base_url('events')){ echo 'id="accomodation_page"';}
  elseif(current_url()==base_url('events/editevent/'.$s)){ echo 'id="accomodation_page"';}

  elseif(current_url()==base_url('front/clubdetails/'.$s)){ echo 'id="gallery_page"';}
  elseif(current_url()==base_url('vendor/createstep1')){ echo 'id="booking_page"';}
  else{} ?>>
  <!-- start preloader -->
  <div id="loader-wrapper">
    <div class="logo">
      <a href="#">
        <span>Table</span> - Fast
      </a>
    </div>
    <div id="loader">   
    </div>
  </div>
  <?php $this->load->view('front/include/nav');?>

<!-- start breadcrumb -->
<section class="breadcrumb_main_area margin-bottom-80">
  <div class="container-fluid">
    <div class="row">
      <?php $vid=$vendordetails[0]['Id'];
$layout=$this->App->getPerticularRecord('clublayout','VendorId',$vid);
$img=$layout[0]['MainImage'];
$Description=$layout[0]['Description'];

$Cuisines=$layout[0]['Cuisines'];
$PerAdultPrice=$layout[0]['PerAdultPrice'];
if($img!=''){
$i=base_url('assets/clubimage/'.$img);
}else{
$i=base_url('assets/fronttheme/img/special-offer-yellow-main.png');
} ?>
      <style>
        .march {
          background:url(<?php echo $i;?>);
          background-repeat: no-repeat;
          background-size:     cover;
        }
      </style>
      <div class="breadcrumb_main nice_title march">
        <h2>
          <?php echo $vendordetails[0]['ClubName'];?>
        </h2>
        <!-- special offer start -->
        <div class="special_offer_main">
          <div class="container">
            <div class="special_offer_sub">
              <?php $vid=$vendordetails[0]['Id'];
$layout=$this->App->getPerticularRecord('clublayout','VendorId',$vid);
$img=$layout[0]['MainImage'];
$Description=$layout[0]['Description'];
if($img!=''){
$i=base_url('assets/clubimage/'.$img);
}else{
$i=base_url('assets/fronttheme/img/special-offer-yellow-main.png');
} ?>
            </div>
          </div>
        </div>         
        <!-- end offer start -->
      </div>
    </div>
  </div>            
</section>
<!-- end breadcrunb -->
<div class="room_detail_main margin-bottom-55">
  <div class="container">
    <div class="row">
      <div class="col-lg-12 col-md-12">
        <?php  $this->load->view('front/include/tab');?>
      </div>
      <div class="col-lg-9 col-md-9">
        <div class="deluxe_room_detail">
          <div class="section_title content-left margin-bottom-5">
            <h5>
              <?php echo $vendordetails[0]['ClubName'];?> Gallery 
              <span class="price floatright"><?php echo '₹ '.$PerAdultPrice;?>
              </span> 
              
            </h5>
          </div>
          <div class="section_content">
           <!---------------------------------------------------------->
                                    <div class="accomodation_single_room">
                                        <div class="container">
                                            <div class="row">
                                                <div class="col-lg-9 col-md-9 col-sm-9 col-sm-12">
                                                <?php $clubid;
                                               $clubgallery= $this->App->getPerticularRecord('clubgallery', 'VendorId', $clubid);
                                               if(!empty($clubgallery)){
                                                   foreach($clubgallery as $gallery){
                                                      
                                                   
                                               ?>
                                                
                                                <div class="col-lg-4 col-md-4 col-sm-4">
                                                    <div class="single_room_wrapper clearfix">
                                                        <div class="room_wrapper">
                                                            <div class="room_media" style="width:100%">
                                                                <img alt="img" class="imgopwn" src="<?php echo base_url('assets/clubgallery/'.$gallery['Image']);?>" >
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                   <?php }
                                               }?>
                                               
                                               </div> 
                                                <div class="col-lg-3 col-md-3 col-sm-3 col-sm-12 myclspo">
                                                    <div class="hotel_booking_area clearfix myclspo1">
            <div class="hotel_booking">
              <form id="form1" role="form" action="#" class="">
                <div class="col-lg-12 col-md-12">
                  <div class="room_book">
                    <h6>Vendor Details
                    </h6>
                    <p>Club
                    </p>
                  </div>
                </div>
                <?php $vid=$vendordetails[0]['Id'];
$vendordetails=$this->App->getPerticularRecord('vendor','Id',$vid);?>
                <div class="form-group col-lg-12 col-md-12">
                  <div class="input-group border-bottom-dark-2">
                    <br>
                    <label style="    font-size: 20px;    color: whitesmoke;">
                      <?php echo $vendordetails[0]['FirstName'].' '.$vendordetails[0]['LastName'];?>
                    </label>
                    <br>
                    <label>
                      <i class="fa fa-envelope">
                      </i> 
                      <?php echo $vendordetails[0]['Email'];?>
                    </label>
                    <label>
                      <i class="fa fa-phone">
                      </i> 
                      <?php echo $vendordetails[0]['Phone'] .' , '.$vendordetails[0]['AlternativePhone'];?>
                    </label>
                    <br>
                    <label>
                      <i class="fa fa-map-marker">
                      </i> 
                      <?php echo $vendordetails[0]['Address'].' <br> '.$vendordetails[0]['City'].'-'.$vendordetails[0]['PostCode'].' ,'.$vendordetails[0]['Country']; ?>
                    </label>
                    <br>
                    <label>
                      <?php $AddressIfram=$vendordetails[0]['AddressIfram'];
if($AddressIfram!=''){ ?>
                      <iframe width="100%" height="250" frameborder="0" style="border:0" src="https://www.google.com/maps/embed/v1/place?key=AIzaSyAyhF2cCWevFm_T8iog0GqV3utCrfAbWYw&q='<?php echo $AddressIfram;?>'">
                      </iframe>
                      <?php } ?>
                    </label> 
                  </div>
                </div>
              </form>
            </div>
          </div>
                                                </div>
                                                
                                            </div>

                                        </div>
                                    </div>
                                
           <!------------------------------------------------------------->
            
          </div>
        </div>
      </div>
      
    </div>
    
  </div>
</div>
</div>     
<!-- start contact us area -->
<!-- end contact us area -->
<style>
    img.imgopwn {
    height: 150px;width:100%
}
  .myclspo1 {
    background: #313a45;
  }
  p {
    color: #666666;
    /* font-weight: normal; */
    font-size: 14px;
    font-family: inherit;
    font-weight: normal;
  }
  label {
    font-family: serif;
    color: #ccc;
  }
  span.a {
    COLOR: slategray;
  }
  
  
  img.eightimg {
    height: 412px;
  }
  img.rm {
    height: 150px;
  }
  img.uo {
    height: 188px;
  }
  .room_media {
    margin-bottom: 28px;
    text-align: center;
  }
  .padding-22 {
    padding: 27px 22px;
    text-align: justify;
  }
  img.ew {
    height: 150px;
  }
  .boxclx {
    border: 1px solid #ccc;
    display: inline-block;
    background: whitesmoke;
    padding: 12px;
    border-radius: 8px;
    margin: 1%;
    width:98%
  }
  h3.titlecls {
    padding-top: 10px;
  }
  .mg {
    border-top: 1px dotted;
    padding: 7px;
    margin-top: 15px;
  }
  .col-md-3.col-lg-3.col-sm-12.mds {
    background: #313a45;
  }
  input#clubname ,input#bookdate {
    background: transparent;
    border: none;
    color:#fff; font-size: 10px;
  }
  img.imgsearch {
    width: 34%;
  }
  .mop {
    border: 1px solid #ccc;
    background: #fff;
    padding: 2px;
    margin: 8px;
  }
</style>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Tablefast.com
    </title>
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url('assets/favicon/');?>favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- fonts -->
    <link href='http://fonts.googleapis.com/css?family=Playfair+Display:400,700,900' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Karla:700,400' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Lora:400,700' rel='stylesheet' type='text/css'>
    <!-- fontawesome -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/font-awesome.css" />
    <!-- bootstrap -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/bootstrap.min.css" />
    <!-- uikit -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/uikit.min.css" />
    <!-- animate -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/animate.css" />
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/datepicker.css" />
    <!-- Owl carousel 2 css -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/owl.carousel.css">
    <!-- rev slider -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/rev-slider/settings.css" />
    <!-- lightslider -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/lightslider.css">
    <!-- Theme -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/reset.css">
    <!-- custom css -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/style.css" />
    <!-- responsive -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/css/responsive.css" />
    <link href="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-bs/css/dataTables.bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-buttons-bs/css/buttons.bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-fixedheader-bs/css/fixedHeader.bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-responsive-bs/css/responsive.bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-scroller-bs/css/scroller.bootstrap.min.css" rel="stylesheet">

    <link href="<?php echo base_url('assets/admintheme');?>/build/css/custom.minfront.css" rel="stylesheet">
   
    <?php $s= $this->uri->segment(3);?>
  </head>
  <body id="accomodation_page">
  <!-- start preloader -->
  <div id="loader-wrapper">
    <div class="logo">
      <a href="#">
        <span>Table
        </span>-Fast
      </a>
    </div>
    <div id="loader">   
    </div>
  </div>
  <?php $this->load->view('front/include/nav');?> 
<style>
  
.pad-30 {
    padding: 6px 9px;
}a.btn.btn-warning.pad-30 {
    padding: 7px 11px;
}
    .form-group.col-lg-6.col-md-6.col-sm-6.icon_arrow1 {
    margin-right: 33px;
}td {
    width: 8%;
}label.error {
    color: red;
    font-size: 13px;
}

@media only screen and (min-width: 992px) and (max-width: 1199px) {
  .x_title{
    border-bottom:2px solid #E6E9ED;
    padding:1px 5px 6px
  }
}
  
</style> 
<section class="breadcrumb_main_area margin-bottom-80">
  <div class="container-fluid">
    <div class="row">
      <div class="breadcrumb_main nice_title">
        <h2> Events
        </h2>
        <!-- special offer start -->
        <div class="special_offer_main">
          <div class="container">
            <div class="special_offer_sub">
              <img src="<?php echo base_url('assets/fronttheme/')?>/img/special-offer-yellow-main.png" alt="imf">
            </div>
          </div>
        </div>         
        <!-- end offer start -->
      </div>
    </div>
  </div>            
</section>
<section class="contact_mail_area margin-bottom-90">
  <div class="container">
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_title">
            <h2 style="font-size:20px "> Events
            </h2>
            <button type="button" class="btn "  style="float:right;margin-bottom:10px;color:#63c2ea !important" data-toggle="modal" data-target="#myModal" >
              <i class="fa fa-plus"> 
              </i> Add Event  
            </button>
            <br>
            <br>
            <!------------------------------------>
            <!-- Modal -->
            <div class="modal fade" id="myModal" role="dialog">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;
                    </button>
                    <h4 class="modal-title" >Add Events
                    </h4>
                  </div>
                  <div class="modal-body">
                    <form name="eventfrm" id="eventfrm" method="post" action="<?php echo base_url("events/addevent");?>" class="form-horizontal form-label-left" novalidate enctype="multipart/form-data">
                      <div id="err" style="color:red">
                      </div>
                      <div id="err1" style="color:red">
                      </div>
                        <div class="form-group">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                          <input id="eventtitle" class="form-control col-md-12 col-xs-12" placeholder="Title" required="required" type="text" name="eventtitle" >
                        </div>
                      </div>
                        <div class="form-group">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                          <textarea class="form-control col-md-12 col-xs-12" placeholder="Description" name="description" id="description"></textarea>
                        </div>
                      </div>
                         <div class="form-group">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <select class="form-control col-md-12 col-xs-12" id="days" name="days" onchange="divopenclose()">
                                <option value="">--Select No. of Days--</option>
                                <option value="1">1</option>
                                 <option value="many">Many</option>
                                
                            </select> 
                        </div>
                         </div>
                      <script>
                          function divopenclose(){
                            
                              var c=$("#days option:selected").val();
                              if(c=='1'){
                                  $("#maydays").hide();
                                   $("#onedays").show();
                              }
                              if(c=='many'){
                                  $("#maydays").show();
                                   $("#onedays").hide();
                              }
                          }
                      </script>
                        
                        <div id="maydays" style="display:none">
                            <div class="form-group">
                                <div class="col-md-12 col-sm-12 col-xs-12">
                                   <input id="nooddays" class=" form-control col-md-12 col-xs-12" placeholder="No. of Days " required="required" type="text" name="nooddays" >
                                </div>
                            </div>
                             <div class="form-froup">
                            <div class="col-md-12 col-sm-12 col-sm-12">
                                <div class="form-group col-lg-6 col-md-6 col-sm-6 icon_arrow1 ">                            
                                    <input id="fromdate" class="date-picker form-control col-md-12 col-xs-12" placeholder="From Date" required="required" type="text" name="fromdate" >
                               </div> 
                          <div class="form-group col-lg-6 col-md-6 col-sm-6 icon_arrow2">
                               <input id="todate" class="date-picker form-control col-md-12 col-xs-12" placeholder="To Date" required="required" type="text" name="todate" >
                              </div>
                            </div>
                        </div>
                           
                        </div>
                        
                        <div id="onedays" style="display:none">
                             <div class="form-group">
                                <div class="col-md-12 col-sm-12 col-xs-12">
                                    <input id="specialdate" class="date-picker form-control col-md-12 col-xs-12" placeholder="Special Date" required="required" type="text" name="specialdate" >
                                </div>
                              </div>
                        </div>
                        
                        
                         <div class="form-group">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <input type="file" name="uploadsfl" id="uploadsfl"  >
                        </div>
                      </div>
                        <div class="form-froup">
                            <div class="col-md-12 col-sm-12 col-sm-12">
                                <div class="form-group col-lg-6 col-md-6 col-sm-6 icon_arrow1 ">  
                                    <lable>From Time</lable>
                                    <input type="time" id="fromtime" class="form-control" type="text" name="fromtime" placeholder="Time From" required="required" >
                                </div> 
                          <div class="form-group col-lg-6 col-md-6 col-sm-6 icon_arrow2"><lable>To Time</lable>
                                <input type="time" id="totime" class="form-control" type="text" name="totime" placeholder="Time To" required="required" >
                           </div>
                            </div>
                        </div>
                      
                      <div class="form-group">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                          <input id="price" class="form-control col-md-12 col-xs-12" placeholder="Price" required="required" type="text" name="price" >
                        </div>
                      </div>
                      <div class="ln_solid">
                      </div>
                      <div class="form-group">
                        <div class="col-md-12 col-sm-12 col-xs-12 ">
                          <button  class="btn btn-info" >Submit
                          </button>
                            
                        </div>
                      </div>
                    </form>
                      <script>
          $("#eventfrm").validate({
            rules: {
              eventtitle: "required",
              description: "required",
              price: "required",
            }
            ,
            messages: {
              eventtitle: "Please enter Title ",
              description: "Please enter description",
              price: "Please enter First Name",
            }
            ,
            submitHandler: function(form) {
              form.submit();
            }
          }
                                     );
        </script>
                   
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!------------------------------------------->
        </div>
        
<div id="updatediv">
</div>
        <div class="x_content">
        	
          <table id="datatable-buttons"  class="table table-striped table-bordered" cellspacing="0" width="100%">
            <thead>
              <tr>
                <th>Action                </th> 
                <th>Events              </th>
                <th>Image                </th>
                <th>No. of Days                </th>
                <th>Date                </th>
                <th>Time                 </th> 
                <th>Price                </th>  
              </tr>
            </thead>
            <tbody>
              <?php if(!empty($listcategory)){
    foreach($listcategory as $cat){ 
    if($cat['Status']=='1'){ $s='Active';}else{ $s='Inactive';}
    if($cat['NoofDays']=='1'){
        $dt=$cat['OneDate'];
    }else{ $dt=$cat['FromDate'].' To '.$cat['ToDate'];}
    $img=$cat['Image'];
    if($img!=''){
        $b=base_url('assets/events/'.$img);
        $sdq="<img src='".$b."' width='100%' >";
    }
    ?>
              <tr>
                <td>
                
                   <a  class="btn pad-30" style="margin:3px 0px" data-toggle="tooltip" title="Edit"  href="<?php echo base_url('events/editevent/'.$cat['Slug'])?>">
                    <i class="fa fa-edit"> 
                    </i>  
                  </a> 
                  <a  class="btn btn-warning pad-30" style="margin:3px 0px;" data-toggle="tooltip" title="Delete" onclick="deletecategory('<?php echo $cat['Id']?>')">
                    <i class="fa fa-trash"> 
                    </i>  
                  </a> 
                </td>
                <td>
                  <?php echo  $cat['Title'];?>
                </td>
                <td>
                  <?php echo  $sdq;?>
                </td>
                <td>
                  <?php echo $cat['NoofDays'];?>
                </td>
                <td>
                  <?php echo $dt;?>
                </td>
                <td>
                  <?php echo $cat['TimeFrom'].' To '.$cat['TimeTo'];?>
                </td>
                <td>
                  <?php echo '₹ '.$cat['Price'];?>
                </td>
              </tr>
              <?php }
} ?>
            </tbody>
          </table>
          <div class="row">
            <nav class="text-center margin-top-65 margin-bottom-75">
              <ul class="pagination">
                <?php echo $links; ?>
              </ul>
            </nav> 
          </div>
          <script>
            function deletecategory(id){
              var r = confirm("Are You sure want to Delete this Record?");
              var url="<?php echo base_url('events/deleteevent');?>";
              if (r == true) {
                $.ajax({
                  type: 'post',
                  url: url,
                  data: "id="+id,
                  success: function () {
                    alert('Delete Event Successfully');
                    location.reload();
                  }
                }
                      );
              }
            }
            function updatecategory(id){
              var url="<?php echo base_url('events/updateeventfrom');?>";
              $.ajax({
                type: 'post',
                dataType : 'json',
                url: url,
                data: "id="+id,
                success: function (data) {
                    alert(data);
                  $("#updatediv").html(data);
                  $('#myModal2').modal('show');
                }
              }
                    );
            }
          </script>	
        </div>
      </div>
    </div>
  </div>
  </div>
</div>
</section>
<script>
  function editcategory(){
    var s=$("#cattitle1 option:selected").val();
    var itemtitle1=$("#itemtitle1").val();
    var itemid=$("#itemid").val();
    var price1=$("#price1").val();
    var catstatus=$().val("#catstatus option:selected");
    var url="<?php echo base_url('food/edititem');?>";
    if(s=='' || itemtitle1=='' || price1==''){
      $("#err3").html("Please item title required");
    }
    else{
      $.ajax({
        type: 'post',
        dataType : 'json',
        url: url,
        data: "category="+s+"&itemtitle1="+itemtitle1+"&price1="+price1+"&itemid="+itemid+"&catstatus="+catstatus,
        success: function (data) {
          if(data=='1'){
            alert('Item successfully Update.');
            location.reload();
          }
          if(data=='2'){
            $('#err2').html('Item already Exist.');
          }
        }
      }
            );
    }
  }
</script>
<?php $this->load->view('front/include/subfooternav');?>
<footer class="footer_area">
  <div class="container">
    <div class="footer">
      <div class="footer_top padding-top-80 clearfix">
        <div class="col-lg-4 col-md-4 col-sm-4">
          <div class="footer_widget">
            <div class="footer_logo">
              <a href="#">
                <img src="<?php echo base_url('assets/fronttheme/')?>/img/footer-logo-one.png" alt="">
              </a>
            </div>
            <p>Lorem ipsum dolor sit amet, conser adipiscing elit. In consectetur tincidunt dolor.
            </p>
            <ul>
              <li>
                <P>
                  <i class="fa fa-map-marker">
                  </i>St Amsterdam finland, 
                  <br> United Stats of AKY16 8PN
                </P>
              </li>
            </ul>
          </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-4">
          <div class="row">
            <div class="footer_widget clearfix">
              <h5 class="padding-left-15">Quick Links
              </h5>
              <div class="col-lg-6 col-md-6 col-sm-6">
                <ul>
                  <li>
                    <a href="<?php echo base_url();?>">Home
                    </a>
                  </li>
                  <li>
                    <a href="<?php echo base_url('front/allclub');?>">Clubs
                    </a>
                  </li>
                  <li>
                    <a href="<?php echo base_url('about');?>">About Us
                    </a>
                  </li>
                  <li>
                    <a href="<?php echo base_url('contact');?>">Contact
                    </a>
                  </li>
                </ul>  
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-4">
          <div class="footer_widget">
            <h5>We Are Global
            </h5>
            <div class="footer_map">
              <a href="#">
                <img src="<?php echo base_url('assets/fronttheme/')?>/img/footer-map-two.jpg" alt="">
              </a>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="container">
          <div class="footer_copyright margin-tb-50 content-center">
            <p>© 2018 
              <a href="#">Tablefast.com 
              </a>. All rights reserved
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
</footer>
<!-- end footer -->
<!-- jquery library -->
<script src="<?php echo base_url('assets/fronttheme/')?>/js/vendor/jquery-1.11.2.min.js"></script>
<!-- bootstrap -->
<script src="<?php echo base_url('assets/fronttheme/')?>/js/bootstrap.min.js"></script>

<!-- uikit -->
<script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/datatables.net-scroller/js/dataTables.scroller.min.js"></script>
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/jszip/dist/jszip.min.js"></script>
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="<?php echo base_url('assets/admintheme');?>/vendors/pdfmake/build/vfs_fonts.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="<?php echo base_url('assets/admintheme');?>/build/js/custom.min.js"></script>



<!--Activating WOW Animation only for modern browser-->
<!--[if !IE]><!-->
<script type="text/javascript">new WOW().init();</script>
<script src="<?php echo base_url('assets/fronttheme/')?>/js/main.js"></script>
</body>
</html>

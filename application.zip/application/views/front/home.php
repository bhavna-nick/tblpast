<!-- end header -->
<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
<script src="//code.jquery.com/jquery-1.10.2.js">
</script>
<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js">
</script>     
<!-- start main slider -->
<div class="main_slider_area">
  <div class="container-fluid">
    <div class="row">
      <div class="main_slider" id="slider_rev">
        <!-- special offer start -->
        <div class="special_offer_main">
          <img src="<?php echo base_url('assets/fronttheme/')?>/img/special-offer-yellow-main.png" alt="">
        </div>
        <!-- end offer start -->
        <div class="fullwidthbanner-container" >
          <div class="fullwidth_home_two_banner">
            <ul>                     
              <li data-transition="random" data-slotamount="7" data-masterspeed="1000">
                <img src="<?php echo base_url('assets/fronttheme/banner')?>/TableFast-Banner-1.jpg" alt="slide" >
                <!-- <div class="tp-caption large_black sfr" data-x="105" data-y="197" data-speed="1200" data-start="1100" data-easing="easeInOutBack"
style="font-family: 'Playfair Display', serif; font-size: 48px;color: #fff; margin-bottom: 23px; text-transform: uppercase; line-height: 40px;">
Book Your Summer Holidays
</div>
<div class="tp-caption large_black sfr" data-x="105" data-y="255" data-speed="1500" data-start="1400" data-easing="easeInOutBack"
style="font-family: 'Playfair Display', serif; font-size: 48px;color: #fff; margin-bottom: 23px; text-transform: uppercase; line-height: 40px;">
With Tablefast 
</div>-->
                <div class="tp-caption lfb carousel-caption-inner" data-x="105" data-y="313" data-speed="1300" data-start="1700" data-easing="easeInOutBack" 
                     style="background: #f7c411; padding: 10px; cursor: pointer;">
                  <a href="<?php echo base_url('front/allclub');?>" class="" style="background: #f7c411; border-radius: 0; color: #313a45; display: inline-block;  font-size: 18px; padding: 8px 34px; text-transform: uppercase; border: 1px solid #9e811a;">Explore IT
                  </a>
                </div>
              </li>							
              <li data-transition="random" data-slotamount="7" data-masterspeed="1000">
                <img src="<?php echo base_url('assets/fronttheme/banner')?>/TableFast-Banner-2.jpg" alt="slide" >
                <!-- <div class="tp-caption large_black sfr" data-x="105" data-y="197" data-speed="1200" data-start="1100" data-easing="easeInOutBack"
style="font-family: 'Playfair Display', serif; font-size: 48px;color: #131e2a; margin-bottom: 23px; text-transform: uppercase; line-height: 40px;">
One of the Best Booking Template
</div>
<div class="tp-caption large_black sfr" data-x="105" data-y="255" data-speed="1500" data-start="1400" data-easing="easeInOutBack"
style="font-family: 'Playfair Display', serif; font-size: 48px;color: #131e2a; margin-bottom: 23px; text-transform: uppercase; line-height: 40px;">
Available on Envato Market
</div>-->
                <div class="tp-caption lfb carousel-caption-inner" data-x="105" data-y="313" data-speed="1300" data-start="1700" data-easing="easeInOutBack" 
                     style="background: #f7c411; padding: 10px; cursor: pointer;">
                  <a href="<?php echo base_url('front/allclub');?>" class="" style="background: #f7c411; border-radius: 0; color: #313a45; display: inline-block;  font-size: 18px; padding: 8px 34px; text-transform: uppercase; border: 1px solid #9e811a;">Explore IT
                  </a>
                </div>
              </li>	
              <li data-transition="random" data-slotamount="7" data-masterspeed="1000">
                <img src="<?php echo base_url('assets/fronttheme/banner')?>/TableFast-Banner-3.jpg" alt="slide" >
                <!-- <div class="tp-caption large_black sfr" data-x="105" data-y="197" data-speed="1200" data-start="1100" data-easing="easeInOutBack"
style="font-family: 'Playfair Display', serif; font-size: 48px;color: #131e2a; margin-bottom: 23px; text-transform: uppercase; line-height: 40px;">
Book Your Summer Holidays
</div>
<div class="tp-caption large_black sfr" data-x="105" data-y="255" data-speed="1500" data-start="1400" data-easing="easeInOutBack"
style="font-family: 'Playfair Display', serif; font-size: 48px;color: #131e2a; margin-bottom: 23px; text-transform: uppercase; line-height: 40px;">
With Tablefast
</div>-->
                <div class="tp-caption lfb carousel-caption-inner" data-x="105" data-y="313" data-speed="1300" data-start="1700" data-easing="easeInOutBack" 
                     style="background: #f7c411; padding: 10px; cursor: pointer;">
                  <a href="<?php echo base_url('front/allclub');?>" class="" style="background: #f7c411; border-radius: 0; color: #313a45; display: inline-block;  font-size: 18px; padding: 8px 34px; text-transform: uppercase; border: 1px solid #9e811a;">Explore IT
                  </a>
                </div>
              </li>	
              <li data-transition="random" data-slotamount="7" data-masterspeed="1000">
                <img src="<?php echo base_url('assets/fronttheme/banner')?>/TableFast-Banner-4.jpg" alt="slide" >
                <!--<div class="tp-caption large_black sfr" data-x="105" data-y="197" data-speed="1200" data-start="1100" data-easing="easeInOutBack"
style="font-family: 'Playfair Display', serif; font-size: 48px;color: #131e2a; margin-bottom: 23px; text-transform: uppercase; line-height: 40px;">
Book Your Summer Holidays
</div>
<div class="tp-caption large_black sfr" data-x="105" data-y="255" data-speed="1500" data-start="1400" data-easing="easeInOutBack"
style="font-family: 'Playfair Display', serif; font-size: 48px;color: #131e2a; margin-bottom: 23px; text-transform: uppercase; line-height: 40px;">
With tablefast
</div>-->
                <div class="tp-caption lfb carousel-caption-inner" data-x="105" data-y="313" data-speed="1300" data-start="1700" data-easing="easeInOutBack" 
                     style="background: #f7c411; padding: 10px; cursor: pointer;">
                  <a href="<?php echo base_url('front/allclub');?>" class="" style="background: #f7c411; border-radius: 0; color: #313a45; display: inline-block;  font-size: 18px; padding: 8px 34px; text-transform: uppercase; border: 1px solid #9e811a;">Explore IT
                  </a>
                </div>
              </li>	
              <li data-transition="random" data-slotamount="7" data-masterspeed="1000">
                <img src="<?php echo base_url('assets/fronttheme/banner')?>/TableFast-Banner-5.jpg" alt="slide" >
                <!--<div class="tp-caption large_black sfr" data-x="105" data-y="197" data-speed="1200" data-start="1100" data-easing="easeInOutBack"
style="font-family: 'Playfair Display', serif; font-size: 48px;color: #131e2a; margin-bottom: 23px; text-transform: uppercase; line-height: 40px;">
Book Your Summer Holidays
</div>
<div class="tp-caption large_black sfr" data-x="105" data-y="255" data-speed="1500" data-start="1400" data-easing="easeInOutBack"
style="font-family: 'Playfair Display', serif; font-size: 48px;color: #131e2a; margin-bottom: 23px; text-transform: uppercase; line-height: 40px;">
With Tablefast
</div>-->
                <div class="tp-caption lfb carousel-caption-inner" data-x="105" data-y="313" data-speed="1300" data-start="1700" data-easing="easeInOutBack" 
                     style="background: #f7c411; padding: 10px; cursor: pointer;">
                  <a href="<?php echo base_url('front/allclub');?>" class="" style="background: #f7c411; border-radius: 0; color: #313a45; display: inline-block;  font-size: 18px; padding: 8px 34px; text-transform: uppercase; border: 1px solid #9e811a;">Explore IT
                  </a>
                </div>
              </li>	
            </ul>
          </div>
        </div>
        <!-- start hotel booking -->
        <!---Search functionality----------------->
        <div class="hotel_booking_area">
          <div class="container">
            <div class="hotel_booking">
              <form id="form1" role="form" action="<?php echo base_url('front/search');?>" method="post">
                <div class="col-lg-2 col-md-2 col-sm-2">
                  <div class="room_book border-right-dark-1">
                    <h6>Book Your
                    </h6>
                    <p>Tables
                    </p>
                  </div>
                </div>
                <div class="form-group col-lg-4 col-md-4 col-sm-4">
                  <div class="input-group border-bottom-dark-2">
                      <input class="form-control" type="text" name="clubname" id="clubname" required placeholder="ClubName or Address" onkeyup="showResult(this.value)"/>
                    <div class="input-group-addon">
                      <i class="fa fa-map-marker">
                      </i>
                    </div>                
                  </div>
                  <div id="kpl">
                  </div>
                </div>
                <script>
                  function showResult(val){
                    var url="<?php echo base_url('front/autosearch');?>";
                    $.ajax({
                      type: 'post',
                      dataType : 'json',
                      url: url,
                      data: "category="+val,
                      success: function (data) {
                        $("#kpl").html(data);
                      }
                    }
                          );
                  }
                </script>
                <div class="form-group col-lg-2 col-md-2 col-sm-2">
                  <div class="input-group border-bottom-dark-2">
                    <input class="date-picker" id="datepicker" name="bookdata" placeholder="Arrival" type="text">
                    <div class="input-group-addon">
                      <i class="fa fa-calendar">
                      </i>
                    </div>               
                  </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-4">
                  <div class="row">
                    <div class="form-group col-lg-4 col-md-4 col-sm-4 icon_arrow">
                      <div class="input-group border-bottom-dark-2">
                        <select class="form-control" name="adult" id="adult">
                          <option selected="selected" disabled="disabled">1 Adult
                          </option>
                          <option value="1">1 Adult
                          </option>
                          <option value="2">2 Adult
                          </option>
                          <option value="3">3 Adult
                          </option>
                          <option value="4">4 Adult
                          </option>
                          <option value="5">5 Adult
                          </option>
                          <option value="6">6 Adult
                          </option>
                          <option value="7">7 Adult
                          </option>
                          <option value="8">8 Adult
                          </option>
                          <option value="9">9 Adult
                          </option>
                          <option value="10">10 Adult
                          </option>
                          <option value="11">11 Adult
                          </option>
                          <option value="12">12 Adult
                          </option>
                          <option value="13">13 Adult
                          </option>
                          <option value="14">14 Adult
                          </option>
                          <option value="15">15 Adult
                          </option>
                          <option value="16">16 Adult
                          </option>
                          <option value="17">17 Adult
                          </option>
                          <option value="18">18 Adult
                          </option>
                          <option value="19">19 Adult
                          </option>
                          <option value="20">20 Adult
                          </option>
                          <option value="many">Many
                          </option>
                        </select>               
                      </div>
                    </div>
                    <div class="form-group col-lg-4 col-md-4 col-sm-4 icon_arrow">
                      <div class="input-group border-bottom-dark-2">
                        <select class="form-control" name="child" id="child">
                          <option selected="selected" disabled="disabled">0 Child
                          </option>
                          <option value="1">1 Child
                          </option>
                          <option value="2">2 Child
                          </option>
                          <option value="3">3 Child
                          </option>
                          <option value="4">4 Child
                          </option>
                          <option value="5">5 Child
                          </option>
                          <option value="6">6 Child
                          </option>
                          <option value="7">7 Child
                          </option>
                          <option value="8">8 Child
                          </option>
                          <option value="9">9 Child
                          </option>
                          <option value="10">10 Child
                          </option>
                          <option value="11">11 Child
                          </option>
                          <option value="12">12 Child
                          </option>
                          <option value="13">13 Child
                          </option>
                          <option value="14">14 Child
                          </option>
                          <option value="15">15 Child
                          </option>
                          <option value="16">16 Child
                          </option>
                          <option value="17">17 Child
                          </option>
                          <option value="18">18 Child
                          </option>
                          <option value="19">19 Child
                          </option>
                          <option value="20">20 Child
                          </option>
                          <option value="many">Many
                          </option>
                        </select>               
                      </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-4">
                      <input type="submit" class="btn btn-warning btn-md floatright" name="submit" value="Book">
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
        <!----------end serach functionality--------------------------------------------->
        <!-- end hotel booking -->
      </div>
    </div>
  </div>
</div>
<!-- end main slider -->
<!-- start welcome section -->
<section class="another_facitilies_area">
  <div class="container">
    <div class="another_facitilies clearfix padding-bottom-100">
      <div class="col-lg-3 col-md-3 col-sm-3">
        <div class="single_facities">
          <a href="#">
            <img src="<?php echo base_url('assets/fronttheme/')?>/img/home-facilities-icon-eleven.png" alt="">
          </a>
          <h6>Restaurant
          </h6>
          <p>Semper ac dolor vitae accumsan. Cras interdum hendrerit lacinia.  vitae molestie interdum.
          </p>
        </div>                        
      </div>
      <div class="col-lg-3 col-md-3 col-sm-3">
        <div class="single_facities">
          <a href="#">
            <img src="<?php echo base_url('assets/fronttheme/')?>/img/home-facilities-icon-seven.png" alt="">
          </a>
          <h6>Sports Club
          </h6>
          <p>Semper ac dolor vitae accumsan. Cras interdum hendrerit lacinia.  vitae molestie interdum.
          </p>
        </div> 
      </div>
      <div class="col-lg-3 col-md-3 col-sm-3">
        <div class="single_facities">
          <a href="#">
            <img src="<?php echo base_url('assets/fronttheme/')?>/img/home-facilities-icon-eight.png" alt="">
          </a>
          <h6>Pick up
          </h6>
          <p>Semper ac dolor vitae accumsan. Cras interdum hendrerit lacinia.  vitae molestie interdum.
          </p>
        </div> 
      </div>
      <div class="col-lg-3 col-md-3 col-sm-3">
        <div class="single_facities">
          <a href="#">
            <img src="<?php echo base_url('assets/fronttheme/')?>/img/home-facilities-icon-nine.png" alt="">
          </a>
          <h6>BAR
          </h6>
          <p>Semper ac dolor vitae accumsan. Cras interdum hendrerit lacinia.  vitae molestie interdum.
          </p>
        </div> 
      </div>
    </div>
  </div>
</section>
<!-- end welcome section -->
<!-- start Hotel Facilities section -->
<section class="select_room_area padding-top-90">
  <div class="container">
    <div class="row">
      <div class="select_room clearfix">
        <div class="section_title nice_title content-center">
          <h3>Select Your Table
          </h3>
        </div>
        <div class="select_room_content clearfix">
          <?php if(!empty($clubs)){
foreach($clubs as $clb){
$cid=$clb['Id'];
$clublayout=$this->App->getPerticularRecord('clublayout','VendorId',$cid);
$img=$clublayout[0]['MainImage'];
$PerAdultPrice=$clublayout[0]['PerAdultPrice'];
?>
          <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12 eightcls">
            <div class="room_thumb eightroom">
              <a href="<?php echo base_url('front/clubdetails/'.$clb['Slug']);?>">
                <?php if($img!=''){ ?>
                <img class="eightimg" src="<?php echo base_url('assets/clubimage/'.$img);?>" alt="">
                <?php }else{ ?>
                <img class="eightimg" src="<?php echo base_url('assets/fronttheme/')?>/img/room-thumb-one.jpg" alt="">
                <?php } ?>
              </a>
              <div class="room_details">
                <div class="about_room floatleft">
                  <div class="room_quality floatleft">
                    <a href="<?php echo base_url('front/clubdetails/'.$clb['Slug']);?>">
                      <h5>
                        <?php echo $clb['ClubName'];?>
                      </h5>
                    </a>
                  </div>
                  <div class="room_rent floatleft">
                    <p><?php echo '₹ '.$PerAdultPrice;?>
                      <span> 
                      </span>
                    </p>
                  </div>
                </div>
                <div class="room_block floatright">
                  <a href="<?php echo base_url('front/clubdetails/'.$clb['Slug']);?>" class="btn btn-black">Book
                  </a>
                </div>
              </div>
            </div>
          </div>
          <?php } } ?>
          <div class="col-lg-4 col-md-4 col-sm-4 col-sx-12 fourcls">
            <?php if(!empty($clubs1)){
foreach($clubs1 as $clb1){
$cid=$clb1['Id'];
$clublayout=$this->App->getPerticularRecord('clublayout','VendorId',$cid);
$img=$clublayout[0]['MainImage'];
$PerAdultPrice=$clublayout[0]['PerAdultPrice'];
?>
            <div class="room_thumb small_room_thumb margin-bottom-35 fourroom1">
              <a href="<?php echo base_url('front/clubdetails/'.$clb1['Slug']);?>">
                <?php if($img!=''){ ?>
                <img src="<?php echo base_url('assets/clubimage/'.$img);?>" alt="" class="uo">
                <?php }else{ ?>
                <img class="uo" src="<?php echo base_url('assets/fronttheme/')?>/img/room-thumb-one.jpg" alt="">
                <?php } ?>
              </a> 
              <div class="room_details">
                <div class="about_room floatleft">
                  <div class="room_quality floatleft">
                    <a href="<?php echo base_url('front/clubdetails/'.$clb1['Slug']);?>">
                      <h5>
                        <?php echo $clb1['ClubName'];?>
                      </h5>
                    </a>
                  </div>
                  <div class="room_rent floatleft">
                    <p><?php echo '₹ '.$PerAdultPrice;?>
                      <span> 
                      </span>
                    </p>
                  </div>
                </div>
                <div class="room_block floatright">
                  <a href="<?php echo base_url('front/clubdetails/'.$clb1['Slug']);?>" class="btn btn-black">Book
                  </a>
                </div>
              </div>
            </div>
            <?php } } 
if(!empty($clubs2)){
foreach($clubs2 as $clb2){
$cid=$clb2['Id'];
$clublayout=$this->App->getPerticularRecord('clublayout','VendorId',$cid);
$img=$clublayout[0]['MainImage'];
$PerAdultPrice=$clublayout[0]['PerAdultPrice'];
?>
            <div class="room_thumb small_room_thumb fourroom1">
              <a href="<?php echo base_url('front/clubdetails/'.$clb2['Slug']);?>">
                <?php if($img!=''){ ?>
                <img src="<?php echo base_url('assets/clubimage/'.$img);?>" alt=""  class="uo">
                <?php }else{ ?>
                <img class="uo" src="<?php echo base_url('assets/fronttheme/')?>/img/room-thumb-one.jpg" alt="">
                <?php } ?>
              </a> 
              <div class="room_details">
                <div class="about_room floatleft">
                  <div class="room_quality floatleft">
                    <a href="<?php echo base_url('front/clubdetails/'.$clb2['Slug']);?>">
                      <h5>
                        <?php echo $clb2['ClubName'];?>
                      </h5>
                    </a>
                  </div>
                  <div class="room_rent floatleft">
                    <p><?php echo '₹ '.$PerAdultPrice;?>
                      <span> 
                      </span>
                    </p>
                  </div>
                </div>
                <div class="room_block floatright">
                  <a href="<?php echo base_url('front/clubdetails/'.$clb2['Slug']);?>" class="btn btn-black">Book
                  </a>
                </div>
              </div>
            </div>
            <?php } } ?>
          </div>
          <div class="col-lg-12 col-md-12 col-sm-12 col-sx-12">
            <div class="view_all_rooms text-center  padding-bottom-90  padding-top-90">
              <a href="<?php echo base_url('front/allclub'); ?>" class="btn btn-warning">View All Tables
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- end Hotel Facilities section -->
<!-- start Hotel Showcase section -->
<section class="hotel_showcase_area margin-bottom-128 margin-top-110">
  <div class="container-fluid">
    <div class="row">
      <div class="hotel_showcase">
        <div class="section_title nice_title content-center">
          <h3>TableFast Gallery
          </h3>
        </div>
        <div class="section_content">
          <div class="showcase_slider">
            <?php
if(!empty($Allclub)){
foreach($Allclub as $cl){
$Iid=$cl['Id'];
$all=$this->App->getRecordByLimit('clubgallery','VendorId',$Iid,'0','2');
if(!empty($all)){
foreach($all as $gallery){
?>
            <div class="item">
              <a href="#">
                <img class="iop" src="<?php echo base_url('assets/clubgallery/'.$gallery['Image'])?>" alt="img">
                <i class="fa fa-search">
                </i>
              </a>
            </div>
            <?php }
} }
} ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- end Hotel Showcase section -->
<!-- start About Us section -->
<section class="about_us_area margin-bottom-128">
  <div class="container">
    <div class="about_us clearfix">
      <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 padding-left-0">
        <div class="news">
          <div class="section_title margin-bottom-50">
            <h5>News
            </h5>
          </div>
          <div class="section_description">
            <div class="row">
              <div class="col-md-12">
                <?php if(!empty($clubs3rec)){
foreach($clubs3rec as $clb3){
$cid=$clb3['Id'];
$clublayout=$this->App->getPerticularRecord('clublayout','VendorId',$cid);
$img=$clublayout[0]['MainImage'];
?> 
                <div class="single_content clearfix border-bottom-whitesmoke">
                  <div class="col-lg-4 col-md-4 col-sm-12 col-xs-4 padding-left-0">
                    <div class="post_media">
                      <a href="<?php echo base_url('front/clubdetails/'.$clb3['Slug']);?>">
                        <?php if($img!=''){ ?>
                        <img class="smcl" src="<?php echo base_url('assets/clubimage/'.$img);?>" alt="">
                        <?php }else{ ?>
                        <img class="smcl" src="<?php echo base_url('assets/clubgallery/n010064_2017dec15_new-york-hotel-parkside-diner_16-9.jpg')?>" alt="">
                        <?php } ?>
                      </a>
                    </div>
                  </div>
                  <div class="col-lg-8 col-md-8 col-sm-12 col-xs-8 padding-left-0">
                    <div class="post_title clearfix">
                      <a href="<?php echo base_url('front/clubdetails/'.$clb3['Slug']);?>"> 
                        <h6>
                          <?php echo $clb3['ClubName'];?>
                        </h6>
                      </a>
                    </div>
                    <div class="post_content  margin-bottom-35 " style="color: deepskyblue;" >
                      <?php echo 'By '.$clb3['FirstName'].' '.$clb3['LastName'];?>
                    </div>
                  </div>
                </div>
                <?php } } ?>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
        <div class="showcase">
          <div class="section_title margin-bottom-50">
            <h5>About TableFast
            </h5>
          </div>
          <div class="section_description">
            <div class="about_hotel" style="">
              <div class="hotel_thumb">
                <img src="<?php echo base_url('assets/clubgallery')?>/cS-282.jpeg" alt="img">
              </div>
              <div class="about_details">
                <p>
                  Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
        <div class="customer_says">
          <div class="section_title margin-bottom-50">
            <h5>Customer Says
            </h5>
          </div>
          <div class="section_description">
            <div id="customer_says_slider" class="carousel slide" data-ride="carousel" data-pause="none">
              <!-- Wrapper for slides -->
              <div class="carousel-inner" role="listbox">
                <div class="item active">
                  <div class="single_says">
                    <div class="customer_comment">
                      <p>
                        Semper ac dolor vitae msan. Cras interdum hendreritnia Phasellus accumsan urna vitae molestie interdum.
                      </p>
                      <p>
                        Nam sed placerat libero, non eleifend dolor.
                      </p>
                    </div>
                    <div class="customer_detail clearfix">
                      <div class="customer_pic alignleft-20">
                        <a href="#">
                          <img src="<?php echo base_url('assets/fronttheme/')?>/img/customer-says-one.png" alt="">
                        </a>
                      </div>
                      <div class="customer_identity floatleft">
                        <h6>John Doe
                        </h6>
                        <p>www.john.com
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="item">
                  <div class="single_says">
                    <div class="customer_comment">
                      <p>
                        Semper ac dolor vitae msan. Cras interdum hendreritnia Phasellus accumsan urna vitae molestie interdum.
                      </p>
                      <p>
                        Nam sed placerat libero, non eleifend dolor.
                      </p>
                    </div>
                    <div class="customer_detail clearfix">
                      <div class="customer_pic alignleft-20">
                        <a href="#">
                          <img src="<?php echo base_url('assets/fronttheme/')?>/img/customer-says-one.png" alt="">
                        </a>
                      </div>
                      <div class="customer_identity floatleft">
                        <h6>John Doe
                        </h6>
                        <p>www.john.com
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <!-- Controls -->
              <a class="slider_says left" href="#customer_says_slider" role="button" data-slide="prev">
                <i class="fa fa-angle-left">
                </i>
                <span class="sr-only">Previous
                </span>
              </a>
              <a class="slider_says right" href="#customer_says_slider" role="button" data-slide="next">
                <i class="fa fa-angle-right">
                </i>
                <span class="sr-only">Next
                </span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- end About Us section -->
<section class="welcome_area">
  <div class="container">
    <div class="about_us clearfix">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 padding-left-0">
        <div class="news">
          <div class="section_title margin-bottom-50">
            <h5>You may Also like
            </h5>
          </div>
          <div class="section_description">
            <div class="row">
              <?php if(!empty($clubs4rec)){
foreach($clubs4rec as $clb4){
$cid=$clb4['Id'];
$clublayout=$this->App->getPerticularRecord('clublayout','VendorId',$cid);
$img=$clublayout[0]['MainImage'];
$PerAdultPrice=$clublayout[0]['PerAdultPrice'];
?>           
              <div class="col-lg-3 col-md-3 col-sm-3">
                <div class="single_room_wrapper clearfix">
                  <div class="room_wrapper">
                    <div class="room_media">
                      <a href="<?php echo base_url('front/clubdetails/'.$clb4['Slug']);?>">
                        <?php if($img!=''){ ?>
                        <img src="<?php echo base_url('assets/clubimage/'.$img);?>" alt="" class="rm">
                        <?php }else{ ?>
                        <img src="<?php echo base_url('assets/fronttheme/')?>/img/room-thumb-one.jpg" alt="">
                        <?php } ?>
                      </a>
                    </div>
                    <div class="room_title clearfix">
                      <div class="left_room_title floatleft">
                        <a href="<?php echo base_url('front/clubdetails/'.$clb4['Slug']);?>">
                          <h6>
                            <?php echo $clb4['ClubName'];?>
                          </h6>
                        </a>
                        <p><?php echo '₹ '.$PerAdultPrice;?> 
                          <span>
                          </span>
                        </p>
                      </div>
                      <div class="left_room_title floatright">
                        <a href="<?php echo base_url('front/clubdetails/'.$clb4['Slug']);?>" class="btn btn-black">Book
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <?php } } ?> 
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- end About Us section -->
<!-- start welcome section -->
<!-- start contact us area -->
<script>
  function searchfun(id){
    var url="<?php echo base_url('front/getname');?>";
    $.ajax({
      type: 'post',
      dataType : 'json',
      url: url,
      data: "id="+id,
      success: function (data) {
        document.getElementById('clubname').value=data;
      }
    }
          );
    //alert(id);
  }
</script>
<!-- end contact us area -->
<style>
  .mop {
    width: 100%;
    border: 1px solid #ccc;
    padding: 4px;
    margin: 7px;
  }
  img.imgsearch {
    width: 15%;
  }
  input#clubname ,input#bookdate {
    background: transparent;
    border: none;
    color:#fff
  }
  img.eightimg {
    height: 412px; width: 100%;
  }
  img.smcl {
    height: 55px;    width: 100%;
  }
  img.iop {
    height: 137px;
  }
  .room_wrapper {
    margin-bottom: 20px;
  }
  img.rm {
    height: 150px;    width: 100%;
  }
  img.uo {
    height: 188px;width: 100%;
  }
  .room_media {
    margin-bottom: 28px;
    text-align: center;
  }
  div#kpl {
    margin-top: 13%;
  }
</style>
<!-- start footer -->

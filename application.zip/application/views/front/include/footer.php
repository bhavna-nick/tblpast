

<?php $this->load->view('front/include/subfooternav');?>
<footer class="footer_area">
  <div class="container">
    <div class="footer">
      <div class="footer_top padding-top-80 clearfix">
        <div class="col-lg-4 col-md-4 col-sm-4">
          <div class="footer_widget">
            <div class="footer_logo">
              <a href="#">
                <img src="<?php echo base_url('assets/fronttheme/')?>/img/footer-logo-one.png" alt="">
              </a>
            </div>
            <p>Lorem ipsum dolor sit amet, conser adipiscing elit. In consectetur tincidunt dolor.
            </p>
            <ul>
              <li>
                <P>
                  <i class="fa fa-map-marker">
                  </i>St Amsterdam finland, 
                  <br> United Stats of AKY16 8PN
                </P>
              </li>
            </ul>
          </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-4">
          <div class="row">
            <div class="footer_widget clearfix">
              <h5 class="padding-left-15">Quick Links
              </h5>
              <div class="col-lg-6 col-md-6 col-sm-6">
                <ul>
                  <li>
                    <a href="<?php echo base_url();?>">Home
                    </a>
                  </li>
                  <li>
                    <a href="<?php echo base_url('front/allclub');?>">Clubs
                    </a>
                  </li>
                  <li>
                    <a href="<?php echo base_url('about');?>">About Us
                    </a>
                  </li>
                  <li>
                    <a href="<?php echo base_url('contact');?>">Contact
                    </a>
                  </li>
                </ul>  
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-4">
          <div class="footer_widget">
            <h5>We Are Global
            </h5>
            <div class="footer_map">
              <a href="#">
                <img src="<?php echo base_url('assets/fronttheme/')?>/img/footer-map-two.jpg" alt="">
              </a>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="container">
          <div class="footer_copyright margin-tb-50 content-center">
            <p>© 2018 
              <a href="#">Tablefast.com 
              </a>. All rights reserved
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
</footer>
<!-- end footer -->
<!-- jquery library -->
<script src="<?php echo base_url('assets/fronttheme/')?>/js/vendor/jquery-1.11.2.min.js"></script>
<!-- bootstrap -->
<script src="<?php echo base_url('assets/fronttheme/')?>/js/bootstrap.min.js"></script>
<!-- uikit -->
<script src="<?php echo base_url('assets/fronttheme/')?>/js/uikit.min.js"></script>
<!-- easing -->
<script src="<?php echo base_url('assets/fronttheme/')?>/js/jquery.easing.1.3.min.js"></script>
<script src="<?php echo base_url('assets/fronttheme/')?>/js/datepicker.js"></script>
<!-- scroll up -->
<script src="<?php echo base_url('assets/fronttheme/')?>/js/jquery.scrollUp.min.js"></script>
<!-- owlcarousel -->
<script src="<?php echo base_url('assets/fronttheme/')?>/js/owl.carousel.min.js"></script>
<!-- lightslider -->
<script src="<?php echo base_url('assets/fronttheme/')?>/js/lightslider.js"></script>
<!-- rev slider -->
<script src="<?php echo base_url('assets/fronttheme/')?>/js/rev-slider/rs-plugin/jquery.themepunch.plugins.min.js"></script>
<script src="<?php echo base_url('assets/fronttheme/')?>/js/rev-slider/rs-plugin/jquery.themepunch.revolution.js"></script>
<script src="<?php echo base_url('assets/fronttheme/')?>/js/rev-slider/rs.home.js"></script>
<!-- wow Animation -->
<script src="<?php echo base_url('assets/fronttheme/')?>/js/wow.min.js"></script>
<!--Activating WOW Animation only for modern browser-->
<!--[if !IE]><!-->
<script type="text/javascript">new WOW().init();</script>
<script src="<?php echo base_url('assets/fronttheme/')?>/js/main.js"></script>
</body>
</html>

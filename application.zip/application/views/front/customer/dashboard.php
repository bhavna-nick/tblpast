
      <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.min.js"></script>
  <link rel="stylesheet" href="<?php echo base_url('assets/fronttheme/')?>/custom.css">
        <section class="section-account parallax bg-11">
            <div class="awe-overlay"></div>
            <div class="container">
                <div class="login-register">
                    <div class="text text-center">
                        <h2>REGISTER FORM</h2>
      
                       
                        <form action="<?php echo base_url('vendor/register'); ?>" class="account_form" method="post" name="registration" id="registration">
                            <div class="row">
                                                  
<?php if(!empty($error)){?>
  <div class="alert alert-danger  alert-dismissible">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
     <?php  echo $error;?>
  
</div><?php } ?>
                        
<?php if(!empty($success)){?>
  <div class="alert alert-success  alert-dismissible">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
     <?php  echo $success;?>
  
</div><?php } ?>
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 floatright">
                                    <div class="field-form"><?php //echo form_error('jabatan'); ?>
                                        <input type="text" class="field-text"  name='lastname' id="lastname" placeholder="Last name*">
                                    </div>
                                    <div class="field-form">
                                        <input type="text" class="field-text"  name="clubname" id="clubname" placeholder="Club Name*">
                                    </div>
                                    <div class="field-form">
                                        <input type="password" class="field-text"  name="password" id="password" placeholder="Password*">
                                    </div>
                                    <div class="field-form">
                                        <input type="text" class="field-text"  name="state" id="state" placeholder="State*">
                                    </div>
                                    
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 floatright">
                                     <div class="field-form">
                                        <input type="text" class="field-text"  name="firstname" id="firstname" placeholder="First name*">
                                    </div>
                                    <div class="field-form">
                                        <input type="email" class="field-text"  name="email" id="email" placeholder="Email*">
                                    </div>
                                    <div class="field-form">
                                        <input type="text" onkeypress="return ValidatePhoneNo()" class="field-text" maxlength="10" name="phone" id="phone" placeholder="Phone Number*">
                                    </div>
                                      <script>
	function ValidatePhoneNo() {
			if ((event.keyCode > 47 && event.keyCode < 58) || event.keyCode == 43 || event.keyCode == 32)
				return event.returnValue;
			return event.returnValue = '';
		}
	</script>
                                    <div class="field-form">
                                        <input type="text" class="field-text"  name="city"  id="city" placeholder="City*">
                                    </div>
                                    <div class="field-form">
                                        <input type="text" class="field-text"  name="country" id="country" placeholder="Country*">
                                    </div>
                                </div>
                            </div>
                            
                            <div class="field-form field-submit">
                                <button class="btn btn-warning btn-md" >Sign up</button>
                                
                            </div>
                        </form>
                        <script>
       
            //form validation rules
            $("#registration").validate({
                rules: {
                    country: {
                            required: true,                           
                                 },
                    lastname: "required",
                    clubname: "required",
                    password: "required",
                    state: "required",
                    city: "required",
                    firstname: "required",
                    email: "required",
                    phone:
                            {  required :true,
                               integer:true,
                               minlength: 10,
                            }

               
                      },
                messages: {
                    country: {
                     required:"Please enter Country Name",
                     },
                    lastname: "Please enter Last Name",
                    clubname: "Please enter Club Name",
                    password:  {
                            required :"Please enter Password ",
                            minlength:"minimum length is 6",
                            maxlength:"maximum length is 12"
                                     }, 
                    state: "Please enter State",
                    city: "Please enter City",
                    firstname: "Please enter First Name",
                    email: "Please enter Email",
                    phone:  {
                            required :"Please enter Phone Number",
                            integer:"Please enter Only numbers",
                            minlength:"minimum length is 10",
                                     }, 

                },
                submitHandler: function(form) {
                   form.submit();
                }
            }); </script>
                        
                    </div>
                </div>
            </div>
        </section>
  <style>
    label.error {
    color: red;
    font-size: 12px;
    font-weight: 300;
    }
    .alert {
    text-align: left;
    padding-left: 26px;
    }
    a.close {
        padding-right: 14px;
    }
  </style>
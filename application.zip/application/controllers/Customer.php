<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Customer extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('App');
        $this->load->helper('new_helper');
    }
    public function index()
    {
        $this->load->view('front/include/header');
        $this->load->view('front/customer/login');
        $this->load->view('front/include/footer');
    }
    public function login()
    {
        $this->load->view('front/include/header');
        $this->load->view('front/customer/login');
        $this->load->view('front/include/footer');
    }
    public function register()
    {
        $this->load->view('front/include/header');
        $this->load->view('front/customer/register');
        $this->load->view('front/include/footer');
    }
    
}